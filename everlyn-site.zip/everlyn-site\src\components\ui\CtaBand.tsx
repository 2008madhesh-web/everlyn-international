import { Button } from "./Button";
import { Reveal, RevealText } from "./Reveal";
import { Emblem } from "../Logo";

export function CtaBand({
  title = "Tell us what you need. We'll take it from there.",
  body = "Share the product, quantity and destination. We usually reply within one business day with a quotation or a few clarifying questions.",
}: {
  title?: string;
  body?: string;
}) {
  return (
    <section className="container-lux py-24 md:py-32">
      <div className="relative overflow-hidden rounded-[2rem] bg-forest-deep px-6 py-16 text-ivory sm:px-12 md:px-20 md:py-24">
        <Emblem className="pointer-events-none absolute -bottom-24 -right-16 h-96 w-96 text-ivory/[0.06]" strokeWidth={1} />
        <div className="relative max-w-3xl">
          <p className="eyebrow mb-5 !text-brass-light">Start a conversation</p>
          <RevealText text={title} className="display text-4xl sm:text-5xl lg:text-6xl" />
          <Reveal delay={0.2}>
            <p className="mt-6 max-w-xl text-ivory/70">{body}</p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Button href="/quote" variant="light" arrow>Request a Quote</Button>
              <Button href="/contact" variant="ghost">Contact Us</Button>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
