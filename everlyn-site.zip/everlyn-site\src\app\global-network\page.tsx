import type { Metadata } from "next";
import { PageHero, SectionHeading } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { GlobeBlock } from "@/components/GlobeBlock";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { originPorts, regions } from "@/content/site";

export const metadata: Metadata = {
  title: "Global Network",
  description: "Shipping routes from India's major ports to Europe, the Middle East, the Americas, Africa, Southeast Asia and Oceania.",
};

const freight = [
  { icon: "ship" as const, t: "Sea freight", d: "FCL, LCL and reefer containers with major carriers, booked on the fastest reliable service to your port." },
  { icon: "globe" as const, t: "Air freight", d: "For samples, perishables and urgent orders, door-to-door or airport-to-airport." },
  { icon: "truck" as const, t: "Multimodal", d: "Rail and road connections from inland factories to port, and onward delivery at destination." },
  { icon: "shield" as const, t: "Cargo insurance", d: "All-risk marine insurance arranged on request for complete peace of mind." },
];

export default function GlobalNetworkPage() {
  return (
    <>
      <PageHero
        eyebrow="Global network"
        title="Six continents. One trusted route from India."
        intro="We ship from India's busiest gateways to the ports that matter to our buyers, on carriers and schedules we know well."
        crumbs={[{ label: "Global Network" }]}
      />

      <section className="container-lux grid items-center gap-16 pb-24 md:pb-32 lg:grid-cols-2">
        <Reveal className="mx-auto w-full">
          <GlobeBlock />
        </Reveal>
        <div>
          <p className="eyebrow mb-5">Origin ports in India</p>
          <ul className="flex flex-wrap gap-2">
            {originPorts.map((p) => (
              <li key={p} className="rounded-full border border-forest-deep/15 px-4 py-2 text-sm text-forest-deep">{p}</li>
            ))}
          </ul>
          <ul className="mt-12 divide-y divide-forest-deep/10 border-y border-forest-deep/10">
            {regions.map((r, i) => (
              <Reveal as="li" key={r.name} delay={i * 0.05} y={12} className="grid gap-2 py-6 sm:grid-cols-3 sm:items-baseline">
                <span className="display text-3xl text-forest-deep">{r.name}</span>
                <span className="text-sm text-ink/65">{r.ports.join(" · ")}</span>
                <span className="text-xs uppercase tracking-[0.18em] text-brass sm:text-right">Transit {r.transit}</span>
              </Reveal>
            ))}
          </ul>
          <p className="mt-6 text-xs text-ink/50">Transit times are typical port-to-port sea freight and vary by carrier and season.</p>
        </div>
      </section>

      <section className="bg-parchment/60 py-24 md:py-32">
        <div className="container-lux">
          <SectionHeading eyebrow="Logistics" title="However it needs to travel." />
          <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {freight.map((f, i) => (
              <Reveal key={f.t} delay={i * 0.07} className="rounded-[1.5rem] border border-forest-deep/10 bg-ivory p-8">
                <Icon name={f.icon} className="h-8 w-8 text-brass" />
                <h3 className="display mt-5 text-2xl text-forest-deep">{f.t}</h3>
                <p className="mt-3 text-sm leading-relaxed text-ink/65">{f.d}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <CtaBand title="Shipping somewhere not listed?" body="We ship to more than thirty-five countries. Tell us your destination port and we'll quote the best route." />
    </>
  );
}
