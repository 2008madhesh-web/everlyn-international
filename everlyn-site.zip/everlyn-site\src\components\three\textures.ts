import * as THREE from "three";

let corrugation: THREE.CanvasTexture | null = null;

/** Vertical corrugated-steel bump map, shared by every container. */
export function corrugationTexture() {
  if (corrugation) return corrugation;
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 4;
  const g = c.getContext("2d")!;
  const img = g.createImageData(128, 4);
  for (let x = 0; x < 128; x++) {
    // trapezoidal profile like real container walls
    const t = (x / 128) * Math.PI * 2;
    const v = Math.max(-0.75, Math.min(0.75, Math.sin(t))) / 0.75;
    const shade = Math.round(128 + v * 120);
    for (let y = 0; y < 4; y++) {
      const i = (y * 128 + x) * 4;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = shade;
      img.data[i + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
  corrugation = new THREE.CanvasTexture(c);
  corrugation.wrapS = corrugation.wrapT = THREE.RepeatWrapping;
  corrugation.repeat.set(26, 1);
  return corrugation;
}

const PETAL = "M0 0 C 11 -10, 13 -27, 0 -40 C -13 -27, -11 -10, 0 0 Z";
const HALF = "M0 -4 C -8 -12, -9.5 -25, 0 -36 Z";

function drawEmblem(g: CanvasRenderingContext2D, cx: number, cy: number, scale: number, color: string) {
  g.save();
  g.translate(cx, cy);
  g.scale(scale, scale);
  g.strokeStyle = color;
  g.fillStyle = color;
  g.lineWidth = 2.6;
  g.lineJoin = "round";
  const petal = new Path2D(PETAL);
  const half = new Path2D(HALF);
  const rib = new Path2D("M0 -2 L0 -34");
  for (const r of [0, 180]) {
    g.save();
    g.rotate((r * Math.PI) / 180);
    g.stroke(petal);
    g.fill(half);
    g.restore();
  }
  for (const r of [90, 270]) {
    g.save();
    g.rotate((r * Math.PI) / 180);
    g.stroke(petal);
    g.stroke(rib);
    g.restore();
  }
  g.restore();
}

function displayFont() {
  if (typeof window === "undefined") return "Georgia, serif";
  const v = getComputedStyle(document.documentElement).getPropertyValue("--font-cormorant").trim();
  return v ? `${v}, Georgia, serif` : "Georgia, serif";
}

/** Logo artwork canvas size; the loader and the container decal share this layout exactly. */
export const LOGO_CANVAS = { w: 2048, h: 860, emblem: { x: 1024, y: 215, scale: 3.4 } };
export const LOGO_COLOR = "#f3ead7";

function spaced(g: CanvasRenderingContext2D, text: string, spacing: number, y: number) {
  g.textAlign = "left";
  const widths = [...text].map((ch) => g.measureText(ch).width);
  const total = widths.reduce((a, b) => a + b, 0) + spacing * (text.length - 1);
  let x = LOGO_CANVAS.w / 2 - total / 2;
  [...text].forEach((ch, i) => {
    g.fillText(ch, x, y);
    x += widths[i] + spacing;
  });
  return total;
}

/** Draws the EVERLYN wordmark and/or the INTERNATIONALS line (with rules) onto a 2048x860 canvas. */
export function drawLogoText(g: CanvasRenderingContext2D, color: string, part: "name" | "sub" | "both" = "both") {
  const font = displayFont();
  g.fillStyle = color;
  g.textBaseline = "alphabetic";
  if (part !== "sub") {
    g.font = `500 250px ${font}`;
    spaced(g, "EVERLYN", 70, 640);
  }
  if (part !== "name") {
    g.font = `500 74px ${font}`;
    const st = spaced(g, "INTERNATIONALS", 36, 790);
    g.fillRect(1024 - st / 2 - 220, 763, 170, 5);
    g.fillRect(1024 + st / 2 + 50, 763, 170, 5);
  }
}

function paintLogo(c: HTMLCanvasElement, color: string) {
  const g = c.getContext("2d")!;
  g.clearRect(0, 0, c.width, c.height);
  drawEmblem(g, LOGO_CANVAS.emblem.x, LOGO_CANVAS.emblem.y, LOGO_CANVAS.emblem.scale, color);
  drawLogoText(g, color);
}

/** The Everlyn logo painted in ivory for the side of the container. */
export function logoDecalTexture(color = LOGO_COLOR) {
  const c = document.createElement("canvas");
  c.width = LOGO_CANVAS.w;
  c.height = LOGO_CANVAS.h;
  paintLogo(c, color);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  // repaint once the web font is ready so the lettering matches the loader exactly
  if (typeof document !== "undefined" && document.fonts && document.fonts.status !== "loaded") {
    document.fonts.ready.then(() => {
      paintLogo(c, color);
      t.needsUpdate = true;
    });
  }
  return t;
}

/** Warm interior glow seen when the doors open. */
export function interiorGlowTexture() {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(128, 150, 10, 128, 140, 180);
  grd.addColorStop(0, "#fff6dc");
  grd.addColorStop(0.35, "#f1cf8a");
  grd.addColorStop(1, "#5a3b16");
  g.fillStyle = grd;
  g.fillRect(0, 0, 256, 256);
  // silhouettes of neatly stacked cartons
  g.fillStyle = "rgba(70,45,15,0.35)";
  for (let i = 0; i < 4; i++) for (let j = 0; j < 3; j++) g.fillRect(30 + i * 52, 120 + j * 44, 46, 38);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
