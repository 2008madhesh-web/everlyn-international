﻿"use client";

import { useEffect, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useEnvironment } from "@react-three/drei";
import * as THREE from "three";
import {
  story, rig, shipPosition, truckX, craneX, cameraAt, introPose, whiteout, globeAmount, routeProgress,
  duskAmount, nightAmount, shipHeading, SUN_AZIMUTH, SUNSET_ELEVATION, MOON_DIR, GLOBE_POS, SHIP_DOCK, type RigState, seg, ease, lerp, clamp,
} from "@/lib/story";
import { HeroContainer, type ContainerRefs } from "./Container";
import { BackgroundCranes, Crane, Ocean, Quay, type CraneRefs } from "./Port";
import { Ship } from "./Ship";
import { Truck } from "./Truck";
import { Birds, SkyDome, skyUniforms } from "./Sky";
import { night } from "./night";
import { Pin, R, setRouteDraw, useGlobeData, useGlobeMaterials } from "./Globe";

/** Deep night backdrop for the globe interlude and the veil between scenes. */
const NIGHT_BG = new THREE.Color().setRGB(0.012, 0.03, 0.03);

const FOG_DAY = new THREE.Color("#d8c8b0");
const FOG_DUSK = new THREE.Color("#7a4a3e");
const FOG_NIGHT = new THREE.Color("#0b141c");
const KEY_DAY = new THREE.Color("#ffd9a8");
const KEY_DUSK = new THREE.Color("#ff8a45");
const KEY_NIGHT = new THREE.Color("#9fb6e0");
const GLINT_DAY = new THREE.Color(1.2, 1.0, 0.75);
const GLINT_DUSK = new THREE.Color(2.6, 1.1, 0.38);
const GLINT_NIGHT = new THREE.Color(0.12, 0.14, 0.2);
const HEMI_SKY_DAY = new THREE.Color("#f6ead6");
const HEMI_SKY_NIGHT = new THREE.Color("#2a3f5c");
const HEMI_GROUND_DAY = new THREE.Color("#7d6f5c");
const HEMI_GROUND_NIGHT = new THREE.Color("#0b0d10");

/** Finds the sun in an equirectangular HDR (brightest texel): longitude and latitude in the texture. */
function findSun(tex: THREE.Texture) {
  const img = tex.image as { data?: ArrayLike<number>; width?: number; height?: number };
  const fallback = { lon: 0, lat: 0.2 };
  if (!img?.data || !img.width || !img.height) return fallback;
  const { data, width, height } = img;
  const half = data instanceof Uint16Array;
  const val = (i: number) => (half ? THREE.DataUtils.fromHalfFloat(data[i]) : data[i]);
  let best = -1;
  let bx = 0;
  let by = 0;
  const stride = data.length / (width * height);
  for (let y = 0; y < height / 2; y += 2)
    for (let x = 0; x < width; x += 2) {
      const i = (y * width + x) * stride;
      const l = val(i) * 0.3 + val(i + 1) * 0.59 + val(i + 2) * 0.11;
      if (l > best) {
        best = l;
        bx = x;
        by = y;
      }
    }
  const u = (bx + 0.5) / width;
  const v = tex.flipY ? 1 - (by + 0.5) / height : (by + 0.5) / height;
  return { lon: (u - 0.5) * Math.PI * 2, lat: (v - 0.5) * Math.PI };
}

/** Sun direction in the world at a given elevation, always on the story's sun azimuth. */
function sunAt(elevation: number, out: THREE.Vector3) {
  const c = Math.cos(elevation);
  return out.set(SUN_AZIMUTH.x * c, Math.sin(elevation), SUN_AZIMUTH.z * c);
}

export function StoryScene({ lite }: { lite: boolean }) {
  const shadows = !lite;
  const { scene, camera, size } = useThree();
  const env = useEnvironment({ files: "/hdri/sky.hdr" });

  // refs ---------------------------------------------------------------------
  const container: ContainerRefs = {
    group: useRef<THREE.Group>(null),
    doorL: useRef<THREE.Group>(null),
    doorR: useRef<THREE.Group>(null),
    decalMat: useRef<THREE.MeshStandardMaterial>(null),
    glowMat: useRef<THREE.MeshBasicMaterial>(null),
    spillMat: useRef<THREE.MeshBasicMaterial>(null),
    light: useRef<THREE.PointLight>(null),
  };
  const crane: CraneRefs = {
    root: useRef<THREE.Group>(null),
    trolley: useRef<THREE.Group>(null),
    spreader: useRef<THREE.Group>(null),
    ropes: useRef<THREE.Group>(null),
  };
  const local = useRef<THREE.Group>(null);
  const dome = useRef<THREE.Mesh>(null);
  const ship = useRef<THREE.Group>(null);
  const wake = useRef<THREE.MeshBasicMaterial>(null);
  const mooring = useRef<THREE.Group>(null);
  const truck = useRef<THREE.Group>(null);
  const ocean = useRef<THREE.Mesh>(null);
  const sun = useRef<THREE.DirectionalLight>(null);
  const hemi = useRef<THREE.HemisphereLight>(null);
  const floods = useRef<THREE.Group>(null);
  const birdsVisible = useRef(1);
  const veil = useRef<THREE.Mesh>(null);
  const globe = useRef<THREE.Group>(null);
  const spin = useRef<THREE.Group>(null);
  const marker = useRef<THREE.Group>(null);
  const rings = useRef<(THREE.Mesh | null)[]>([]);

  const globeData = useGlobeData(lite ? 16000 : 26000);
  const gm = useGlobeMaterials();
  const ringMats = useMemo(() => Array.from({ length: globeData.pins.length + 1 }, () => gm.ring.clone()), [globeData.pins.length, gm.ring]);
  // rotate the sky so its sun sits on the story's sun azimuth (straight ahead in the opening shot)
  const sky = useMemo(() => {
    const found = findSun(env);
    const rotation = Math.atan2(SUN_AZIMUTH.z, SUN_AZIMUTH.x) - found.lon;
    if (process.env.NODE_ENV !== "production") (window as unknown as { __sky: unknown }).__sky = { rotation, elevation: found.lat };
    return { rotation, elevation: found.lat };
  }, [env]);

  // scratch objects ----------------------------------------------------------
  const s = useMemo(
    () => ({
      ship: new THREE.Vector3(),
      prevShip: new THREE.Vector3(),
      rig: { container: new THREE.Vector3(), spreaderY: 0, trolleyZ: 0, onShip: false, doors: 0 } as RigState,
      cam: new THREE.Vector3(),
      look: new THREE.Vector3(),
      iCam: new THREE.Vector3(),
      iLook: new THREE.Vector3(),
      fwd: new THREE.Vector3(),
      key: new THREE.Vector3(),
      sunNow: new THREE.Vector3(),
      dayKey: new THREE.Vector3(),
      camS: new THREE.Vector3(),
      lookS: new THREE.Vector3(),
      camInit: false,
      m: new THREE.Vector3(),
      rotY: 0,
      rotX: 0,
      globeWasHidden: true,
      time: 0,
      speed: 0,
    }),
    [],
  );

  useEffect(() => {
    scene.environment = env;
    scene.background = null;
    scene.environmentRotation.set(0, -sky.rotation, 0);
    scene.fog = new THREE.Fog(FOG_DAY.clone(), 40, 170);
    skyUniforms.uEnv.value = env;
    skyUniforms.uEnvRot.value = sky.rotation;
    skyUniforms.uMoonDir.value.copy(MOON_DIR);
    return () => {
      scene.fog = null;
      scene.environment = null;
      scene.background = null;
    };
  }, [scene, env, sky]);

  useFrame((state, dt) => {
    const d = Math.min(dt, 0.05);
    s.time += d;
    // unhurried: the story eases toward the scroll position rather than jumping to it
    story.current += (story.target - story.current) * (1 - Math.exp(-d * 2.6));
    const p = story.current;
    const aspect = size.width / size.height;
    const intro = story.intro;

    // --- time of day ------------------------------------------------------
    const du = duskAmount(p);
    const ni = nightAmount(p);
    night.value = ni;
    skyUniforms.uDusk.value = du;
    skyUniforms.uNight.value = ni;
    skyUniforms.uTime.value = s.time;
    // the same sun, sinking from its afternoon height to the horizon as dusk falls
    sunAt(lerp(sky.elevation, SUNSET_ELEVATION, du), s.sunNow);
    skyUniforms.uSunDir.value.copy(s.sunNow);
    sunAt(Math.max(sky.elevation, 0.3), s.dayKey); // keep daytime shadows readable
    s.key.copy(s.dayKey).lerp(s.sunNow, du).lerp(MOON_DIR, ni).normalize();
    skyUniforms.uKeyDir.value.copy(s.key);
    skyUniforms.uKeyColor.value.copy(GLINT_DAY).lerp(GLINT_DUSK, du).lerp(GLINT_NIGHT, ni);
    birdsVisible.current = (1 - ni) * (1 - du * 0.4);

    // --- world state -----------------------------------------------------
    s.prevShip.copy(s.ship);
    shipPosition(p, s.ship);
    const v = s.prevShip.distanceTo(s.ship) / Math.max(d, 1e-3);
    s.speed += (Math.min(v, 30) - s.speed) * 0.08;
    const bob = Math.sin(s.time * 0.9) * 0.03;
    const r = rig(p, s.ship, s.rig);
    const tx = truckX();

    if (ship.current) {
      ship.current.position.set(s.ship.x, s.ship.y + bob, s.ship.z);
      ship.current.rotation.set(Math.sin(s.time * 0.55) * 0.008, shipHeading(p), Math.sin(s.time * 0.7) * 0.006);
    }
    if (wake.current) wake.current.opacity = clamp(s.speed / 8) * 0.8 * (1 - ni * 0.7);
    if (mooring.current) mooring.current.visible = s.ship.distanceTo(SHIP_DOCK) < 0.05;
    if (container.group.current) {
      const g = container.group.current;
      g.position.copy(r.container);
      if (r.onShip) g.position.y += bob;
      const hanging = !r.onShip && r.container.y > 0.6 && r.container.y < 4.5 && Math.abs(r.container.y - 1.28) > 0.001;
      g.rotation.z = hanging ? Math.sin(s.time * 1.4) * 0.01 : 0;
      // presentation turn only after the logo hand-off, and settled before pick-up
      g.rotation.y = ease(seg(intro, 0.4, 1)) * (1 - seg(p, 0.06, 0.12)) * (Math.sin(s.time * 0.35) * 0.04 + story.pointerX * 0.06);
      // once aboard, the container turns with the ship
      if (r.onShip) g.rotation.y = shipHeading(p) - Math.PI;
    }
    if (crane.root.current) crane.root.current.position.x = craneX(p);
    if (crane.trolley.current) crane.trolley.current.position.z = r.trolleyZ;
    if (crane.spreader.current) crane.spreader.current.position.set(0, r.spreaderY, r.trolleyZ);
    if (crane.ropes.current) {
      const top = 7.4 - 0.3;
      crane.ropes.current.position.y = top;
      crane.ropes.current.scale.y = Math.max(0.05, top - (r.spreaderY + 0.3));
    }
    if (truck.current) {
      truck.current.visible = p > 0.66;
      truck.current.position.set(tx, 0, 0);
    }

    // --- light ------------------------------------------------------------
    const w = whiteout(p);
    const ga = globeAmount(p);
    const localVisible = w < 0.995;
    if (local.current) local.current.visible = localVisible;
    if (dome.current) {
      dome.current.visible = localVisible;
      dome.current.position.copy(camera.position);
    }
    scene.background = localVisible ? null : NIGHT_BG;
    // the ship goes dark against the sunset (silhouette), then night
    scene.environmentIntensity = ga > 0.5 ? 0.9 : lerp(lerp(1, 0.05, du), 0.08, ni);
    const fog = scene.fog as THREE.Fog | null;
    if (fog) {
      fog.color.copy(FOG_DAY).lerp(FOG_DUSK, du).lerp(FOG_NIGHT, ni);
      fog.near = lerp(45, 30, ni);
      fog.far = lerp(lerp(190, 260, du), 140, ni);
    }
    if (sun.current) {
      const f = r.container;
      sun.current.position.set(f.x + s.key.x * 30, s.key.y * 30, f.z + s.key.z * 30);
      sun.current.target.position.set(f.x, 0, f.z);
      sun.current.target.updateMatrixWorld();
      sun.current.color.copy(KEY_DAY).lerp(KEY_DUSK, du).lerp(KEY_NIGHT, ni);
      sun.current.intensity = lerp(lerp(2.6, 0.9, du), 0.85, ni);
    }
    if (hemi.current) {
      hemi.current.color.copy(HEMI_SKY_DAY).lerp(HEMI_SKY_NIGHT, ni);
      hemi.current.groundColor.copy(HEMI_GROUND_DAY).lerp(HEMI_GROUND_NIGHT, ni);
      hemi.current.intensity = lerp(lerp(0.35, 0.05, du), 0.45, ni);
    }
    if (floods.current) {
      floods.current.visible = ni > 0.02;
      floods.current.children.forEach((l) => {
        const light = l as THREE.SpotLight;
        if (light.isSpotLight) light.intensity = ni * (light.userData.power as number);
      });
    }
    if (veil.current) {
      (veil.current.material as THREE.MeshBasicMaterial).opacity = w;
      veil.current.visible = w > 0.001 && ga < 0.999;
    }
    if (ocean.current) {
      ocean.current.position.x = Math.round(camera.position.x / 4) * 4;
      ocean.current.position.z = Math.round(camera.position.z / 4) * 4 - 40;
    }

    // --- globe ------------------------------------------------------------
    if (globe.current) {
      globe.current.visible = ga > 0.001;
      globe.current.scale.setScalar(lerp(0.82, 1, ease(ga)));
    }
    if (ga > 0.001) {
      gm.ocean.opacity = ga;
      gm.ocean.depthWrite = ga > 0.5;
      gm.dots.uniforms.uOpacity.value = ga;
      gm.atmo.uniforms.uOpacity.value = 0.75 * ga;
      const rp = routeProgress(p);
      setRouteDraw(globeData.hero, rp);
      gm.heroRoute.opacity = ga;
      globeData.others.forEach((rt, i) => setRouteDraw(rt, ease(seg(p, 0.49 + i * 0.012, 0.56 + i * 0.012))));
      gm.route.opacity = 0.5 * ga;
      gm.pin.opacity = ga;
      const mp = globeData.hero.curve.getPointAt(Math.max(0.001, rp), s.m);
      if (marker.current) {
        marker.current.position.copy(mp);
        marker.current.scale.setScalar(0.9 + Math.sin(s.time * 4) * 0.08);
      }
      const n = mp.clone().normalize();
      const targetY = -Math.atan2(n.x, n.z);
      const targetX = Math.asin(n.y) * 0.75;
      let dy = targetY - s.rotY;
      dy = Math.atan2(Math.sin(dy), Math.cos(dy));
      const k = s.globeWasHidden ? 1 : 1 - Math.exp(-d * 3);
      s.globeWasHidden = false;
      s.rotY += dy * k;
      s.rotX += (targetX - s.rotX) * k;
      if (spin.current) spin.current.rotation.set(s.rotX, s.rotY, 0, "XYZ");
      rings.current.forEach((mesh, i) => {
        if (!mesh) return;
        const ph = (s.time * 0.6 + i * 0.27) % 1;
        mesh.scale.setScalar(0.6 + ph * 1.6);
        (mesh.material as THREE.MeshBasicMaterial).opacity = (1 - ph) * ga * 0.9;
      });
    } else {
      s.globeWasHidden = true;
    }

    // --- camera -----------------------------------------------------------
    cameraAt(p, s.ship, tx, aspect, s.cam, s.look);
    if (intro < 1) {
      introPose(size.width, size.height, s.iCam, s.iLook);
      const t = ease(seg(intro, 0.18, 1));
      s.cam.lerpVectors(s.iCam, s.cam, t);
      s.look.lerpVectors(s.iLook, s.look, t);
    }
    const par = (1 - ga) * (aspect < 1 ? 0 : 1) * ease(seg(intro, 0.6, 1));
    s.cam.x += story.pointerX * 0.18 * par;
    s.cam.y += story.pointerY * 0.1 * par;

    // Steadicam: the real camera glides after its target so moves are slow and turns gentle.
    // (Exact during the logo hand-off, and it cuts instantly across the veiled jump to the globe.)
    const jump = s.camS.distanceTo(s.cam) > 40;
    if (!s.camInit || intro < 1 || jump) {
      s.camS.copy(s.cam);
      s.lookS.copy(s.look);
      s.camInit = true;
    } else {
      const k = 1 - Math.exp(-d * 2.2);
      s.camS.lerp(s.cam, k);
      s.lookS.lerp(s.look, 1 - Math.exp(-d * 1.8));
    }
    camera.position.copy(s.camS);
    camera.lookAt(s.lookS);
    if (process.env.NODE_ENV !== "production") (window as unknown as { __dbg: unknown }).__dbg = { ship: s.ship, cam: s.camS, look: s.lookS, sun: s.sunNow };

    if (veil.current) {
      camera.getWorldDirection(s.fwd);
      veil.current.position.copy(camera.position).addScaledVector(s.fwd, 0.15);
      veil.current.quaternion.copy(camera.quaternion);
    }
  });

  const flood = (pos: [number, number, number], target: [number, number, number], power: number) => {
    const light = new THREE.SpotLight("#ffe2b5", 0, 42, 0.62, 0.75, 1.3);
    light.position.set(...pos);
    light.target.position.set(...target);
    light.userData.power = power;
    return light;
  };
  const floodLights = useMemo(
    () => [
      flood([0, 7.1, 0.6], [0, 0, 0.2], 120), // crane, over the lorry lane
      flood([0, 7.1, -3.2], [0, 0, -5.6], 70), // crane, over the ship
      flood([11, 9, 12], [1, 0, 0], 190), // high-mast
      flood([-6, 9, 12], [-2, 0, -1], 140), // high-mast
    ],
    [],
  );

  return (
    <>
      <hemisphereLight ref={hemi} args={["#f6ead6", "#7d6f5c", 0.35]} />
      <directionalLight
        ref={sun}
        intensity={2.6}
        color="#ffd9a8"
        castShadow={shadows}
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-18}
        shadow-camera-right={18}
        shadow-camera-top={18}
        shadow-camera-bottom={-18}
        shadow-camera-far={90}
        shadow-bias={-0.00025}
        shadow-normalBias={0.02}
      />

      <SkyDome domeRef={dome} />

      <group ref={local}>
        <group ref={floods}>
          {floodLights.map((l, i) => (
            <group key={i}>
              <primitive object={l} />
              <primitive object={l.target} />
            </group>
          ))}
        </group>
        <Quay shadows={shadows} lite={lite} mooringRef={mooring} />
        <Crane refs={crane} shadows={shadows} />
        {!lite && <BackgroundCranes shadows={false} />}
        <Ship groupRef={ship} wakeRef={wake} shadows={shadows} lite={lite} />
        <Truck groupRef={truck} shadows={shadows} />
        <Ocean meshRef={ocean} />
        <HeroContainer refs={container} shadows={shadows} />
        <Birds visibleRef={birdsVisible} />
      </group>

      {/* veil used for the cross-fade between the port and the night globe */}
      <mesh ref={veil} renderOrder={1000} visible={false}>
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial color={NIGHT_BG} transparent opacity={0} depthTest={false} depthWrite={false} toneMapped={false} fog={false} />
      </mesh>

      <group ref={globe} position={GLOBE_POS} visible={false}>
        <group ref={spin}>
          <mesh material={gm.ocean} renderOrder={0}>
            <sphereGeometry args={[R, 64, 64]} />
          </mesh>
          <points material={gm.dots} renderOrder={1}>
            <bufferGeometry>
              <bufferAttribute attach="attributes-position" args={[globeData.positions, 3]} />
            </bufferGeometry>
          </points>
          <mesh geometry={globeData.hero.geo} material={gm.heroRoute} renderOrder={2} />
          {globeData.others.map((rt, i) => (
            <mesh key={i} geometry={rt.geo} material={gm.route} renderOrder={2} />
          ))}
          <Pin at={globeData.origin} mat={gm.pin} ringMat={ringMats[0]} size={1.5} ringRef={(mesh) => (rings.current[0] = mesh)} />
          {globeData.pins.map((pin, i) => (
            <Pin key={i} at={pin} mat={gm.pin} ringMat={ringMats[i + 1]} ringRef={(mesh) => (rings.current[i + 1] = mesh)} />
          ))}
          <group ref={marker}>
            <mesh material={gm.pin}>
              <boxGeometry args={[0.07, 0.035, 0.035]} />
            </mesh>
          </group>
        </group>
        <mesh material={gm.atmo}>
          <sphereGeometry args={[R * 1.1, 48, 48]} />
        </mesh>
      </group>
    </>
  );
}
