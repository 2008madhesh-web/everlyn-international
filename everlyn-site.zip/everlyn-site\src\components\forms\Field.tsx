"use client";

import { AnimatePresence, motion } from "framer-motion";

export function Field({
  label,
  error,
  children,
  htmlFor,
  optional,
  className = "",
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
  htmlFor: string;
  optional?: boolean;
  className?: string;
}) {
  return (
    <div className={`relative ${className}`}>
      <label htmlFor={htmlFor} className="text-[0.68rem] font-medium uppercase tracking-[0.2em] text-ink/55">
        {label}
        {optional && <span className="ml-2 normal-case tracking-normal text-ink/35">optional</span>}
      </label>
      {children}
      <AnimatePresence>
        {error && (
          <motion.p
            id={`${htmlFor}-error`}
            role="alert"
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-2 text-xs text-[#9b3b2a]"
          >
            {error}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}

export function SuccessMark() {
  return (
    <svg viewBox="0 0 64 64" className="h-16 w-16 text-forest" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
      <motion.circle cx="32" cy="32" r="30" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }} />
      <motion.path d="M20 33l8 8 16-17" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.7, delay: 0.7, ease: [0.22, 1, 0.36, 1] }} />
    </svg>
  );
}
