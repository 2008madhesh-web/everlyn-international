type EmblemProps = { className?: string; strokeWidth?: number; draw?: boolean };

/** Four-petal emblem redrawn from the Everlyn logo. Uses currentColor. */
export function Emblem({ className, strokeWidth = 2.6, draw = false }: EmblemProps) {
  const outline = "M0 0 C 11 -10, 13 -27, 0 -40 C -13 -27, -11 -10, 0 0 Z";
  const half = "M0 -4 C -8 -12, -9.5 -25, 0 -36 Z";
  const drawCls = draw ? "emblem-draw" : undefined;
  return (
    <svg viewBox="0 0 100 100" className={className} aria-hidden="true" fill="none">
      <g transform="translate(50 50)" stroke="currentColor" strokeWidth={strokeWidth} strokeLinejoin="round">
        {/* vertical petals: outline + filled half */}
        {[0, 180].map((r) => (
          <g key={r} transform={`rotate(${r})`}>
            <path d={outline} className={drawCls} pathLength={1} />
            <path d={half} fill="currentColor" stroke="none" className={draw ? "emblem-fill" : undefined} />
          </g>
        ))}
        {/* horizontal petals: outline + midrib */}
        {[90, 270].map((r) => (
          <g key={r} transform={`rotate(${r})`}>
            <path d={outline} className={drawCls} pathLength={1} />
            <path d="M0 -2 L0 -34" className={drawCls} pathLength={1} />
          </g>
        ))}
      </g>
    </svg>
  );
}

type LogoProps = { className?: string; compact?: boolean };

/** Horizontal lockup for navigation and footer. */
export function Logo({ className, compact }: LogoProps) {
  return (
    <span className={`inline-flex items-center gap-3 ${className ?? ""}`}>
      <Emblem className="h-9 w-9 shrink-0" strokeWidth={3} />
      <span className="flex flex-col leading-none">
        <span className="font-display text-[1.45rem] tracking-[0.28em] font-medium">EVERLYN</span>
        {!compact && (
          <span className="mt-1 flex items-center gap-2 text-[0.52rem] tracking-[0.42em] font-medium opacity-80">
            <span className="h-px w-3 bg-current opacity-60" />
            INTERNATIONALS
            <span className="h-px w-3 bg-current opacity-60" />
          </span>
        )}
      </span>
    </span>
  );
}

/** Stacked lockup, as on the original logo artwork. */
export function LogoStacked({ className }: { className?: string }) {
  return (
    <span className={`inline-flex flex-col items-center ${className ?? ""}`}>
      <Emblem className="h-16 w-16" strokeWidth={2.4} />
      <span className="mt-4 font-display text-5xl tracking-[0.3em] pl-[0.3em]">EVERLYN</span>
      <span className="mt-3 flex items-center gap-4 text-[0.7rem] tracking-[0.5em] pl-[0.5em]">
        <span className="h-px w-10 bg-current opacity-60" />
        INTERNATIONALS
        <span className="h-px w-10 bg-current opacity-60" />
      </span>
    </span>
  );
}
