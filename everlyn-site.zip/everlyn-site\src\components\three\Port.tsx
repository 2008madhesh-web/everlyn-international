﻿"use client";

import { useLayoutEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { containerGeometry, corrugatedPanel } from "./geometry";
import { hazardTexture, hullLetteringTexture, usePBR, waterNormalTexture } from "./materials";
import { SHIP_DOCK, WATER_Y } from "@/lib/story";
import { SKY_GLSL, skyUniforms } from "./Sky";
import { night } from "./night";

// Deterministic random so the yard looks identical on every load
export function rng(seed: number) {
  return () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
}

/** Real-world container liveries, slightly muted to sit with the Everlyn palette. */
export const LIVERIES = ["#1f5c47", "#173f33", "#a27a3c", "#d9d2c3", "#efebe2", "#4b5754", "#8e3f2c", "#27405a", "#6d7a3a", "#b4532e"];

export type Stack = { p: [number, number, number]; c: string; r?: number };

/** Instanced stacks of corrugated containers with per-box colour variation. */
export function ContainerStacks({ items, shadows }: { items: Stack[]; shadows: boolean }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const pbr = usePBR();
  const geo = useMemo(() => containerGeometry(), []);
  useLayoutEffect(() => {
    const m = ref.current!;
    const o = new THREE.Object3D();
    const col = new THREE.Color();
    const r = rng(items.length + 3);
    items.forEach((it, i) => {
      o.position.set(...it.p);
      o.rotation.set(0, it.r ?? 0, 0);
      o.updateMatrix();
      m.setMatrixAt(i, o.matrix);
      // weathering: each box a touch lighter/darker than its fleet colour
      col.set(it.c).offsetHSL(0, (r() - 0.5) * 0.05, (r() - 0.5) * 0.06);
      m.setColorAt(i, col);
    });
    m.instanceMatrix.needsUpdate = true;
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
  }, [items]);
  return <instancedMesh ref={ref} args={[geo, pbr.containerYard, items.length]} castShadow={shadows} receiveShadow={shadows} />;
}

function worldUVPlane(w: number, h: number) {
  const g = new THREE.PlaneGeometry(w, h);
  const uv = g.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w, uv.getY(i) * h);
  return g;
}

function useLathe(points: [number, number][], seg = 20) {
  return useMemo(() => new THREE.LatheGeometry(points.map(([x, y]) => new THREE.Vector2(x, y)), seg), [points, seg]);
}

const BOLLARD: [number, number][] = [[0, 0], [0.12, 0], [0.12, 0.03], [0.08, 0.05], [0.07, 0.2], [0.11, 0.24], [0.11, 0.28], [0, 0.29]];

// ---------------------------------------------------------------------------
export function Quay({ shadows, lite, mooringRef }: { shadows: boolean; lite: boolean; mooringRef: React.RefObject<THREE.Group | null> }) {
  const pbr = usePBR();
  const bollardGeo = useLathe(BOLLARD);
  const yard = useMemo(() => {
    const r = rng(7);
    const out: Stack[] = [];
    const block = (x0: number, x1: number, z0: number, z1: number, maxH: number, fill = 0.85) => {
      for (let x = x0; x <= x1; x += 2.55)
        for (let z = z0; z <= z1; z += 1.06) {
          if (r() > fill) continue;
          const h = 1 + Math.floor(r() * maxH);
          for (let y = 0; y < h; y++) out.push({ p: [x, 0.5 + y * 1.0, z], c: LIVERIES[Math.floor(r() * LIVERIES.length)] });
        }
    };
    block(-38, -10.5, 5.4, lite ? 7.6 : 10.8, 3);
    // (the quay to the right is kept clear: it is the sunset viewpoint)
    block(-34, 22, 15, lite ? 17 : 19, lite ? 2 : 3, 0.85);
    return out;
  }, [lite]);

  const m = useMemo(() => {
    const dark = new THREE.MeshStandardMaterial({ color: "#2b2d2a", roughness: 0.55, metalness: 0.7 });
    const rubber = new THREE.MeshStandardMaterial({ color: "#151614", roughness: 0.95 });
    const yellow = new THREE.MeshStandardMaterial({ color: "#d4a62a", roughness: 0.7 });
    const white = new THREE.MeshStandardMaterial({ color: "#e9e4d8", roughness: 0.7 });
    const pole = new THREE.MeshStandardMaterial({ color: "#9aa09a", roughness: 0.4, metalness: 0.8 });
    const lamp = new THREE.MeshStandardMaterial({ color: "#fff2d0", emissive: "#ffd99a", emissiveIntensity: 1.4, toneMapped: false });
    const rope = new THREE.MeshStandardMaterial({ color: "#d8c9a6", roughness: 0.9 });
    const top = worldUVPlane(240, 24);
    const face = worldUVPlane(240, 2.4);
    return { dark, rubber, yellow, white, pole, lamp, rope, top, face };
  }, []);

  // floodlights come on as night falls
  useFrame(() => {
    m.lamp.emissiveIntensity = 0.4 + night.value * 7;
  });

  // Mooring lines from the docked ship to the quay bollards (shown only while alongside)
  const lines = useMemo(() => {
    const shipZ = SHIP_DOCK.z + 2.62;
    const pairs: [THREE.Vector3, THREE.Vector3][] = [
      [new THREE.Vector3(-13, -0.05, shipZ), new THREE.Vector3(-18.6, 0.25, -2.35)],
      [new THREE.Vector3(-11.5, -0.1, shipZ), new THREE.Vector3(-9.0, 0.25, -2.35)],
      [new THREE.Vector3(11.5, -0.1, shipZ), new THREE.Vector3(9.0, 0.25, -2.35)],
      [new THREE.Vector3(12.8, -0.1, shipZ), new THREE.Vector3(18.6, 0.25, -2.35)],
    ];
    return pairs.map(([a, b]) => {
      const mid = a.clone().lerp(b, 0.5);
      mid.y -= 0.35; // sag
      return new THREE.TubeGeometry(new THREE.QuadraticBezierCurve3(a, mid, b), 24, 0.018, 6, false);
    });
  }, []);

  return (
    <group>
      {/* quay deck and wall */}
      <mesh geometry={m.top} material={pbr.concrete} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 9.4]} receiveShadow={shadows} />
      <mesh geometry={m.face} material={pbr.concrete} position={[0, -1.2, -2.6]} rotation={[0, Math.PI, 0]} />
      {/* yellow safety edge and capping */}
      <mesh material={m.yellow} position={[0, 0.012, -2.48]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[240, 0.16]} />
      </mesh>
      {/* crane rails */}
      {[2.4, -2.2].map((z) => (
        <mesh key={z} material={m.dark} position={[0, 0.02, z]} receiveShadow={shadows}>
          <boxGeometry args={[240, 0.04, 0.08]} />
        </mesh>
      ))}
      {/* painted lane markings */}
      {Array.from({ length: 36 }).map((_, i) => (
        <mesh key={i} material={m.white} position={[-45 + i * 2.6, 0.008, 1.0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[1.3, 0.05]} />
        </mesh>
      ))}
      {Array.from({ length: 36 }).map((_, i) => (
        <mesh key={`b${i}`} material={m.white} position={[-45 + i * 2.6, 0.008, -1.0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[1.3, 0.05]} />
        </mesh>
      ))}
      {/* cone fenders on the quay wall */}
      {Array.from({ length: 22 }).map((_, i) => (
        <mesh key={i} material={m.rubber} position={[-42 + i * 4, -0.55, -2.72]} castShadow={shadows}>
          <cylinderGeometry args={[0.2, 0.26, 0.9, 16]} />
        </mesh>
      ))}
      {/* mushroom bollards */}
      {Array.from({ length: 16 }).map((_, i) => (
        <mesh key={i} geometry={bollardGeo} material={m.dark} position={[-42.6 + i * 4.8 + (i % 2) * 0.4, 0, -2.3]} castShadow={shadows} />
      ))}
      {/* high-mast floodlights */}
      {Array.from({ length: 6 }).map((_, i) => (
        <group key={i} position={[-40 + i * 17, 0, 12]}>
          <mesh material={m.pole} position={[0, 4.5, 0]} castShadow={shadows}>
            <cylinderGeometry args={[0.07, 0.13, 9, 10]} />
          </mesh>
          <mesh material={m.pole} position={[0, 9.05, 0]}>
            <torusGeometry args={[0.45, 0.04, 6, 20]} />
          </mesh>
          {[0, 1, 2, 3, 4, 5].map((k) => (
            <mesh key={k} material={m.lamp} position={[Math.cos((k / 6) * Math.PI * 2) * 0.45, 9.0, Math.sin((k / 6) * Math.PI * 2) * 0.45]}>
              <boxGeometry args={[0.16, 0.08, 0.16]} />
            </mesh>
          ))}
        </group>
      ))}
      <group ref={mooringRef}>
        {lines.map((g, i) => (
          <mesh key={i} geometry={g} material={m.rope} />
        ))}
      </group>
      <ContainerStacks items={yard} shadows={shadows} />
    </group>
  );
}

// ---------------------------------------------------------------------------
export type CraneRefs = {
  root: React.RefObject<THREE.Group | null>;
  trolley: React.RefObject<THREE.Group | null>;
  spreader: React.RefObject<THREE.Group | null>;
  ropes: React.RefObject<THREE.Group | null>;
};

function Strut({ a, b, r, material }: { a: [number, number, number]; b: [number, number, number]; r: number; material: THREE.Material }) {
  const { pos, quat, len } = useMemo(() => {
    const va = new THREE.Vector3(...a);
    const vb = new THREE.Vector3(...b);
    const d = vb.clone().sub(va);
    const len = d.length();
    const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize());
    return { pos: va.add(vb).multiplyScalar(0.5), quat, len };
  }, [a, b]);
  return (
    <mesh position={pos} quaternion={quat} material={material}>
      <cylinderGeometry args={[r, r, len, 8]} />
    </mesh>
  );
}

export const CRANE_TOP = 7.4;

function useCraneMaterials() {
  return useMemo(() => {
    const paint = new THREE.MeshStandardMaterial({ color: "#ebe6db", roughness: 0.5, metalness: 0.25 });
    const dark = new THREE.MeshStandardMaterial({ color: "#2f3431", roughness: 0.5, metalness: 0.6 });
    const glass = new THREE.MeshPhysicalMaterial({ color: "#1f2b2a", roughness: 0.05, metalness: 0.2, envMapIntensity: 1.6 });
    const hazard = hazardTexture();
    hazard.wrapS = hazard.wrapT = THREE.RepeatWrapping;
    hazard.repeat.set(1, 3);
    const stripes = new THREE.MeshStandardMaterial({ map: hazard, roughness: 0.6 });
    const spreader = new THREE.MeshStandardMaterial({ color: "#c9952c", roughness: 0.45, metalness: 0.5 });
    const emerald = new THREE.MeshStandardMaterial({ color: "#1f5c47", roughness: 0.5, metalness: 0.3 });
    const red = new THREE.MeshStandardMaterial({ color: "#ff3b2a", emissive: "#ff2a1a", emissiveIntensity: 2, toneMapped: false });
    const lettering = new THREE.MeshBasicMaterial({ map: hullLetteringTexture("EVERLYN", "#efe6d2", 60), transparent: true, toneMapped: false });
    return { paint, dark, glass, stripes, spreader, emerald, red, lettering };
  }, []);
}

/** The gantry structure (legs, portal, boom, machinery house). Shared by the working crane and the background cranes. */
function CraneFrame({ shadows, boomRaise = 0 }: { shadows: boolean; boomRaise?: number }) {
  const m = useCraneMaterials();
  const TOP = CRANE_TOP;
  const legs: [number, number][] = [
    [3.2, 2.4],
    [-3.2, 2.4],
    [3.2, -2.2],
    [-3.2, -2.2],
  ];
  return (
    <group>
      {legs.map(([x, z]) => (
        <group key={`${x}${z}`}>
          <mesh material={m.paint} position={[x, TOP / 2 + 0.4, z]} castShadow={shadows} receiveShadow={shadows}>
            <boxGeometry args={[0.34, TOP - 0.8, 0.34]} />
          </mesh>
          <mesh material={m.stripes} position={[x, 1.0, z]}>
            <boxGeometry args={[0.35, 0.8, 0.35]} />
          </mesh>
          {/* travelling bogie with wheels on the rail */}
          <mesh material={m.dark} position={[x, 0.32, z]} castShadow={shadows}>
            <boxGeometry args={[1.1, 0.3, 0.42]} />
          </mesh>
          {[-0.36, 0, 0.36].map((dx) => (
            <mesh key={dx} material={m.dark} position={[x + dx, 0.13, z]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.12, 0.12, 0.12, 14]} />
            </mesh>
          ))}
        </group>
      ))}
      {/* sill beams and portal beams */}
      {[3.2, -3.2].map((x) => (
        <mesh key={x} material={m.paint} position={[x, 0.62, 0.1]} castShadow={shadows}>
          <boxGeometry args={[0.3, 0.3, 4.9]} />
        </mesh>
      ))}
      {[2.4, -2.2].map((z) => (
        <mesh key={z} material={m.paint} position={[0, TOP - 0.2, z]} castShadow={shadows}>
          <boxGeometry args={[6.75, 0.42, 0.34]} />
        </mesh>
      ))}
      {[3.2, -3.2].map((x) => (
        <group key={`d${x}`}>
          <Strut a={[x, 0.8, 2.4]} b={[x, TOP - 0.4, -2.2]} r={0.07} material={m.paint} />
          <Strut a={[x, 0.8, -2.2]} b={[x, TOP * 0.55, 0.1]} r={0.05} material={m.paint} />
        </group>
      ))}
      {/* caged access ladder on the landside leg */}
      <mesh material={m.dark} position={[3.42, TOP / 2, 2.4]}>
        <boxGeometry args={[0.04, TOP - 1.2, 0.22]} />
      </mesh>

      {/* boom (can be raised for parked background cranes) */}
      <group position={[0, TOP + 0.25, -2.2]} rotation={[boomRaise, 0, 0]}>
        {[0.78, -0.78].map((x) => (
          <mesh key={x} material={m.paint} position={[x, 0, -4.6]} castShadow={shadows}>
            <boxGeometry args={[0.26, 0.6, 9.4]} />
          </mesh>
        ))}
        {Array.from({ length: 6 }).map((_, i) => (
          <mesh key={i} material={m.paint} position={[0, 0.28, -1 - i * 1.6]}>
            <boxGeometry args={[1.8, 0.08, 0.1]} />
          </mesh>
        ))}
        <mesh material={m.red} position={[0, 0.4, -9.3]}>
          <sphereGeometry args={[0.07, 10, 10]} />
        </mesh>
      </group>
      {/* backreach girders over the land */}
      {[0.78, -0.78].map((x) => (
        <mesh key={x} material={m.paint} position={[x, TOP + 0.25, 1.9]} castShadow={shadows}>
          <boxGeometry args={[0.26, 0.6, 8.2]} />
        </mesh>
      ))}
      {/* apex A-frame and stays */}
      {[3.2, -3.2].map((x) => (
        <group key={`a${x}`}>
          <Strut a={[x, TOP, 2.4]} b={[x * 0.3, TOP + 3.8, 1.0]} r={0.12} material={m.paint} />
          <Strut a={[x, TOP, -2.2]} b={[x * 0.3, TOP + 3.8, 1.0]} r={0.12} material={m.paint} />
          <Strut a={[x * 0.3, TOP + 3.8, 1.0]} b={[x * 0.25, TOP + 0.5, -11.5]} r={0.025} material={m.dark} />
          <Strut a={[x * 0.3, TOP + 3.8, 1.0]} b={[x * 0.25, TOP + 0.5, 5.8]} r={0.025} material={m.dark} />
        </group>
      ))}
      <mesh material={m.red} position={[0, TOP + 3.9, 1.0]}>
        <sphereGeometry args={[0.08, 10, 10]} />
      </mesh>
      {/* machinery house with Everlyn branding */}
      <group position={[0, TOP + 1.0, 4.4]}>
        <mesh material={m.paint} castShadow={shadows}>
          <boxGeometry args={[2.2, 1.1, 2.6]} />
        </mesh>
        <mesh material={m.emerald} position={[0, -0.25, 0]}>
          <boxGeometry args={[2.22, 0.36, 2.62]} />
        </mesh>
        {[1.112, -1.112].map((x) => (
          <mesh key={x} material={m.lettering} position={[x, -0.25, 0]} rotation={[0, x > 0 ? Math.PI / 2 : -Math.PI / 2, 0]}>
            <planeGeometry args={[2.3, 0.28]} />
          </mesh>
        ))}
        {Array.from({ length: 5 }).map((_, i) => (
          <mesh key={i} material={m.dark} position={[1.113, 0.22, -0.9 + i * 0.45]}>
            <boxGeometry args={[0.01, 0.3, 0.3]} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

/** The working ship-to-shore crane: gantry + trolley, operator cab, hoist ropes and spreader. */
export function Crane({ refs, shadows }: { refs: CraneRefs; shadows: boolean }) {
  const m = useCraneMaterials();
  const TOP = CRANE_TOP;
  return (
    <group ref={refs.root}>
      <CraneFrame shadows={shadows} />
      <group ref={refs.trolley}>
        <mesh material={m.paint} position={[0, TOP - 0.05, 0]} castShadow={shadows}>
          <boxGeometry args={[1.35, 0.32, 1.15]} />
        </mesh>
        {/* operator cab with glazing */}
        <group position={[0.95, TOP - 0.55, 0.25]}>
          <mesh material={m.paint} castShadow={shadows}>
            <boxGeometry args={[0.55, 0.55, 0.6]} />
          </mesh>
          <mesh material={m.glass} position={[0, -0.04, -0.302]}>
            <boxGeometry args={[0.5, 0.36, 0.01]} />
          </mesh>
          <mesh material={m.glass} position={[0, -0.28, 0]}>
            <boxGeometry args={[0.5, 0.01, 0.5]} />
          </mesh>
        </group>
        <group ref={refs.ropes}>
          {[
            [0.5, 0.35],
            [-0.5, 0.35],
            [0.5, -0.35],
            [-0.5, -0.35],
          ].map(([x, z]) => (
            <mesh key={`${x}${z}`} position={[x, -0.5, z]} material={m.dark}>
              <cylinderGeometry args={[0.013, 0.013, 1, 6]} />
            </mesh>
          ))}
        </group>
      </group>
      <group ref={refs.spreader}>
        <mesh material={m.spreader} castShadow={shadows}>
          <boxGeometry args={[2.42, 0.12, 0.34]} />
        </mesh>
        {[1.16, -1.16].map((x) => (
          <group key={x} position={[x, 0, 0]}>
            <mesh material={m.spreader} castShadow={shadows}>
              <boxGeometry args={[0.14, 0.16, 1.0]} />
            </mesh>
            {[0.45, -0.45].map((z) => (
              <mesh key={z} material={m.dark} position={[0, -0.1, z]}>
                <boxGeometry args={[0.06, 0.06, 0.06]} />
              </mesh>
            ))}
          </group>
        ))}
        <mesh material={m.dark} position={[0, 0.16, 0]} castShadow={shadows}>
          <boxGeometry args={[1.1, 0.2, 0.7]} />
        </mesh>
        {[0.5, -0.5].map((x) => (
          <mesh key={x} material={m.dark} position={[x, 0.28, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.1, 0.1, 0.08, 14]} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

/** Parked cranes further along the quay for depth. */
export function BackgroundCranes({ shadows }: { shadows: boolean }) {
  return (
    <>
      {[
        { x: -30, raise: -1.15 },
        { x: -52, raise: 0 },
      ].map((c) => (
        <group key={c.x} position={[c.x, 0, 0]}>
          <CraneFrame shadows={shadows} boomRaise={c.raise} />
        </group>
      ))}
    </>
  );
}

// ---------------------------------------------------------------------------
/** The client's warehouse at the end of the journey: clad in profiled steel, roller doors, warm interior. */
export function Warehouse({ shadows }: { shadows: boolean }) {
  const pbr = usePBR();
  const m = useMemo(() => {
    const clad = new THREE.MeshStandardMaterial({ color: "#e4ddcd", roughness: 0.55, metalness: 0.4, normalMap: pbr.containerYard.normalMap, roughnessMap: pbr.containerYard.roughnessMap });
    const roof = new THREE.MeshStandardMaterial({ color: "#1f5c47", roughness: 0.6, metalness: 0.3 });
    const door = new THREE.MeshStandardMaterial({ color: "#9aa09a", roughness: 0.5, metalness: 0.6 });
    const warm = new THREE.MeshBasicMaterial({ color: "#e7b56a", toneMapped: false });
    const wallGeo = corrugatedPanel(11, 5.2, 0.05, 0.3);
    const doorGeo = corrugatedPanel(2.8, 2.2, 0.025, 0.12).rotateZ(Math.PI / 2); // horizontal slats
    return { clad, roof, door, warm, wallGeo, doorGeo };
  }, [pbr]);
  return (
    <group position={[26.5, 0, 0.5]}>
      <mesh geometry={m.wallGeo} material={m.clad} position={[-5.05, 2.6, 0]} rotation={[0, -Math.PI / 2, 0]} castShadow={shadows} receiveShadow={shadows} />
      <mesh material={m.clad} position={[0, 2.6, 0]} castShadow={shadows}>
        <boxGeometry args={[10, 5.2, 11]} />
      </mesh>
      <mesh material={m.roof} position={[0, 5.35, 0]} castShadow={shadows}>
        <boxGeometry args={[10.4, 0.3, 11.4]} />
      </mesh>
      {[-3, 0, 3].map((z, i) => (
        <group key={z} position={[-5.12, 1.45, z]}>
          {i === 1 ? (
            <mesh material={m.warm} rotation={[0, -Math.PI / 2, 0]}>
              <planeGeometry args={[2.2, 2.8]} />
            </mesh>
          ) : (
            <mesh geometry={m.doorGeo} material={m.door} rotation={[0, -Math.PI / 2, 0]} />
          )}
        </group>
      ))}
      <pointLight position={[-6, 2.2, 0]} color="#ffcf88" intensity={6} distance={9} decay={1.6} />
    </group>
  );
}

// ---------------------------------------------------------------------------
const oceanVert = /* glsl */ `
  uniform float uTime;
  varying vec3 vWorld;
  varying vec3 vNormalW;
  varying float vCrest;
  #include <fog_pars_vertex>

  // Gerstner wave: returns displacement, accumulates tangent/binormal
  vec3 gerstner(vec4 w, vec3 p, inout vec3 tangent, inout vec3 binormal, inout float crest) {
    float steep = w.z;
    float k = 6.28318 / w.w;
    float c = sqrt(9.8 / k);
    vec2 d = normalize(w.xy);
    float f = k * (dot(d, p.xz) - c * uTime * 0.55);
    float a = steep / k;
    tangent += vec3(-d.x * d.x * steep * sin(f), d.x * steep * cos(f), -d.x * d.y * steep * sin(f));
    binormal += vec3(-d.x * d.y * steep * sin(f), d.y * steep * cos(f), -d.y * d.y * steep * sin(f));
    crest += sin(f) * steep;
    return vec3(d.x * a * cos(f), a * sin(f), d.y * a * cos(f));
  }

  void main() {
    vec3 p = (modelMatrix * vec4(position, 1.0)).xyz;
    vec3 tangent = vec3(1.0, 0.0, 0.0);
    vec3 binormal = vec3(0.0, 0.0, 1.0);
    float crest = 0.0;
    vec3 disp = vec3(0.0);
    disp += gerstner(vec4(1.0, 0.35, 0.10, 14.0), p, tangent, binormal, crest);
    disp += gerstner(vec4(-0.4, 1.0, 0.09, 9.0), p, tangent, binormal, crest);
    disp += gerstner(vec4(0.7, -0.6, 0.08, 5.5), p, tangent, binormal, crest);
    disp += gerstner(vec4(-0.9, -0.3, 0.06, 3.1), p, tangent, binormal, crest);
    p += disp;
    vWorld = p;
    vNormalW = normalize(cross(binormal, tangent));
    vCrest = crest;
    vec4 mvPosition = viewMatrix * vec4(p, 1.0);
    gl_Position = projectionMatrix * mvPosition;
    #include <fog_vertex>
  }
`;

const oceanFrag = /* glsl */ `
  ${SKY_GLSL}
  uniform sampler2D uRipples;
  uniform vec3 uKeyDir;
  uniform vec3 uKeyColor;
  varying vec3 vWorld;
  varying vec3 vNormalW;
  varying float vCrest;
  #include <fog_pars_fragment>

  vec2 ripple(vec2 uv) { return texture2D(uRipples, uv).xy * 2.0 - 1.0; }

  void main() {
    vec2 uv = vWorld.xz;
    vec2 r1 = ripple(uv * 0.21 + vec2(uTime * 0.018, uTime * 0.011));
    vec2 r2 = ripple(uv * 0.083 - vec2(uTime * 0.009, -uTime * 0.014));
    vec2 r3 = ripple(uv * 0.55 + vec2(-uTime * 0.03, uTime * 0.02));
    vec2 rp = r1 * 0.55 + r2 * 0.7 + r3 * 0.25;
    vec3 n = normalize(vNormalW + vec3(rp.x, 0.0, rp.y) * 0.32);

    vec3 v = normalize(cameraPosition - vWorld);
    float ndv = max(dot(n, v), 0.0);
    float fres = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);

    vec3 rd = reflect(-v, n);
    rd.y = abs(rd.y);
    vec3 refl = skyColor(rd);

    // water body: emerald by day, ink-blue at night, lit by whatever is in the sky
    vec3 bodyDay = vec3(0.012, 0.06, 0.052);
    vec3 bodyDusk = vec3(0.03, 0.025, 0.03);
    vec3 bodyNight = vec3(0.002, 0.005, 0.009);
    vec3 body = mix(mix(bodyDay, bodyDusk, uDusk), bodyNight, uNight);
    // light scattering through wave crests
    float sss = pow(max(dot(v, -uKeyDir), 0.0), 3.0) * max(vCrest, 0.0);
    body += vec3(0.02, 0.12, 0.09) * sss * (1.0 - uNight) * 2.0;

    vec3 col = mix(body, refl, fres);

    // sun / moon glitter path
    float spec = pow(max(dot(rd, uKeyDir), 0.0), mix(380.0, 160.0, uDusk));
    float sparkle = step(0.86, fract(sin(dot(floor(uv * 9.0), vec2(12.9898, 78.233))) * 43758.5453 + uTime * 0.6));
    col += uKeyColor * spec * (5.0 + sparkle * mix(10.0, 2.0, uNight));

    // foam on the crests
    float foamN = fbm(uv * 0.9 + uTime * 0.05);
    float foam = smoothstep(0.17, 0.3, vCrest + foamN * 0.12) * 0.55;
    vec3 foamCol = mix(vec3(0.85, 0.88, 0.86), vec3(0.95, 0.6, 0.45), uDusk) * mix(1.0, 0.04, uNight);
    col = mix(col, foamCol, foam);

    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
    #include <fog_fragment>
  }
`;

/** The sea: rolling Gerstner swell, drifting ripples, crest foam, a glitter path and live sky reflections. */
export function Ocean({ meshRef }: { meshRef: React.RefObject<THREE.Mesh | null> }) {
  const mat = useMemo(() => {
    const ripples = waterNormalTexture();
    return new THREE.ShaderMaterial({
      vertexShader: oceanVert,
      fragmentShader: oceanFrag,
      fog: true,
      uniforms: {
        ...THREE.UniformsUtils.clone(THREE.UniformsLib.fog),
        ...skyUniforms,
        uRipples: { value: ripples },
      },
    });
  }, []);
  // (sky uniforms are the same objects as the dome's, so they update together)
  return (
    <mesh ref={meshRef} material={mat} rotation={[-Math.PI / 2, 0, 0]} position={[0, WATER_Y, 0]}>
      <planeGeometry args={[300, 300, 220, 220]} />
    </mesh>
  );
}
