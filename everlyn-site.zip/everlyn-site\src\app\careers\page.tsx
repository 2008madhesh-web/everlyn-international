import type { Metadata } from "next";
import { PageHero, SectionHeading } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { Button } from "@/components/ui/Button";
import { careers, contact } from "@/content/site";

export const metadata: Metadata = {
  title: "Careers",
  description: "Join the Everlyn Internationals team in international sales, documentation, sourcing and quality.",
};

const perks = [
  { t: "Global exposure", d: "Work with buyers and suppliers across six continents from day one." },
  { t: "Real ownership", d: "Small teams, clear responsibilities and decisions you can see through." },
  { t: "Learn the trade", d: "Hands-on training in documentation, quality, logistics and negotiation." },
];

export default function CareersPage() {
  return (
    <>
      <PageHero
        eyebrow="Careers"
        title="Help us carry India to the world."
        intro="We're a growing team of traders, quality specialists and logistics people who care about getting the details right."
        crumbs={[{ label: "Careers" }]}
      />

      <section className="container-lux grid gap-10 pb-24 md:grid-cols-3">
        {perks.map((p, i) => (
          <Reveal key={p.t} delay={i * 0.08} className="border-t border-forest-deep/15 pt-6">
            <h2 className="display text-3xl text-forest-deep">{p.t}</h2>
            <p className="mt-3 text-ink/70">{p.d}</p>
          </Reveal>
        ))}
      </section>

      <section className="bg-parchment/60 py-24 md:py-32">
        <div className="container-lux">
          <SectionHeading eyebrow="Open positions" title="Current openings." />
          <ul className="mt-14 space-y-4">
            {careers.map((c, i) => (
              <Reveal as="li" key={c.title} delay={i * 0.07}>
                <div className="flex flex-col gap-6 rounded-[1.5rem] border border-forest-deep/10 bg-ivory p-8 md:flex-row md:items-center md:justify-between">
                  <div className="max-w-2xl">
                    <p className="eyebrow mb-2">{c.type}</p>
                    <h3 className="display text-3xl text-forest-deep">{c.title}</h3>
                    <p className="mt-2 text-sm text-ink/70">{c.body}</p>
                  </div>
                  <Button href={`mailto:${contact.careersEmail}?subject=${encodeURIComponent(`Application: ${c.title}`)}`} variant="outline" arrow external>
                    Apply
                  </Button>
                </div>
              </Reveal>
            ))}
          </ul>
          <p className="mt-10 text-ink/70">
            Don&rsquo;t see your role? Send your CV to{" "}
            <a href={`mailto:${contact.careersEmail}`} className="link-underline text-forest-deep">{contact.careersEmail}</a>.
          </p>
        </div>
      </section>
    </>
  );
}
