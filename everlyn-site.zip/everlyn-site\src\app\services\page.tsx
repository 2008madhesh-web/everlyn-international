import type { Metadata } from "next";
import { PageHero, SectionHeading } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { Icon } from "@/components/ui/Icon";
import { CtaBand } from "@/components/ui/CtaBand";
import { process, services } from "@/content/site";

export const metadata: Metadata = {
  title: "Services",
  description: "Export trade, import and procurement, sourcing, quality inspection, documentation, freight and private label services from India.",
};

const terms = [
  { k: "EXW", t: "Ex Works", d: "You collect from the supplier's premises and handle everything after that." },
  { k: "FOB", t: "Free On Board", d: "We deliver, clear export customs and load onto your vessel at the Indian port." },
  { k: "CFR", t: "Cost & Freight", d: "We also book and pay sea freight to your destination port." },
  { k: "CIF", t: "Cost, Insurance & Freight", d: "As CFR, plus marine cargo insurance for the voyage." },
  { k: "DDP", t: "Delivered Duty Paid", d: "We deliver to your door with import duties and clearance handled." },
];

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Our services"
        title="Everything between the source and your shelf."
        intro="Use us end to end, or only for the part you need: sourcing, inspection, documents or freight."
        crumbs={[{ label: "Services" }]}
      />

      <section className="container-lux pb-24 md:pb-32">
        <div className="grid gap-px overflow-hidden rounded-[2rem] border border-forest-deep/10 bg-forest-deep/10 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={(i % 4) * 0.06} className="group relative bg-ivory p-8 transition-colors duration-700 hover:bg-forest-deep">
              <Icon name={s.icon} className="h-8 w-8 text-brass transition-colors duration-700 group-hover:text-brass-light" />
              <h3 className="display mt-6 text-2xl text-forest-deep transition-colors duration-700 group-hover:text-ivory">{s.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-ink/65 transition-colors duration-700 group-hover:text-ivory/70">{s.body}</p>
              <ul className="mt-6 space-y-2 border-t border-forest-deep/10 pt-5 text-[0.82rem] text-ink/70 transition-colors duration-700 group-hover:border-ivory/15 group-hover:text-ivory/75">
                {s.points.map((pt) => (
                  <li key={pt} className="flex gap-2">
                    <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-brass" />
                    {pt}
                  </li>
                ))}
              </ul>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-forest-deep py-24 text-ivory md:py-32">
        <div className="container-lux">
          <SectionHeading light eyebrow="How it works" title="Six steps, one accountable team." />
          <ol className="mt-16 grid gap-px overflow-hidden rounded-[2rem] bg-ivory/10 md:grid-cols-3">
            {process.map((s, i) => (
              <Reveal as="li" key={s.step} delay={(i % 3) * 0.08} className="bg-forest-deep p-8 md:p-10">
                <span className="display text-6xl italic text-brass-light/80">{s.step}</span>
                <h3 className="display mt-6 text-3xl">{s.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-ivory/65">{s.body}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="container-lux py-24 md:py-32">
        <SectionHeading eyebrow="Incoterms" title="Buy on the terms that suit you." intro="We quote on all common Incoterms. Here's what each one means in practice." />
        <dl className="mt-14 border-t border-forest-deep/15">
          {terms.map((t, i) => (
            <Reveal key={t.k} delay={i * 0.05} y={12} className="grid gap-2 border-b border-forest-deep/15 py-7 md:grid-cols-12 md:items-baseline">
              <dt className="display text-4xl text-forest md:col-span-2">{t.k}</dt>
              <dd className="font-medium text-forest-deep md:col-span-3">{t.t}</dd>
              <dd className="text-ink/70 md:col-span-7">{t.d}</dd>
            </Reveal>
          ))}
        </dl>
      </section>

      <CtaBand />
    </>
  );
}
