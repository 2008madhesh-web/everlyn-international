﻿"use client";

import dynamic from "next/dynamic";
import { useCallback, useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { story } from "@/lib/story";
import { Loader } from "./Loader";
import { getLenis } from "../SmoothScroll";
import { Emblem } from "../Logo";
import {
  HeroFrame, OriginPanel, ProductsGallery, RegionsPanel, WhyPanel, ProcessPanel, DeliveredPanel, StoryProgress,
} from "./StoryPanels";

gsap.registerPlugin(ScrollTrigger);

const StoryCanvas = dynamic(() => import("../three/StoryCanvas"), { ssr: false });

let introPlayed = false;

function webglOK() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

/**
 * Each section has a height (vh) and the point in the 3D timeline (p) that should be
 * playing when the section locks into place. Scroll to p is mapped piecewise between
 * these anchors, so sections can be any length and still stay in sync with the scene.
 */
const SECTIONS = {
  origin: { h: 190, p: 0.13 },
  products: { h: 640, p: 0.31 }, // the sunset departure: one product per stage
  regions: { h: 140, p: 0.49 },
  why: { h: 130, p: 0.585 },
  process: { h: 210, p: 0.8 }, // night arrival and unloading
  delivered: { h: 130, p: 0.955 }, // container placed on the lorry: the end
};

export function HomeStory() {
  const wrap = useRef<HTMLDivElement>(null);
  const productsRef = useRef<HTMLElement>(null);
  const processRef = useRef<HTMLElement>(null);
  const [mode, setMode] = useState<"pending" | "3d" | "static">("pending");
  const [sceneReady, setSceneReady] = useState(false);
  const [showLoader, setShowLoader] = useState(!introPlayed);
  const [introDone, setIntroDone] = useState(introPlayed);

  // Decide between the 3D story and the static fallback once we're in the browser
  useEffect(() => {
    const id = requestAnimationFrame(() => {
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      const m = !reduce && webglOK() ? "3d" : "static";
      let skip = introPlayed || m === "static";
      if (process.env.NODE_ENV !== "production") {
        (window as unknown as { __story: typeof story }).__story = story;
        if (location.search.includes("nointro")) skip = true;
      }
      if (skip) {
        story.intro = 1;
        introPlayed = true;
        setShowLoader(false);
        setIntroDone(true);
      }
      setMode(m);
    });
    return () => cancelAnimationFrame(id);
  }, []);

  // Scroll position to story progress, anchored to each section
  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    story.target = 0;
    story.current = 0;
    let anchors: [number, number][] = [];
    const build = () => {
      const secs = Array.from(el.querySelectorAll<HTMLElement>("[data-p]"));
      anchors = secs.map((s) => [s.offsetTop, parseFloat(s.dataset.p!)]);
      anchors.push([el.offsetHeight - window.innerHeight, 1]);
    };
    const map = (y: number) => {
      if (!anchors.length) return 0;
      if (y <= anchors[0][0]) return anchors[0][1];
      for (let i = 0; i < anchors.length - 1; i++) {
        const [y0, p0] = anchors[i];
        const [y1, p1] = anchors[i + 1];
        if (y <= y1) return p0 + ((y - y0) / Math.max(1, y1 - y0)) * (p1 - p0);
      }
      return 1;
    };
    build();
    const st = ScrollTrigger.create({
      trigger: el,
      start: "top top",
      end: "bottom bottom",
      onRefresh: build,
      onUpdate: (self) => {
        story.target = map(self.scroll() - self.start);
      },
    });
    return () => st.kill();
  }, []);

  // Pointer parallax
  useEffect(() => {
    const move = (e: PointerEvent) => {
      story.pointerX = (e.clientX / window.innerWidth) * 2 - 1;
      story.pointerY = -((e.clientY / window.innerHeight) * 2 - 1);
    };
    window.addEventListener("pointermove", move);
    return () => window.removeEventListener("pointermove", move);
  }, []);

  // Lock scrolling while the loader plays
  useEffect(() => {
    if (introDone) return;
    const l = getLenis();
    l?.stop();
    document.documentElement.style.overflow = "hidden";
    return () => {
      getLenis()?.start();
      document.documentElement.style.overflow = "";
    };
  }, [introDone]);

  const onLoaderDone = useCallback(() => {
    setShowLoader(false);
    introPlayed = true;
    story.intro = 0;
    // the logo is now the paint on the container: hold a beat, then slowly pull back to reveal the cargo
    // the headline arrives only as the pull-back settles, never over the close-up
    let shown = false;
    gsap.to(story, {
      intro: 1,
      duration: 5.2,
      ease: "power2.inOut",
      delay: 0.2,
      onUpdate: () => {
        if (!shown && story.intro > 0.82) {
          shown = true;
          setIntroDone(true);
        }
      },
      onComplete: () => setIntroDone(true),
    });
  }, []);

  return (
    <>
      {mode === "3d" && <StoryCanvas onReady={() => setSceneReady(true)} />}
      {mode === "static" && <StaticBackdrop />}
      {showLoader && mode !== "static" && <Loader ready={sceneReady} onDone={onLoaderDone} />}

      <StoryProgress />

      <div ref={wrap} id="story" className="relative z-10">
        <section data-p={0} className="relative">
          <HeroFrame show={introDone} />
        </section>
        <Section {...SECTIONS.origin}>
          <OriginPanel />
        </Section>
        <Section {...SECTIONS.products} sectionRef={productsRef} bare>
          <ProductsGallery sectionRef={productsRef} />
        </Section>
        <Section {...SECTIONS.regions}>
          <RegionsPanel />
        </Section>
        <Section {...SECTIONS.why}>
          <WhyPanel />
        </Section>
        <Section {...SECTIONS.process} sectionRef={processRef}>
          <ProcessPanel sectionRef={processRef} />
        </Section>
        <Section {...SECTIONS.delivered}>
          <DeliveredPanel />
        </Section>
      </div>
    </>
  );
}

function Section({
  h, p, children, align, veil, bare, sectionRef,
}: {
  h: number;
  p: number;
  children: React.ReactNode;
  align?: "start";
  veil?: boolean;
  bare?: boolean;
  sectionRef?: React.RefObject<HTMLElement | null>;
}) {
  return (
    <section
      ref={sectionRef}
      data-p={p}
      className="relative md:[height:var(--h)]"
      style={{ ["--h" as string]: `${h}vh`, minHeight: bare ? undefined : `${Math.round(h * 0.6)}svh` }}
    >
      <div
        className={`relative flex md:sticky md:top-0 md:h-screen ${bare ? "items-center py-24 md:items-stretch md:py-0" : "min-h-[100svh]"} ${
          bare ? "" : align === "start" ? "items-end pb-14 md:items-center md:pb-0" : "items-end pb-10 md:items-center md:pb-0"
        }`}
      >
        {veil && (
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ivory from-30% via-ivory/60 via-50% to-transparent to-70% md:bg-gradient-to-r md:from-ivory/90 md:via-ivory/45 md:to-transparent"
          />
        )}
        {bare ? <div className="relative w-full">{children}</div> : <div className="container-lux relative w-full">{children}</div>}
      </div>
    </section>
  );
}

function StaticBackdrop() {
  return (
    <div aria-hidden className="fixed inset-0 overflow-hidden bg-gradient-to-br from-ivory via-parchment to-sand">
      <Emblem className="absolute -right-24 top-1/2 h-[42rem] w-[42rem] -translate-y-1/2 text-forest/10" strokeWidth={1} />
    </div>
  );
}
