/**
 * EVERLYN INTERNATIONALS — single source of truth for all site content.
 *
 * Anything marked `TODO` is a placeholder. Replace it with real details before launch.
 * Stats, testimonials and certifications are SAMPLE content written to show the layout:
 * swap in your real numbers, client quotes and registrations.
 */

export const company = {
  name: "Everlyn Internationals",
  shortName: "Everlyn",
  tagline: "From India's finest sources to the world's doorsteps.",
  description:
    "Everlyn Internationals is an India-based import and export house trading spices, grains, fresh produce, textiles, handicrafts and engineering goods with buyers across six continents.",
  url: "https://www.everlyninternationals.com", // TODO: real domain
  foundedLabel: "Est. in India", // TODO: e.g. "Est. 2014"
};

export const contact = {
  // TODO: replace every value below with real details
  addressLines: ["Everlyn Internationals", "Office address line 1", "City, State – PIN", "India"],
  mapQuery: "India", // TODO: your office address, used for the Google Maps embed
  phone: "+91 00000 00000",
  phoneHref: "tel:+910000000000",
  whatsapp: "910000000000", // digits only, with country code
  email: "info@everlyninternationals.com",
  salesEmail: "sales@everlyninternationals.com",
  careersEmail: "careers@everlyninternationals.com",
  hours: "Mon – Sat · 9:30 AM – 6:30 PM IST",
  iec: "IEC: XXXXXXXXXX", // TODO
  gst: "GSTIN: XXXXXXXXXXXXXXX", // TODO
};

export const socials = [
  { label: "LinkedIn", href: "#" }, // TODO
  { label: "Instagram", href: "#" }, // TODO
  { label: "Facebook", href: "#" }, // TODO
];

export const nav = [
  { label: "About", href: "/about" },
  { label: "Products", href: "/products" },
  { label: "Services", href: "/services" },
  { label: "Global Network", href: "/global-network" },
  { label: "Quality", href: "/quality" },
  { label: "Contact", href: "/contact" },
];

export const footerNav = {
  Company: [
    { label: "About us", href: "/about" },
    { label: "Quality & Compliance", href: "/quality" },
    { label: "Industries", href: "/industries" },
    { label: "Careers", href: "/careers" },
  ],
  Trade: [
    { label: "Products", href: "/products" },
    { label: "Services", href: "/services" },
    { label: "Global Network", href: "/global-network" },
    { label: "Request a Quote", href: "/quote" },
  ],
  Support: [
    { label: "Contact", href: "/contact" },
    { label: "FAQ", href: "/faq" },
    { label: "Privacy Policy", href: "/privacy" },
    { label: "Terms of Trade", href: "/terms" },
  ],
};

// SAMPLE numbers: replace with your real figures
export const stats = [
  { value: 35, suffix: "+", label: "Countries served" },
  { value: 2400, suffix: "+", label: "Containers shipped" },
  { value: 180, suffix: "+", label: "Trusted partners" },
  { value: 98.7, suffix: "%", label: "On-time delivery", decimals: 1 },
];

export type IconName =
  | "spice" | "grain" | "fruit" | "textile" | "craft" | "gear" | "ship" | "globe"
  | "shield" | "doc" | "box" | "truck" | "search" | "handshake" | "leaf" | "chart"
  | "store" | "factory" | "hotel" | "cart" | "anchor" | "compass";

export type Product = {
  slug: string;
  name: string;
  icon: IconName;
  short: string;
  intro: string;
  items: { name: string; note: string }[];
  specs: { label: string; value: string }[];
  packaging: string[];
};

export const products: Product[] = [
  {
    slug: "spices",
    name: "Spices & Seasonings",
    icon: "spice",
    short: "Whole and ground spices from Kerala, Rajasthan and Andhra Pradesh, steam-sterilised on request.",
    intro:
      "India grows more spice than any other nation. We buy direct from estates and auction centres, then clean, grade and pack every lot to your market's residue and moisture limits.",
    items: [
      { name: "Turmeric", note: "Fingers, bulbs & powder · 3–5% curcumin" },
      { name: "Black Pepper", note: "Malabar & Tellicherry grades, 500–600 g/l" },
      { name: "Green Cardamom", note: "Alleppey green, 6–8 mm bold" },
      { name: "Cumin Seed", note: "Singapore & Europe quality, 99% purity" },
      { name: "Red Chilli", note: "Teja, S17 & Byadgi · whole, crushed, powder" },
      { name: "Coriander, Cloves & Fennel", note: "Machine-cleaned, sortex optional" },
    ],
    specs: [
      { label: "Origin", value: "Kerala, Andhra Pradesh, Gujarat, Rajasthan" },
      { label: "Minimum order", value: "1 × 20 ft FCL (mixed loads possible)" },
      { label: "Lead time", value: "2–3 weeks from confirmed order" },
      { label: "Documents", value: "Phytosanitary, CoO, lab analysis, Spices Board" },
    ],
    packaging: ["25 / 50 kg PP or jute bags", "Kraft paper bags with liner", "Retail packs under your label"],
  },
  {
    slug: "rice-grains",
    name: "Rice, Grains & Pulses",
    icon: "grain",
    short: "Aged basmati, non-basmati staples, millets and pulses, milled and sorted to export grade.",
    intro:
      "From long-grain basmati aged for twelve months to everyday sona masoori, our rice is milled, sortexed and fumigated in accredited facilities, with grain-length reports for every lot.",
    items: [
      { name: "1121 Basmati", note: "Steam, sella & white · 8.3 mm+ average length" },
      { name: "1509 & Pusa Basmati", note: "Aged, low broken percentage" },
      { name: "Sona Masoori & IR64", note: "Raw & parboiled, 5–25% broken" },
      { name: "Wheat & Maize", note: "Milling and feed grades" },
      { name: "Millets", note: "Foxtail, pearl, finger & sorghum" },
      { name: "Pulses", note: "Chickpeas, lentils, pigeon peas, mung beans" },
    ],
    specs: [
      { label: "Origin", value: "Punjab, Haryana, Andhra Pradesh, Madhya Pradesh" },
      { label: "Minimum order", value: "1 × 20 ft FCL (approx. 25 MT)" },
      { label: "Lead time", value: "2–4 weeks" },
      { label: "Documents", value: "APEDA, phytosanitary, fumigation, CoO, SGS on request" },
    ],
    packaging: ["5 – 50 kg BOPP & non-woven bags", "Jute bags", "Private-label consumer packs"],
  },
  {
    slug: "fresh-produce",
    name: "Fresh Fruits & Vegetables",
    icon: "fruit",
    short: "Onions, grapes, pomegranates and mangoes shipped in temperature-controlled reefers.",
    intro:
      "Fresh produce lives or dies by the cold chain. We pre-cool at pack houses, load reefers with data loggers and book routes with the shortest transit time to your port.",
    items: [
      { name: "Red & Pink Onions", note: "Nashik origin, 40–80 mm" },
      { name: "Table Grapes", note: "Thompson seedless, Sharad & Flame" },
      { name: "Pomegranates", note: "Bhagwa variety, export-graded by count" },
      { name: "Mangoes", note: "Alphonso, Kesar & Banganapalli in season" },
      { name: "Bananas", note: "Cavendish G9, 13 kg cartons" },
      { name: "Green Chilli, Lemons & Okra", note: "Air and sea freight" },
    ],
    specs: [
      { label: "Origin", value: "Maharashtra, Gujarat, Karnataka" },
      { label: "Minimum order", value: "1 × 40 ft reefer" },
      { label: "Lead time", value: "Seasonal · 7–14 days in season" },
      { label: "Documents", value: "Phytosanitary, GlobalG.A.P. farms, residue reports" },
    ],
    packaging: ["Ventilated corrugated cartons", "Mesh bags for onions", "Pallet-ready with corner boards"],
  },
  {
    slug: "textiles",
    name: "Textiles & Apparel",
    icon: "textile",
    short: "Cotton yarn, woven fabrics, home textiles and garments from India's textile clusters.",
    intro:
      "We work with mills and garment units in Tiruppur, Surat, Ludhiana and Panipat, so you get one point of contact from yarn to finished, labelled garments.",
    items: [
      { name: "Cotton Yarn", note: "Combed & carded, Ne 10s – 60s" },
      { name: "Woven & Knitted Fabric", note: "Cotton, viscose, linen blends" },
      { name: "Home Textiles", note: "Bed linen, towels, curtains, table linen" },
      { name: "Garments", note: "T-shirts, shirts, workwear, kidswear" },
      { name: "Organic Cotton", note: "GOTS-certified supply chains" },
      { name: "Rugs & Durries", note: "Panipat flat-weaves and handlooms" },
    ],
    specs: [
      { label: "Origin", value: "Tamil Nadu, Gujarat, Punjab, Haryana" },
      { label: "Minimum order", value: "From 1,000 pieces / 1 MT yarn" },
      { label: "Lead time", value: "4–8 weeks including sampling" },
      { label: "Documents", value: "Test reports, OEKO-TEX / GOTS where applicable" },
    ],
    packaging: ["Polybagged & cartoned by size ratio", "Hanger packs on request", "Bales for yarn"],
  },
  {
    slug: "handicrafts",
    name: "Handicrafts & Home Décor",
    icon: "craft",
    short: "Brassware, woodcraft, marble and terracotta made by artisan clusters across India.",
    intro:
      "Each piece is made by hand, so we check it by hand too. Our team inspects finish, weight and packaging strength before anything leaves the workshop.",
    items: [
      { name: "Brass & Metalware", note: "Moradabad décor, lamps, tableware" },
      { name: "Wooden Furniture & Décor", note: "Sheesham, mango wood, acacia" },
      { name: "Marble & Stone", note: "Inlay work, coasters, sculpture" },
      { name: "Terracotta & Ceramics", note: "Planters, vases, kitchenware" },
      { name: "Handloom Throws", note: "Cotton, wool & jute weaves" },
      { name: "Gift Collections", note: "Curated corporate and festive sets" },
    ],
    specs: [
      { label: "Origin", value: "Uttar Pradesh, Rajasthan, Gujarat" },
      { label: "Minimum order", value: "From 200 pieces per design" },
      { label: "Lead time", value: "5–10 weeks" },
      { label: "Documents", value: "Fumigation for wood, CoO, product photos per lot" },
    ],
    packaging: ["5-ply export cartons", "Foam & honeycomb protection", "Gift boxes under your brand"],
  },
  {
    slug: "industrial",
    name: "Industrial & Engineering Goods",
    icon: "gear",
    short: "Castings, forgings, pumps, valves, fasteners and auto components made to drawing.",
    intro:
      "We connect you with audited Indian manufacturers working to ISO, ASTM and DIN standards, and manage drawings, samples, inspection and dispatch from one desk.",
    items: [
      { name: "Castings & Forgings", note: "Grey/SG iron, steel, aluminium" },
      { name: "Pumps & Valves", note: "Agricultural and industrial ranges" },
      { name: "Fasteners", note: "Stainless & alloy steel, DIN/ISO" },
      { name: "Auto Components", note: "Aftermarket and OEM parts" },
      { name: "Hand & Power Tools", note: "Professional-grade tooling" },
      { name: "Electrical Goods", note: "Cables, switchgear, motors" },
    ],
    specs: [
      { label: "Origin", value: "Gujarat, Maharashtra, Punjab, Tamil Nadu" },
      { label: "Minimum order", value: "Per drawing / per SKU" },
      { label: "Lead time", value: "4–10 weeks including PPAP / samples" },
      { label: "Documents", value: "Material test certificates, dimensional reports" },
    ],
    packaging: ["Wooden crates & pallets (ISPM-15)", "VCI wrapping for rust protection", "Bulk or kitted"],
  },
];

export const services: { title: string; icon: IconName; body: string; points: string[] }[] = [
  {
    title: "Export Trade",
    icon: "ship",
    body: "We ship Indian goods to buyers worldwide, handling the whole order from contract to delivery.",
    points: ["FOB, CFR, CIF and DDP terms", "LC, DP and advance payment structures", "Single or mixed-category containers"],
  },
  {
    title: "Import & Procurement",
    icon: "anchor",
    body: "We bring machinery, raw materials and consumer goods into India for manufacturers and distributors.",
    points: ["Supplier discovery and negotiation", "Customs clearance and duty planning", "Door delivery anywhere in India"],
  },
  {
    title: "Global Sourcing",
    icon: "search",
    body: "Tell us what you need and we find, audit and qualify the right manufacturer for it.",
    points: ["Factory audits and capability checks", "Sampling and price benchmarking", "Ongoing supplier management"],
  },
  {
    title: "Quality Inspection",
    icon: "shield",
    body: "We inspect before shipment, during loading, and with lab tests, so you don't pay for surprises.",
    points: ["AQL-based pre-shipment inspection", "Loading supervision with photos", "Third-party labs: SGS, Intertek, Bureau Veritas"],
  },
  {
    title: "Documentation & Customs",
    icon: "doc",
    body: "Every certificate, licence and declaration prepared correctly the first time.",
    points: ["Commercial invoice, packing list, CoO", "Phytosanitary, fumigation, health certificates", "DGFT incentives and compliance"],
  },
  {
    title: "Freight & Logistics",
    icon: "truck",
    body: "Sea, air and multimodal freight booked with carriers we trust, then tracked to your door.",
    points: ["FCL, LCL and reefer bookings", "Marine cargo insurance", "Live milestone updates"],
  },
  {
    title: "Private Label & Packaging",
    icon: "box",
    body: "Your brand on the shelf: we develop packaging that meets your market's labelling rules.",
    points: ["Design and printing coordination", "Retail-ready and bulk formats", "Barcodes and multilingual labels"],
  },
  {
    title: "Trade Advisory",
    icon: "compass",
    body: "Market entry advice for first-time importers and growing brands.",
    points: ["Landed-cost calculations", "Regulatory requirements by country", "Incoterm and payment-risk guidance"],
  },
];

export const originPorts = ["Nhava Sheva (JNPT)", "Mundra", "Chennai", "Tuticorin", "Cochin", "Kolkata"];

export const regions = [
  { name: "Europe", ports: ["Rotterdam", "Hamburg", "Antwerp", "Felixstowe"], transit: "18–24 days" },
  { name: "Middle East", ports: ["Jebel Ali", "Dammam", "Hamad", "Salalah"], transit: "4–9 days" },
  { name: "North America", ports: ["New York / NJ", "Savannah", "Houston", "Montreal"], transit: "28–35 days" },
  { name: "Southeast Asia", ports: ["Singapore", "Port Klang", "Laem Chabang", "Ho Chi Minh"], transit: "7–12 days" },
  { name: "Africa", ports: ["Durban", "Mombasa", "Lagos", "Djibouti"], transit: "12–22 days" },
  { name: "Oceania", ports: ["Sydney", "Melbourne", "Auckland"], transit: "20–26 days" },
];

/** Lat/lon used by the 3D globe. `from` is always the Indian origin port. */
export const globeRoutes = {
  origin: { name: "Nhava Sheva", lat: 18.95, lon: 72.95 },
  hero: { name: "Rotterdam", lat: 51.95, lon: 4.14 },
  others: [
    { name: "Jebel Ali", lat: 25.01, lon: 55.06 },
    { name: "New York", lat: 40.68, lon: -74.04 },
    { name: "Singapore", lat: 1.26, lon: 103.84 },
    { name: "Durban", lat: -29.87, lon: 31.03 },
    { name: "Sydney", lat: -33.86, lon: 151.2 },
    { name: "Hamburg", lat: 53.54, lon: 9.97 },
    { name: "Mombasa", lat: -4.04, lon: 39.67 },
    { name: "Santos", lat: -23.96, lon: -46.33 },
  ],
};

export const whyUs: { title: string; icon: IconName; body: string }[] = [
  { title: "Verified at the source", icon: "leaf", body: "Every farm, mill and factory we buy from is visited and audited by our team." },
  { title: "Export-grade packaging", icon: "box", body: "Packed for the voyage and for your shelf, to your market's labelling rules." },
  { title: "Paperwork, handled", icon: "doc", body: "Certificates, customs and compliance prepared right the first time." },
  { title: "You always know where it is", icon: "compass", body: "Milestone updates from loading to arrival, with photos at every stage." },
];

export const process: { step: string; title: string; body: string }[] = [
  { step: "01", title: "Enquiry & Sourcing", body: "We understand your specification, then shortlist and sample from qualified suppliers." },
  { step: "02", title: "Quality Control", body: "Lab tests and AQL inspections confirm every lot matches the approved sample." },
  { step: "03", title: "Packing & Labelling", body: "Packed for the route and climate, labelled for your market and brand." },
  { step: "04", title: "Documentation", body: "Invoices, certificates of origin, phytosanitary and customs filings, all prepared in-house." },
  { step: "05", title: "Shipping", body: "Booked with reliable carriers, insured, and tracked from gate-in to discharge." },
  { step: "06", title: "Delivery & Support", body: "Clearance support at destination and a team that stays with you after delivery." },
];

// SAMPLE testimonials: replace with real client quotes (with their permission)
export const testimonials = [
  {
    quote:
      "Consistent quality across every container, and documents that clear customs without a single query. Everlyn has become our first call for Indian spices.",
    who: "Procurement Director",
    org: "Food ingredients distributor · Netherlands",
  },
  {
    quote:
      "They found us a new rice supplier, inspected the first three lots themselves and kept us updated at every port. That level of care is rare.",
    who: "Head of Purchasing",
    org: "Wholesale importer · United Arab Emirates",
  },
  {
    quote:
      "Our private-label textile range launched on time across forty stores. Sampling, testing and shipping were handled from one desk.",
    who: "Sourcing Manager",
    org: "Home & lifestyle retailer · United Kingdom",
  },
];

// TODO: confirm each registration / certificate actually held before publishing
export const certifications = [
  { name: "IEC", by: "DGFT, Government of India" },
  { name: "APEDA", by: "Registered exporter" },
  { name: "Spices Board", by: "Certificate of registration" },
  { name: "FIEO", by: "Member" },
  { name: "FSSAI", by: "Food safety licence" },
  { name: "ISO 9001:2015", by: "Quality management" },
];

export const industries: { title: string; icon: IconName; body: string; needs: string[] }[] = [
  { title: "Importers & Distributors", icon: "anchor", body: "Steady, consistent supply for wholesalers who serve their own networks.", needs: ["Consistent grades", "Mixed containers", "Credit-friendly terms"] },
  { title: "Retail & Supermarkets", icon: "cart", body: "Retail-ready private-label products with full compliance for shelf.", needs: ["Private label", "Barcoding", "Shelf-life planning"] },
  { title: "Food Processing", icon: "factory", body: "Ingredients made to specification for manufacturers and blenders.", needs: ["Lab-tested lots", "Sterilised spices", "Long-term contracts"] },
  { title: "Hospitality & HoReCa", icon: "hotel", body: "Premium staples, linen and décor for hotels, restaurants and caterers.", needs: ["Premium grades", "Linen & décor", "Scheduled deliveries"] },
  { title: "Manufacturing & OEM", icon: "gear", body: "Engineering components made to drawing by audited Indian factories.", needs: ["Drawings & PPAP", "Dimensional reports", "Rust-proof packing"] },
  { title: "E-commerce Brands", icon: "store", body: "Small-batch, high-variety sourcing for direct-to-consumer brands.", needs: ["Low MOQs", "Branded packaging", "Fast sampling"] },
];

export const values = [
  { title: "Integrity", body: "We quote honestly, ship what we promise and tell you early when something changes." },
  { title: "Craft", body: "We treat every lot like it carries our name, because it does." },
  { title: "Partnership", body: "We build relationships that last for decades, not single transactions." },
  { title: "Responsibility", body: "We favour suppliers who pay fairly and farm and manufacture responsibly." },
];

export const milestones = [
  { title: "The beginning", body: "Everlyn Internationals is founded with a simple idea: Indian quality, delivered with global standards of service." },
  { title: "First container", body: "Our first full container of spices sails from Nhava Sheva to the Middle East." },
  { title: "Beyond spices", body: "We add rice, textiles and handicrafts, building a network of audited suppliers across India." },
  { title: "Six continents", body: "Buyers in Europe, the Americas, Africa, Asia and Oceania now receive regular Everlyn shipments." },
  { title: "Two-way trade", body: "We launch import and procurement services, bringing global goods into India." },
];

export const faqs = [
  { q: "What is your minimum order quantity?", a: "For most agro products it is one 20 ft container (around 18–26 MT depending on the product). Handicrafts and textiles start from a few hundred pieces per design. Mixed-category containers are possible." },
  { q: "Which Incoterms do you work with?", a: "We quote EXW, FOB, CFR, CIF and DDP. Most buyers choose FOB or CIF. We'll recommend what suits your market and your experience with imports." },
  { q: "What payment terms do you accept?", a: "Typical terms are an advance followed by payment against documents, or an irrevocable Letter of Credit at sight. Long-term partners can discuss other structures." },
  { q: "Can I get samples before ordering?", a: "Yes. We send pre-shipment-quality samples by courier. Sample costs are usually adjusted against your first order." },
  { q: "How do you guarantee quality?", a: "Every lot is inspected against the approved sample. Where required we use independent labs such as SGS, Intertek or Bureau Veritas, and you get photos and reports before the container is sealed." },
  { q: "How long does shipping take?", a: "Transit from India is roughly 4–9 days to the Gulf, 7–12 days to Southeast Asia, 18–24 days to Europe and 28–35 days to North America, plus 1–4 weeks of production depending on the product." },
  { q: "Do you handle export documentation?", a: "Yes. We prepare the invoice, packing list, certificate of origin, phytosanitary and fumigation certificates, health certificates and any market-specific documents." },
  { q: "Can you pack under our own brand?", a: "Yes. We coordinate design, printing and labelling so products arrive retail-ready under your brand and comply with your country's labelling rules." },
  { q: "Do you also import into India?", a: "Yes. Our import desk sources machinery, raw materials and consumer goods for Indian businesses and handles customs clearance and delivery." },
  { q: "How do I start?", a: "Send us a quote request with the product, quantity and destination. We usually respond within one business day with a quotation or a few clarifying questions." },
];

export const careers = [
  { title: "International Sales Executive", type: "Full-time · On-site", body: "Build relationships with importers in Europe and the Gulf, and turn enquiries into lasting accounts." },
  { title: "Export Documentation Officer", type: "Full-time · On-site", body: "Own the paperwork for every shipment: invoices, certificates, customs filings and bank documents." },
  { title: "Sourcing & Quality Manager", type: "Full-time · Travel", body: "Audit suppliers, approve samples and oversee pre-shipment inspections across India." },
];
