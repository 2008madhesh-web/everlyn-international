import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { Accordion } from "@/components/ui/Accordion";
import { CtaBand } from "@/components/ui/CtaBand";
import { faqs } from "@/content/site";

export const metadata: Metadata = {
  title: "FAQ",
  description: "Answers about minimum orders, Incoterms, payment terms, samples, quality and shipping times with Everlyn Internationals.",
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
};

export default function FaqPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />
      <PageHero eyebrow="Questions & answers" title="Everything you'd like to know before you ship." crumbs={[{ label: "FAQ" }]} />
      <section className="container-lux pb-12">
        <Accordion items={faqs} />
      </section>
      <CtaBand title="Still have a question?" body="Write to us or call. A member of our trade team will get back to you within one business day." />
    </>
  );
}
