import type { Metadata } from "next";
import { LegalPage } from "@/components/ui/LegalPage";
import { company, contact } from "@/content/site";

export const metadata: Metadata = { title: "Privacy Policy" };

// TODO: have this template reviewed by your legal adviser before launch.
export default function PrivacyPage() {
  return (
    <LegalPage
      title="Privacy Policy"
      updated="November 2026"
      sections={[
        {
          h: "Who we are",
          p: [`${company.name} ("we", "us") is an import and export company based in India. This policy explains how we handle personal information collected through this website.`],
        },
        {
          h: "Information we collect",
          p: [
            "When you submit our contact or quote forms we collect the details you provide: your name, company, email address, phone number, country and the content of your enquiry.",
            "Like most websites, our hosting provider may record basic technical data such as your IP address, browser type and the pages you visit, for security and performance purposes.",
          ],
        },
        {
          h: "How we use it",
          p: [
            "We use your information only to respond to your enquiry, prepare quotations, carry out orders and keep you informed about shipments you are involved in.",
            "We do not sell your personal information, and we do not use it for unrelated marketing without your consent.",
          ],
        },
        {
          h: "Sharing",
          p: [
            "Where needed to fulfil an order we may share relevant details with suppliers, inspection agencies, freight forwarders, shipping lines, banks and customs authorities. Each receives only what is required for their part of the shipment.",
          ],
        },
        {
          h: "Retention & security",
          p: [
            "We keep enquiry and trade records for as long as needed for business, tax and legal purposes, and protect them with reasonable technical and organisational measures.",
          ],
        },
        {
          h: "Your rights",
          p: [
            `You may ask us to access, correct or delete your personal information at any time by writing to ${contact.email}. We will respond within a reasonable period, in line with applicable law including India's Digital Personal Data Protection Act, 2023.`,
          ],
        },
        {
          h: "Contact",
          p: [`Questions about this policy can be sent to ${contact.email}.`],
        },
      ]}
    />
  );
}
