"use client";

import { useMemo } from "react";
import { RoundedBox } from "@react-three/drei";
import * as THREE from "three";
import { tyreGeometry } from "./geometry";

const BED_TOP = 0.78; // container bottom sits here (TRUCK_C - 0.5)
const R = 0.24;

function Wheel({ x, z, dual, m }: { x: number; z: number; dual?: boolean; m: ReturnType<typeof useTruckMaterials> }) {
  const s = Math.sign(z);
  return (
    <group position={[x, R, z]}>
      <mesh geometry={m.tyre} material={m.rubber} castShadow />
      <mesh material={m.rim} position={[0, 0, s * 0.045]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[R * 0.6, R * 0.6, 0.02, 20]} />
      </mesh>
      <mesh material={m.hub} position={[0, 0, s * 0.058]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[R * 0.2, R * 0.24, 0.03, 12]} />
      </mesh>
      {dual && <mesh geometry={m.tyre} material={m.rubber} position={[0, 0, -s * 0.1]} />}
    </group>
  );
}

function useTruckMaterials() {
  return useMemo(
    () => ({
      tyre: tyreGeometry(R, 0.09),
      rubber: new THREE.MeshStandardMaterial({ color: "#151514", roughness: 0.92 }),
      rim: new THREE.MeshStandardMaterial({ color: "#c7c2b6", roughness: 0.25, metalness: 1 }),
      hub: new THREE.MeshStandardMaterial({ color: "#5f625d", roughness: 0.4, metalness: 0.9 }),
      cab: new THREE.MeshPhysicalMaterial({ color: "#f2eee6", roughness: 0.25, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.08 }),
      stripe: new THREE.MeshPhysicalMaterial({ color: "#1f5c47", roughness: 0.3, clearcoat: 1 }),
      glass: new THREE.MeshPhysicalMaterial({ color: "#16201f", roughness: 0.03, metalness: 0.4, envMapIntensity: 2 }),
      chrome: new THREE.MeshStandardMaterial({ color: "#e4e0d6", roughness: 0.12, metalness: 1 }),
      chassis: new THREE.MeshStandardMaterial({ color: "#23262a", roughness: 0.55, metalness: 0.6 }),
      grille: new THREE.MeshStandardMaterial({ color: "#121413", roughness: 0.5, metalness: 0.6 }),
      head: new THREE.MeshStandardMaterial({ color: "#fff8e8", emissive: "#fff1cf", emissiveIntensity: 1.2, toneMapped: false }),
      tail: new THREE.MeshStandardMaterial({ color: "#c41f14", emissive: "#ff2a14", emissiveIntensity: 1.4, toneMapped: false }),
      amber: new THREE.MeshStandardMaterial({ color: "#e08a16", emissive: "#d97a0b", emissiveIntensity: 0.6 }),
    }),
    [],
  );
}

/** Tractor unit and skeletal 20 ft container trailer. Cab faces +x. */
export function Truck({ groupRef, shadows }: { groupRef: React.RefObject<THREE.Group | null>; shadows: boolean }) {
  const m = useTruckMaterials();
  return (
    <group ref={groupRef}>
      {/* --- skeletal trailer --- */}
      {[0.3, -0.3].map((z) => (
        <mesh key={z} material={m.chassis} position={[0.05, BED_TOP - 0.07, z]} castShadow={shadows}>
          <boxGeometry args={[2.6, 0.14, 0.08]} />
        </mesh>
      ))}
      {[-1.2, -0.6, 0, 0.6, 1.2].map((x) => (
        <mesh key={x} material={m.chassis} position={[x, BED_TOP - 0.05, 0]}>
          <boxGeometry args={[0.07, 0.1, 0.98]} />
        </mesh>
      ))}
      {/* twist-locks */}
      {[1.17, -1.17].map((x) => [0.45, -0.45].map((z) => (
        <mesh key={`${x}${z}`} material={m.rim} position={[x, BED_TOP + 0.01, z]}>
          <boxGeometry args={[0.06, 0.03, 0.06]} />
        </mesh>
      )))}
      {/* gooseneck to the fifth wheel */}
      <mesh material={m.chassis} position={[1.42, BED_TOP - 0.02, 0]}>
        <boxGeometry args={[0.36, 0.1, 0.7]} />
      </mesh>
      {/* landing legs */}
      {[0.32, -0.32].map((z) => (
        <mesh key={z} material={m.chassis} position={[0.95, 0.4, z]}>
          <boxGeometry args={[0.05, 0.62, 0.05]} />
        </mesh>
      ))}
      {/* rear bumper + tail lights */}
      <mesh material={m.chassis} position={[-1.28, 0.42, 0]}>
        <boxGeometry args={[0.05, 0.08, 0.96]} />
      </mesh>
      {[0.38, -0.38].map((z) => (
        <mesh key={z} material={m.tail} position={[-1.31, 0.5, z]}>
          <boxGeometry args={[0.02, 0.06, 0.16]} />
        </mesh>
      ))}
      {/* mudguards */}
      {[0.5, -0.5].map((z) => (
        <mesh key={z} material={m.chassis} position={[-0.65, 0.53, z]}>
          <boxGeometry args={[1.0, 0.02, 0.12]} />
        </mesh>
      ))}
      {[-0.95, -0.65, -0.35].map((x) => [0.43, -0.43].map((z) => <Wheel key={`${x}${z}`} x={x} z={z} dual m={m} />))}

      {/* --- tractor unit --- */}
      <mesh material={m.chassis} position={[2.05, 0.42, 0]} castShadow={shadows}>
        <boxGeometry args={[1.9, 0.16, 0.62]} />
      </mesh>
      <mesh material={m.chassis} position={[1.5, 0.55, 0]}>
        <cylinderGeometry args={[0.24, 0.24, 0.05, 20]} />
      </mesh>
      <group position={[2.62, 0, 0]}>
        <RoundedBox args={[0.78, 0.98, 0.94]} radius={0.06} smoothness={4} position={[0, 1.06, 0]} material={m.cab} castShadow={shadows} receiveShadow={shadows} />
        {/* emerald livery stripe */}
        <mesh material={m.stripe} position={[0, 0.78, 0]}>
          <boxGeometry args={[0.785, 0.07, 0.945]} />
        </mesh>
        {/* windscreen and side windows */}
        <mesh material={m.glass} position={[0.392, 1.3, 0]} rotation={[0, 0, 0.06]}>
          <boxGeometry args={[0.012, 0.36, 0.84]} />
        </mesh>
        {[0.472, -0.472].map((z) => (
          <mesh key={z} material={m.glass} position={[0.16, 1.3, z]}>
            <boxGeometry args={[0.38, 0.3, 0.01]} />
          </mesh>
        ))}
        {/* sun visor */}
        <mesh material={m.cab} position={[0.42, 1.53, 0]}>
          <boxGeometry args={[0.1, 0.04, 0.9]} />
        </mesh>
        {/* grille with chrome bars */}
        <mesh material={m.grille} position={[0.395, 0.86, 0]}>
          <boxGeometry args={[0.01, 0.28, 0.6]} />
        </mesh>
        {[0.78, 0.84, 0.9, 0.96].map((y) => (
          <mesh key={y} material={m.chrome} position={[0.401, y, 0]}>
            <boxGeometry args={[0.006, 0.012, 0.58]} />
          </mesh>
        ))}
        {/* headlights, indicators, bumper */}
        {[0.36, -0.36].map((z) => (
          <group key={z}>
            <mesh material={m.head} position={[0.396, 0.66, z]}>
              <boxGeometry args={[0.01, 0.07, 0.14]} />
            </mesh>
            <mesh material={m.amber} position={[0.396, 0.66, z * 1.22]}>
              <boxGeometry args={[0.01, 0.05, 0.04]} />
            </mesh>
          </group>
        ))}
        <mesh material={m.chassis} position={[0.42, 0.5, 0]}>
          <boxGeometry args={[0.08, 0.14, 0.98]} />
        </mesh>
        {/* mirrors */}
        {[1, -1].map((s) => (
          <group key={s} position={[0.35, 1.25, s * 0.55]}>
            <mesh material={m.chassis} rotation={[s * 0.6, 0, 0]} position={[0, 0, -s * 0.04]}>
              <boxGeometry args={[0.02, 0.02, 0.12]} />
            </mesh>
            <mesh material={m.chassis}>
              <boxGeometry args={[0.04, 0.2, 0.06]} />
            </mesh>
          </group>
        ))}
      </group>
      {/* fuel tanks and exhaust stack */}
      {[0.4, -0.4].map((z) => (
        <mesh key={z} material={m.chrome} position={[2.39, 0.38, z]} rotation={[0, 0, Math.PI / 2]} castShadow={shadows}>
          <cylinderGeometry args={[0.12, 0.12, 0.34, 20]} />
        </mesh>
      ))}
      <mesh material={m.chrome} position={[2.16, 1.25, 0.4]}>
        <cylinderGeometry args={[0.035, 0.035, 1.0, 12]} />
      </mesh>
      <Wheel x={2.85} z={0.43} m={m} />
      <Wheel x={2.85} z={-0.43} m={m} />
      <Wheel x={1.65} z={0.43} dual m={m} />
      <Wheel x={1.65} z={-0.43} dual m={m} />
      <Wheel x={1.95} z={0.43} dual m={m} />
      <Wheel x={1.95} z={-0.43} dual m={m} />
    </group>
  );
}
