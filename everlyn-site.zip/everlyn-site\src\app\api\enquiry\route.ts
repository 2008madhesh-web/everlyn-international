import { enquirySchema } from "@/lib/enquiry";

/**
 * Receives contact and quote form submissions.
 *
 * TODO: connect an email provider (e.g. Resend, SendGrid or SMTP) or a CRM here so
 * enquiries reach your inbox. For now they are validated and written to the server log.
 */
export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request" }, { status: 400 });
  }

  const parsed = enquirySchema.safeParse(body);
  if (!parsed.success) {
    return Response.json({ ok: false, error: "Please check the form and try again.", issues: parsed.error.issues.map((i) => ({ path: i.path, message: i.message })) }, { status: 422 });
  }

  // Honeypot: silently accept bots without processing
  if (parsed.data.website) return Response.json({ ok: true });

  const ref = `EV-${Date.now().toString(36).toUpperCase()}`;
  console.log(`[enquiry ${ref}]`, JSON.stringify(parsed.data));

  return Response.json({ ok: true, ref });
}
