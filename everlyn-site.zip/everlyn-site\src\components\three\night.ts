/** 0 = daylight, 1 = full night. Written by the scene each frame, read by lamps and windows. */
export const night = { value: 0 };
