"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { drawLogoText, LOGO_CANVAS, LOGO_COLOR } from "../three/textures";

const OUTLINE = "M0 0 C 11 -10, 13 -27, 0 -40 C -13 -27, -11 -10, 0 0 Z";
const HALF = "M0 -4 C -8 -12, -9.5 -25, 0 -36 Z";

// top, right, bottom, left: one petal at a time
const PETALS = [
  { r: 0, filled: true },
  { r: 90, filled: false },
  { r: 180, filled: true },
  { r: 270, filled: false },
];
const FIRST = 0.35;
const GAP = 0.5;
const PETAL_DUR = 1.1;
const BLOOM_END = FIRST + (PETALS.length - 1) * GAP + PETAL_DUR;
const NAME_AT = BLOOM_END + 0.15;
const SUB_AT = NAME_AT + 0.7;
const MIN_SHOW = (SUB_AT + 1.6) * 1000;

const { emblem } = LOGO_CANVAS;
// emblem centre as a percentage of the logo box, so each petal grows out of the heart of the flower
const ORIGIN = `${(emblem.x / LOGO_CANVAS.w) * 100}% ${(emblem.y / LOGO_CANVAS.h) * 100}%`;

/** Text layer drawn with the exact same routine as the container's painted logo. */
function LogoText({ part, delay }: { part: "name" | "sub"; delay: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    let alive = true;
    const paint = () => {
      const c = ref.current;
      if (!c || !alive) return;
      const g = c.getContext("2d")!;
      g.clearRect(0, 0, c.width, c.height);
      drawLogoText(g, LOGO_COLOR, part);
    };
    paint();
    document.fonts?.ready.then(paint);
    return () => {
      alive = false;
    };
  }, [part]);
  return (
    <canvas
      ref={ref}
      width={LOGO_CANVAS.w}
      height={LOGO_CANVAS.h}
      className="loader-rise absolute inset-0 h-full w-full"
      style={{ animationDelay: `${delay}s`, animationDuration: part === "name" ? "1.4s" : "1.1s" }}
    />
  );
}

/**
 * Emerald loading screen. The emblem blooms petal by petal, then the name appears.
 * When the scene is ready the background dissolves while the logo holds perfectly still:
 * the identical logo is painted on the container behind it, at exactly this size and
 * position, so the loading screen simply becomes the cargo.
 * (Animations are pure CSS so they stay smooth while the 3D scene loads.)
 */
export function Loader({ ready, onDone }: { ready: boolean; onDone: () => void }) {
  const [minDone, setMinDone] = useState(false);
  const [play, setPlay] = useState(false);
  useEffect(() => {
    // start the bloom only once the page is live, so the first petal is never missed
    const raf = requestAnimationFrame(() => setPlay(true));
    const t = setTimeout(() => setMinDone(true), MIN_SHOW);
    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(t);
    };
  }, []);
  const gone = minDone && ready;

  return (
    <AnimatePresence onExitComplete={onDone}>
      {!gone && (
        <motion.div key="loader" className="fixed inset-0 z-[90]" exit={{ opacity: 1, transition: { duration: 2.1 } }} role="status" aria-label="Loading Everlyn Internationals">
          {/* emerald backdrop dissolves first, revealing the container behind the logo */}
          <motion.div className="absolute inset-0 bg-forest-deep" exit={{ opacity: 0 }} transition={{ duration: 1.4, ease: "easeInOut" }}>
            <div aria-hidden className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(31,92,71,0.55)_0%,rgba(10,42,33,0)_65%)]" />
          </motion.div>

          {/* logo box: same size and position as the painted logo in the 3D close-up */}
          <motion.div
            className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 ${play ? "" : "loader-paused"}`}
            style={{ width: "min(84vw, calc(42lvh * 2048 / 860))", aspectRatio: "2048 / 860" }}
            exit={{ opacity: 0, transition: { duration: 0.9, delay: 1.1, ease: "easeInOut" } }}
          >
            {PETALS.map((p, i) => (
              <div
                key={p.r}
                className="loader-petal absolute inset-0"
                style={{ transformOrigin: ORIGIN, animationDelay: `${FIRST + i * GAP}s`, animationDuration: `${PETAL_DUR}s` }}
              >
                <svg viewBox={`0 0 ${LOGO_CANVAS.w} ${LOGO_CANVAS.h}`} className="h-full w-full overflow-visible" aria-hidden fill="none">
                  <g transform={`translate(${emblem.x} ${emblem.y}) scale(${emblem.scale}) rotate(${p.r})`} stroke={LOGO_COLOR} strokeWidth={2.6} strokeLinejoin="round">
                    <path d={OUTLINE} />
                    {p.filled ? <path d={HALF} fill={LOGO_COLOR} stroke="none" /> : <path d="M0 -2 L0 -34" />}
                  </g>
                </svg>
              </div>
            ))}
            <LogoText part="name" delay={NAME_AT} />
            <LogoText part="sub" delay={SUB_AT} />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
