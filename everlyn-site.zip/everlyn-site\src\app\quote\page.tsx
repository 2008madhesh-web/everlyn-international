import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { QuoteForm } from "@/components/forms/QuoteForm";
import { Reveal } from "@/components/ui/Reveal";
import { contact } from "@/content/site";

export const metadata: Metadata = {
  title: "Request a Quote",
  description: "Request a quotation for exports from India or imports into India. We usually reply within one business day.",
};

const expect = [
  { t: "Reply within one business day", d: "With pricing, or a few questions to get it exactly right." },
  { t: "Samples on request", d: "Courier samples of the actual grade before you commit." },
  { t: "No obligation", d: "Quotes are free, with no pressure to proceed." },
];

export default function QuotePage() {
  return (
    <>
      <PageHero eyebrow="Request a quote" title="Tell us what you need." intro="Three short steps. The more detail you share, the more precise our quotation will be." crumbs={[{ label: "Request a Quote" }]} />
      <section className="container-lux grid gap-16 pb-32 lg:grid-cols-12">
        <Reveal className="rounded-[2rem] border border-forest-deep/10 bg-ivory p-6 shadow-[0_40px_90px_-60px_rgba(14,59,46,0.5)] sm:p-10 lg:col-span-8">
          <QuoteForm />
        </Reveal>
        <aside className="lg:col-span-4">
          <p className="eyebrow mb-6">What to expect</p>
          <ul className="space-y-8">
            {expect.map((e, i) => (
              <Reveal as="li" key={e.t} delay={i * 0.08} className="border-t border-forest-deep/15 pt-5">
                <p className="display text-2xl text-forest-deep">{e.t}</p>
                <p className="mt-1 text-sm text-ink/65">{e.d}</p>
              </Reveal>
            ))}
          </ul>
          <div className="mt-12 rounded-[1.5rem] bg-forest-deep p-8 text-ivory">
            <p className="eyebrow mb-3 !text-brass-light">Prefer to talk?</p>
            <a href={contact.phoneHref} className="display block text-3xl hover:text-brass-light">{contact.phone}</a>
            <a href={`mailto:${contact.salesEmail}`} className="link-underline mt-2 inline-block text-sm text-ivory/75">{contact.salesEmail}</a>
          </div>
        </aside>
      </section>
    </>
  );
}
