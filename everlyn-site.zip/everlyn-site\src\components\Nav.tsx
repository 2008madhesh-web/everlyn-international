"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Logo } from "./Logo";
import { Button } from "./ui/Button";
import { nav, footerNav, contact } from "@/content/site";
import { getLenis } from "./SmoothScroll";

const ease = [0.22, 1, 0.36, 1] as const;

export function Nav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    let last = window.scrollY;
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 40);
      setHidden(y > 300 && y > last + 2);
      if (y < last - 2) setHidden(false);
      last = y;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // close the menu whenever the route changes
  const [lastPath, setLastPath] = useState(pathname);
  if (pathname !== lastPath) {
    setLastPath(pathname);
    setOpen(false);
  }

  useEffect(() => {
    const l = getLenis();
    if (open) {
      l?.stop();
      document.documentElement.style.overflow = "hidden";
    } else {
      l?.start();
      document.documentElement.style.overflow = "";
    }
  }, [open]);

  const mobileLinks = [{ label: "Home", href: "/" }, ...nav, { label: "Industries", href: "/industries" }, { label: "FAQ", href: "/faq" }, { label: "Careers", href: "/careers" }];

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-700 ease-[cubic-bezier(.22,1,.36,1)] ${
          hidden && !open ? "-translate-y-full" : "translate-y-0"
        }`}
      >
        <div
          className={`transition-all duration-700 ${
            scrolled && !open ? "glass border-x-0 border-t-0 py-3" : "border-b border-transparent py-5"
          }`}
        >
          <div className="container-lux flex items-center justify-between">
            <Link href="/" aria-label="Everlyn Internationals — home" className={`relative z-10 transition-colors duration-500 ${open ? "text-ivory" : "text-forest-deep"}`}>
              <Logo />
            </Link>

            <nav aria-label="Main" className="hidden lg:block">
              <ul className="flex items-center gap-8">
                {nav.map((n) => {
                  const active = pathname === n.href || pathname.startsWith(n.href + "/");
                  return (
                    <li key={n.href}>
                      <Link
                        href={n.href}
                        aria-current={active ? "page" : undefined}
                        className="link-underline text-[0.78rem] font-medium uppercase tracking-[0.16em] text-forest-deep/85 hover:text-forest-deep"
                      >
                        {n.label}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </nav>

            <div className="flex items-center gap-3">
              <div className="hidden sm:block">
                <Button href="/quote" variant={open ? "light" : "primary"} className="!px-5 !py-2.5">
                  Get a Quote
                </Button>
              </div>
              <button
                type="button"
                onClick={() => setOpen((o) => !o)}
                aria-expanded={open}
                aria-controls="mobile-menu"
                aria-label={open ? "Close menu" : "Open menu"}
                className={`relative z-10 flex h-11 w-11 items-center justify-center rounded-full border transition-colors duration-500 lg:hidden ${
                  open ? "border-ivory/40 text-ivory" : "border-forest-deep/25 text-forest-deep"
                }`}
              >
                <span className={`absolute h-px w-5 bg-current transition-transform duration-500 ${open ? "rotate-45" : "-translate-y-[4px]"}`} />
                <span className={`absolute h-px w-5 bg-current transition-transform duration-500 ${open ? "-rotate-45" : "translate-y-[4px]"}`} />
              </button>
            </div>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            className="fixed inset-0 z-40 overflow-y-auto bg-forest-deep text-ivory"
            initial={{ clipPath: "inset(0 0 100% 0)" }}
            animate={{ clipPath: "inset(0 0 0% 0)" }}
            exit={{ clipPath: "inset(0 0 100% 0)" }}
            transition={{ duration: 0.85, ease }}
            data-lenis-prevent
          >
            <div className="container-lux flex min-h-full flex-col justify-between pb-10 pt-28">
              <ul className="space-y-1">
                {mobileLinks.map((n, i) => (
                  <li key={n.href} className="overflow-hidden">
                    <motion.div
                      initial={{ y: "100%" }}
                      animate={{ y: 0 }}
                      transition={{ duration: 0.8, ease, delay: 0.25 + i * 0.05 }}
                    >
                      <Link
                        href={n.href}
                        className={`display block py-1 text-[2.4rem] sm:text-5xl transition-colors hover:text-brass-light ${pathname === n.href ? "text-brass-light" : ""}`}
                      >
                        {n.label}
                      </Link>
                    </motion.div>
                  </li>
                ))}
              </ul>
              <motion.div
                className="mt-12 grid gap-6 border-t border-ivory/15 pt-8 text-sm text-ivory/70 sm:grid-cols-2"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.7, duration: 0.8 }}
              >
                <div>
                  <p className="eyebrow mb-2">Write to us</p>
                  <a href={`mailto:${contact.email}`} className="link-underline">{contact.email}</a>
                </div>
                <div>
                  <p className="eyebrow mb-2">Call</p>
                  <a href={contact.phoneHref} className="link-underline">{contact.phone}</a>
                </div>
                <div className="sm:hidden">
                  <Button href="/quote" variant="light" arrow>Get a Quote</Button>
                </div>
                <p className="sr-only">{Object.keys(footerNav).join(", ")}</p>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
