import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { ContactForm } from "@/components/forms/ContactForm";
import { Reveal } from "@/components/ui/Reveal";
import { Button } from "@/components/ui/Button";
import { contact } from "@/content/site";

export const metadata: Metadata = {
  title: "Contact",
  description: "Contact Everlyn Internationals by email, phone or WhatsApp, or visit our office in India.",
};

export default function ContactPage() {
  const channels = [
    { k: "General enquiries", v: contact.email, href: `mailto:${contact.email}` },
    { k: "Sales & quotations", v: contact.salesEmail, href: `mailto:${contact.salesEmail}` },
    { k: "Phone", v: contact.phone, href: contact.phoneHref },
  ];
  return (
    <>
      <PageHero eyebrow="Contact" title="Let's start a conversation." intro="Whether you're placing a first order or a hundredth, our team is ready to help." crumbs={[{ label: "Contact" }]} />

      <section className="container-lux grid gap-16 pb-24 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <ul className="divide-y divide-forest-deep/10 border-y border-forest-deep/10">
            {channels.map((c, i) => (
              <Reveal as="li" key={c.k} delay={i * 0.06} className="py-6">
                <p className="text-[0.68rem] uppercase tracking-[0.2em] text-ink/50">{c.k}</p>
                <a href={c.href} className="display link-underline mt-1 inline-block text-2xl text-forest-deep sm:text-3xl">{c.v}</a>
              </Reveal>
            ))}
            <Reveal as="li" className="py-6">
              <p className="text-[0.68rem] uppercase tracking-[0.2em] text-ink/50">Office</p>
              <address className="mt-2 not-italic leading-relaxed text-forest-deep">
                {contact.addressLines.map((l) => (
                  <span key={l} className="block">{l}</span>
                ))}
              </address>
              <p className="mt-3 text-sm text-ink/60">{contact.hours}</p>
            </Reveal>
          </ul>
          <div className="mt-8">
            <Button href={`https://wa.me/${contact.whatsapp}`} variant="outline" arrow external>Chat on WhatsApp</Button>
          </div>
        </div>

        <Reveal className="rounded-[2rem] border border-forest-deep/10 bg-ivory p-6 shadow-[0_40px_90px_-60px_rgba(14,59,46,0.5)] sm:p-10 lg:col-span-7">
          <p className="eyebrow mb-2">Send a message</p>
          <h2 className="display mb-10 text-4xl text-forest-deep">We&rsquo;ll reply within one business day.</h2>
          <ContactForm />
        </Reveal>
      </section>

      <section className="container-lux pb-32">
        <Reveal className="overflow-hidden rounded-[2rem] border border-forest-deep/10">
          <iframe
            title="Map showing the Everlyn Internationals office"
            src={`https://www.google.com/maps?q=${encodeURIComponent(contact.mapQuery)}&output=embed`}
            className="h-[420px] w-full grayscale-[0.6] sepia-[0.25]"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </Reveal>
      </section>
    </>
  );
}
