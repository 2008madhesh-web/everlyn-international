import type { Metadata } from "next";
import Image from "next/image";
import { PageHero, SectionHeading } from "@/components/ui/PageHero";
import { Reveal, RevealText, Counter, DrawLine } from "@/components/ui/Reveal";
import { Timeline } from "@/components/ui/Timeline";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { company, milestones, stats, values, whyUs } from "@/content/site";

export const metadata: Metadata = {
  title: "About Us",
  description: `The story, mission and values behind ${company.name}, an Indian import and export house built on trust.`,
};

const petals = [
  { title: "Source", body: "Direct relationships with farms, mills and makers." },
  { title: "Quality", body: "Every lot checked against the approved sample." },
  { title: "Care", body: "Packed for the voyage and for your shelf." },
  { title: "Delivery", body: "Tracked from gate-in to your doorstep." },
];

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About Everlyn"
        title="An Indian trade house with a global standard of care."
        intro={`${company.name} connects India's growers, mills and artisans with buyers around the world, and handles everything in between: sourcing, quality, paperwork and the voyage itself.`}
        crumbs={[{ label: "About" }]}
      />

      {/* Story */}
      <section className="container-lux grid gap-14 pb-24 md:grid-cols-12 md:pb-32">
        <div className="md:col-span-5">
          <Reveal>
            <p className="display text-3xl italic leading-snug text-forest md:text-4xl">
              &ldquo;We believe a container should arrive exactly as it was promised, every time, without anyone having to chase it.&rdquo;
            </p>
            <p className="mt-6 text-xs uppercase tracking-[0.2em] text-ink/50">The Everlyn promise</p>
          </Reveal>
        </div>
        <div className="space-y-6 text-[1.05rem] leading-relaxed text-ink/75 md:col-span-6 md:col-start-7">
          <Reveal>
            <p>
              Everlyn began with a simple observation: India grows and makes some of the world&rsquo;s finest goods, but buying
              them from abroad can be uncertain. Specifications drift, documents arrive late and communication goes quiet
              the moment a container sails.
            </p>
          </Reveal>
          <Reveal delay={0.1}>
            <p>
              We built our company to remove that uncertainty. Our team works on the ground in India, visiting suppliers,
              approving samples, supervising loading and preparing every certificate in-house. Our buyers abroad get one
              accountable partner from the first enquiry to the opened container.
            </p>
          </Reveal>
          <Reveal delay={0.2}>
            <p>
              Today we trade across spices, grains, fresh produce, textiles, handicrafts and engineering goods. We also run
              an import desk that brings global products into India for manufacturers and distributors.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Mission & vision */}
      <section className="bg-forest-deep py-24 text-ivory md:py-32">
        <div className="container-lux">
          <div className="grid gap-px overflow-hidden rounded-[2rem] bg-ivory/10 md:grid-cols-2">
            {[
              { k: "Mission", t: "To make Indian sourcing simple, transparent and dependable for every buyer, whatever their size." },
              { k: "Vision", t: "To be the most trusted name in Indian trade, known for the care we put into every shipment." },
            ].map((b, i) => (
              <Reveal key={b.k} delay={i * 0.12} className="bg-forest-deep p-10 md:p-16">
                <p className="eyebrow mb-6 !text-brass-light">Our {b.k}</p>
                <p className="display text-3xl leading-snug md:text-[2.6rem]">{b.t}</p>
              </Reveal>
            ))}
          </div>
          <dl className="mt-20 grid grid-cols-2 gap-10 md:grid-cols-4">
            {stats.map((s) => (
              <div key={s.label} className="border-t border-ivory/15 pt-6">
                <dd className="display text-5xl text-brass-light md:text-6xl">
                  <Counter value={s.value} suffix={s.suffix} decimals={s.decimals} />
                </dd>
                <dt className="mt-2 text-xs uppercase tracking-[0.2em] text-ivory/60">{s.label}</dt>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* The mark */}
      <section className="container-lux grid items-center gap-14 py-24 md:grid-cols-2 md:py-32">
        <Reveal className="overflow-hidden rounded-[2rem] shadow-[0_40px_90px_-50px_rgba(14,59,46,0.5)]">
          <Image src="/brand/everlyn-logo.jpg" alt="The Everlyn Internationals logo: a four-petal emblem above the wordmark" width={1254} height={1254} className="h-auto w-full" />
        </Reveal>
        <div>
          <SectionHeading eyebrow="Our mark" title="Four petals, one promise." intro="Our emblem is four leaves meeting at a single point. Each one stands for a commitment we make on every shipment." />
          <ul className="mt-10 grid gap-6 sm:grid-cols-2">
            {petals.map((p, i) => (
              <Reveal as="li" key={p.title} delay={i * 0.08} className="border-t border-forest-deep/15 pt-5">
                <p className="display text-2xl text-forest-deep">{p.title}</p>
                <p className="mt-1 text-sm text-ink/65">{p.body}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* Values */}
      <section className="bg-parchment/60 py-24 md:py-32">
        <div className="container-lux">
          <SectionHeading eyebrow="What we stand for" title="Values we trade by." />
          <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={i * 0.08} className="group rounded-[1.5rem] border border-forest-deep/10 bg-ivory p-8 transition-all duration-700 hover:-translate-y-1 hover:border-brass/40 hover:shadow-[0_30px_60px_-40px_rgba(14,59,46,0.45)]">
                <span className="display text-5xl italic text-brass/70">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="display mt-6 text-3xl text-forest-deep">{v.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-ink/70">{v.body}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Milestones */}
      <section className="container-lux py-24 md:py-32">
        <SectionHeading eyebrow="Our journey" title="How we got here." className="mb-20" />
        <Timeline items={milestones} />
      </section>

      {/* Why us */}
      <section className="container-lux pb-8">
        <DrawLine className="mb-16" />
        <RevealText text="Why buyers stay with Everlyn." className="display max-w-3xl text-4xl text-forest-deep sm:text-5xl" />
        <div className="mt-14 grid gap-10 md:grid-cols-4">
          {whyUs.map((w, i) => (
            <Reveal key={w.title} delay={i * 0.08}>
              <Icon name={w.icon} className="h-8 w-8 text-brass" />
              <h3 className="mt-4 font-medium text-forest-deep">{w.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/65">{w.body}</p>
            </Reveal>
          ))}
        </div>
      </section>

      <CtaBand />
    </>
  );
}
