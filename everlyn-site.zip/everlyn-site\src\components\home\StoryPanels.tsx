﻿"use client";

import Link from "next/link";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import {
  AnimatePresence, motion, useInView, useMotionValueEvent, useReducedMotion, useScroll, useSpring, useTransform,
} from "framer-motion";
import { Button, ArrowLink } from "../ui/Button";
import { RevealText } from "../ui/Reveal";
import { Icon } from "../ui/Icon";
import { story } from "@/lib/story";
import { certifications, company, originPorts, process, products, regions, stats, testimonials, whyUs } from "@/content/site";

const ease = [0.22, 1, 0.36, 1] as const;
const glass = "glass relative rounded-[1.75rem] shadow-[0_30px_80px_-40px_rgba(14,59,46,0.35)]";

function Eyebrow({ n, children, light }: { n?: string; children: React.ReactNode; light?: boolean }) {
  return (
    <p className={`eyebrow mb-4 flex items-center gap-3 ${light ? "!text-brass-light" : ""}`}>
      {n && <span className={`font-display text-base italic normal-case tracking-normal ${light ? "text-ivory" : "text-forest"}`}>{n}</span>}
      {n && <span className="h-px w-8 bg-brass/60" />}
      {children}
    </p>
  );
}

// ---------------------------------------------------------------------------
// HERO: the full-screen scene with the headline resting on a soft fade at the bottom.
export function HeroFrame({ show }: { show: boolean }) {
  return (
    <div className="relative flex h-[100svh] items-end overflow-hidden">
      <motion.div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 h-[42%] bg-gradient-to-t from-ivory/90 via-ivory/45 to-transparent md:h-full md:bg-gradient-to-r md:from-ivory/80 md:via-ivory/25 md:via-40% md:to-transparent md:to-60%"
        initial={{ opacity: 0 }}
        animate={show ? { opacity: 1 } : {}}
        transition={{ duration: 2, ease }}
      />
      <div className="container-lux relative pb-12 md:pb-16">
        <div className="flex max-w-2xl flex-col items-start gap-8">
          <div>
            <motion.p className="eyebrow mb-4" initial={{ opacity: 0, y: 10 }} animate={show ? { opacity: 1, y: 0 } : {}} transition={{ duration: 1.4, ease, delay: 0.3 }}>
              {company.name} · Import &amp; Export
            </motion.p>
            <RevealText
              as="h1"
              immediate={show}
              delay={0.45}
              text="From India's finest sources to the world's doorsteps."
              className="display text-[2.3rem] leading-[1.02] text-forest-deep sm:text-5xl lg:text-[4.2rem]"
            />
          </div>
          <motion.div
            className="flex flex-wrap items-center gap-3"
            initial={{ opacity: 0, y: 14 }}
            animate={show ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1.4, ease, delay: 1.1 }}
          >
            <Button href="/quote" arrow>Request a Quote</Button>
            <Button href="/about" variant="outline">Our Story</Button>
          </motion.div>
        </div>
        <motion.div className="mt-8 hidden items-center gap-3 md:flex" initial={{ opacity: 0 }} animate={show ? { opacity: 1 } : {}} transition={{ duration: 1.4, delay: 1.6 }}>
          <span className="relative block h-10 w-px overflow-hidden bg-forest-deep/15">
            <span className="scroll-cue absolute inset-x-0 top-0 h-1/2 bg-forest-deep" />
          </span>
          <span className="eyebrow !text-forest-deep/60">Scroll to follow the shipment</span>
        </motion.div>
      </div>
    </div>
  );
}


// ---------------------------------------------------------------------------
// ORIGIN: a curtain wipes the panel open; stats roll in like a departures board
function RollingNumber({ value, decimals = 0, suffix = "", start }: { value: number; decimals?: number; suffix?: string; start: boolean }) {
  const reduce = useReducedMotion();
  const text = value.toLocaleString("en-IN", { minimumFractionDigits: decimals, maximumFractionDigits: decimals }) + suffix;
  return (
    <span className="inline-flex overflow-hidden tabular-nums" aria-label={text}>
      {[...text].map((ch, i) => {
        const digit = /\d/.test(ch) ? parseInt(ch, 10) : null;
        if (digit === null) return <span key={i} aria-hidden>{ch}</span>;
        return (
          <span key={i} aria-hidden className="relative inline-block h-[1em] overflow-hidden leading-none">
            <motion.span
              className="flex flex-col"
              initial={{ y: "0em" }}
              animate={start || reduce ? { y: `-${digit + 10}em` } : { y: "0em" }}
              transition={{ duration: reduce ? 0 : 1.6 + i * 0.12, ease, delay: 0.5 + i * 0.05 }}
            >
              {Array.from({ length: 20 }).map((_, k) => (
                <span key={k} className="block h-[1em] leading-none">{k % 10}</span>
              ))}
            </motion.span>
          </span>
        );
      })}
    </span>
  );
}

export function OriginPanel() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -20% 0px" });
  return (
    <motion.div
      ref={ref}
      className={`${glass} max-w-xl p-6 sm:p-9`}
      initial={{ clipPath: "inset(0% 100% 0% 0% round 28px)" }}
      animate={inView ? { clipPath: "inset(0% 0% 0% 0% round 28px)" } : {}}
      transition={{ duration: 1.5, ease }}
    >
      {/* brass edge that sweeps across with the curtain */}
      <motion.span
        aria-hidden
        className="pointer-events-none absolute inset-y-0 w-[2px] bg-brass"
        initial={{ left: "0%", opacity: 1 }}
        animate={inView ? { left: "100%", opacity: 0 } : {}}
        transition={{ duration: 1.5, ease }}
      />
      <Eyebrow n="01">Origin</Eyebrow>
      <RevealText text="Every shipment begins with a promise." className="display text-4xl text-forest-deep sm:text-5xl" delay={0.4} />
      <motion.p className="mt-5 text-[0.95rem] leading-relaxed text-ink/70" initial={{ opacity: 0 }} animate={inView ? { opacity: 1 } : {}} transition={{ duration: 1, delay: 0.8 }}>
        We visit the farms, mills and workshops ourselves. Every lot is checked against the approved sample, packed for
        the voyage and sealed only when it&rsquo;s right, because our name travels on every container.
      </motion.p>
      <dl className="mt-8 grid grid-cols-2 gap-x-6 gap-y-6 border-t border-forest-deep/10 pt-7">
        {stats.map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, x: -16 }} animate={inView ? { opacity: 1, x: 0 } : {}} transition={{ duration: 0.9, ease, delay: 0.9 + i * 0.1 }}>
            <dt className="text-[0.7rem] uppercase tracking-[0.2em] text-ink/55">{s.label}</dt>
            <dd className="display mt-1 text-4xl text-forest sm:text-[2.6rem]">
              <RollingNumber value={s.value} suffix={s.suffix} decimals={s.decimals} start={inView} />
            </dd>
          </motion.div>
        ))}
      </dl>
      <div className="mt-8">
        <ArrowLink href="/about">About Everlyn</ArrowLink>
      </div>
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
// PRODUCTS: plays while the ship sails into the sunset. On larger screens one product
// takes the stage at a time; on phones it is a swipeable row.
const SHORT: Record<string, string> = {
  spices: "Spices",
  "rice-grains": "Grains",
  "fresh-produce": "Produce",
  textiles: "Textiles",
  handicrafts: "Handicrafts",
  industrial: "Engineering",
};

export function ProductsGallery({ sectionRef }: { sectionRef: React.RefObject<HTMLElement | null> }) {
  const [desktop, setDesktop] = useState<boolean | null>(null);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const set = () => setDesktop(mq.matches);
    set();
    mq.addEventListener("change", set);
    return () => mq.removeEventListener("change", set);
  }, []);
  if (desktop === null) return null;
  return desktop ? <ProductsShowcase sectionRef={sectionRef} /> : <ProductsRow sectionRef={sectionRef} />;
}

const STAGES = products.length + 1; // intro + one stage per product

function ProductsShowcase({ sectionRef }: { sectionRef: React.RefObject<HTMLElement | null> }) {
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start start", "end end"] });
  const smooth = useSpring(scrollYProgress, { stiffness: 90, damping: 26, mass: 0.5 });
  const [stage, setStage] = useState(0);
  const [dir, setDir] = useState(1);
  useMotionValueEvent(scrollYProgress, "change", (v) => {
    const s = Math.min(STAGES - 1, Math.floor(v * STAGES * 0.9999));
    setStage((prev) => {
      if (s !== prev) setDir(s > prev ? 1 : -1);
      return s;
    });
  });
  // giant outline names glide horizontally, centring the current one
  const stripX = useTransform(smooth, (v) => `${17 - v * (STAGES - 1) * 66}vw`);
  const progress = useTransform(smooth, [0, 1], [0, 1]);
  const p = stage > 0 ? products[stage - 1] : null;

  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* horizontal strip of category names */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute left-0 top-[14vh] flex whitespace-nowrap"
        style={{ x: stripX }}
      >
        {["Our Trade", ...products.map((pr) => SHORT[pr.slug] ?? pr.name)].map((label, i) => (
          <span
            key={label}
            className="flex w-[66vw] items-center justify-center font-sans text-[clamp(3rem,7.2vw,8rem)] font-semibold uppercase leading-none tracking-[0.08em] text-ivory transition-[opacity,transform] duration-1000 ease-[cubic-bezier(.22,1,.36,1)]"
            style={{
              opacity: i === stage ? 0.95 : 0.22,
              transform: i === stage ? "scale(1)" : "scale(0.9)",
              textShadow: "0 2px 28px rgba(20,8,4,0.55), 0 1px 2px rgba(20,8,4,0.35)",
            }}
          >
            {label}
          </span>
        ))}
      </motion.div>

      {/* stage */}
      <div className="container-lux relative flex h-full items-end pb-[12vh]" style={{ perspective: 1600 }}>
        <AnimatePresence mode="popLayout" custom={dir} initial={false}>
          <motion.div
            key={stage}
            custom={dir}
            variants={{
              enter: (d: number) => ({ opacity: 0, x: d * 160, rotateY: d * -32, filter: "blur(14px)", clipPath: d > 0 ? "inset(0% 0% 0% 100% round 28px)" : "inset(0% 100% 0% 0% round 28px)" }),
              center: { opacity: 1, x: 0, rotateY: 0, filter: "blur(0px)", clipPath: "inset(0% 0% 0% 0% round 28px)" },
              exit: (d: number) => ({ opacity: 0, x: d * -200, rotateY: d * 28, scale: 0.9, filter: "blur(10px)" }),
            }}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 1.05, ease }}
            className="w-full max-w-[34rem]"
            style={{ transformOrigin: dir > 0 ? "0% 50%" : "100% 50%" }}
          >
            {p ? <ProductStageCard index={stage} /> : <ProductsIntroCard />}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* index, segmented progress and the horizontal chip rail */}
      <div className="container-lux pointer-events-none absolute inset-x-0 bottom-[5vh] flex items-end justify-end">
        <div className="pointer-events-auto w-full max-w-[26rem] text-ivory [text-shadow:0_1px_10px_rgba(0,0,0,0.35)]">
          <div className="flex items-baseline justify-between">
            <span className="text-[0.62rem] uppercase tracking-[0.3em] text-ivory/80">What we trade</span>
            <span className="display text-2xl tabular-nums">
              {String(stage).padStart(2, "0")}
              <span className="text-ivory/50"> / {String(products.length).padStart(2, "0")}</span>
            </span>
          </div>
          <div className="mt-3 flex gap-1.5">
            {products.map((pr, i) => (
              <SegmentBar key={pr.slug} progress={progress} index={i + 1} />
            ))}
          </div>
          <div className="mt-4 flex gap-2 overflow-hidden">
            <motion.div className="flex gap-2" animate={{ x: -Math.max(0, stage - 2) * 92 }} transition={{ duration: 0.9, ease }}>
              {products.map((pr, i) => (
                <Link
                  key={pr.slug}
                  href={`/products/${pr.slug}`}
                  className={`flex h-9 w-[84px] shrink-0 items-center justify-center rounded-full border text-[0.6rem] uppercase tracking-[0.16em] transition-all duration-500 ${
                    i + 1 === stage ? "border-brass-light bg-brass-light/20 text-ivory" : "border-ivory/25 text-ivory/60 hover:border-ivory/60"
                  }`}
                >
                  {SHORT[pr.slug]}
                </Link>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SegmentBar({ progress, index }: { progress: ReturnType<typeof useTransform<number, number>>; index: number }) {
  const fill = useTransform(progress, (v) => clamp01(v * STAGES - index));
  return (
    <span className="relative h-[2px] flex-1 overflow-hidden rounded-full bg-ivory/25">
      <motion.span className="absolute inset-0 origin-left bg-brass-light" style={{ scaleX: fill }} />
    </span>
  );
}
const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

function ProductsIntroCard() {
  return (
    <div className={`${glass} p-8 sm:p-10`}>
      <Eyebrow n="02">What we trade</Eyebrow>
      <h2 className="display text-4xl text-forest-deep sm:text-5xl">Six categories. One standard of care.</h2>
      <p className="mt-5 text-[0.95rem] leading-relaxed text-ink/70">
        As the ship slips out into the evening, here is what travels in our containers: graded, inspected and packed to
        export standard, from India&rsquo;s best growing regions and manufacturing clusters.
      </p>
      <div className="mt-8 flex items-center gap-5">
        <ArrowLink href="/products">All products</ArrowLink>
        <span className="text-[0.62rem] uppercase tracking-[0.26em] text-ink/45">Scroll to browse</span>
      </div>
    </div>
  );
}

function ProductStageCard({ index }: { index: number }) {
  const p = products[index - 1];
  return (
    <Link href={`/products/${p.slug}`} className={`${glass} group block overflow-hidden p-8 sm:p-10`}>
      <span aria-hidden className="absolute inset-0 origin-bottom scale-y-0 rounded-[inherit] bg-forest-deep transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-y-100" />
      <span className="relative flex items-start justify-between">
        <span className="display flex overflow-hidden text-7xl italic leading-none text-brass/80 transition-colors duration-700 group-hover:text-brass-light">
          {String(index).padStart(2, "0").split("").map((ch, i) => (
            <motion.span key={i} className="inline-block" initial={{ y: "100%" }} animate={{ y: "0%" }} transition={{ duration: 0.9, ease, delay: 0.25 + i * 0.08 }}>
              {ch}
            </motion.span>
          ))}
        </span>
        <motion.span
          className="flex h-16 w-16 items-center justify-center rounded-full bg-forest/10 text-forest transition-colors duration-700 group-hover:bg-ivory/10 group-hover:text-brass-light"
          initial={{ rotate: -120, scale: 0.4, opacity: 0 }}
          animate={{ rotate: 0, scale: 1, opacity: 1 }}
          transition={{ duration: 1.1, ease, delay: 0.35 }}
        >
          <Icon name={p.icon} className="h-8 w-8" />
        </motion.span>
      </span>
      <span className="relative mt-10 block">
        <span className="display block text-[2.6rem] leading-[1.05] text-forest-deep transition-colors duration-700 group-hover:text-ivory">
          {p.name.split(" ").map((w, i) => (
            <span key={i} className="inline-block overflow-hidden pb-1 align-top">
              <motion.span className="inline-block" initial={{ y: "105%" }} animate={{ y: "0%" }} transition={{ duration: 0.9, ease, delay: 0.35 + i * 0.07 }}>
                {w}&nbsp;
              </motion.span>
            </span>
          ))}
        </span>
        <motion.span className="mt-3 block max-w-md text-sm leading-relaxed text-ink/65 transition-colors duration-700 group-hover:text-ivory/75" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6, duration: 0.8 }}>
          {p.short}
        </motion.span>
        <span className="mt-6 grid grid-cols-2 gap-x-6 gap-y-2 border-t border-forest-deep/10 pt-5 text-sm text-forest-deep/80 transition-colors duration-700 group-hover:border-ivory/15 group-hover:text-ivory/80">
          {p.items.slice(0, 4).map((it, i) => (
            <motion.span key={it.name} className="flex items-center gap-2" initial={{ opacity: 0, x: 14 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.7 + i * 0.07, duration: 0.7, ease }}>
              <span className="h-1 w-1 shrink-0 rounded-full bg-brass" />
              {it.name}
            </motion.span>
          ))}
        </span>
        <span className="mt-7 flex items-center gap-2 text-[0.72rem] uppercase tracking-[0.2em] text-forest transition-colors duration-700 group-hover:text-brass-light">
          Explore {p.name.split(" ")[0]}
          <svg width="16" height="10" viewBox="0 0 16 10" fill="none" stroke="currentColor" strokeWidth="1.4" className="transition-transform duration-500 group-hover:translate-x-1.5" aria-hidden>
            <path d="M0 5h14M10 1l4 4-4 4" />
          </svg>
        </span>
      </span>
    </Link>
  );
}

function ProductsRow({ sectionRef }: { sectionRef: React.RefObject<HTMLElement | null> }) {
  const track = useRef<HTMLDivElement>(null);
  const viewport = useRef<HTMLDivElement>(null);
  const [distance, setDistance] = useState(0);
  const [desktop, setDesktop] = useState(false);
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start start", "end end"] });
  const smooth = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.4 });
  const x = useTransform(smooth, [0.04, 0.96], [0, -distance]);
  const bar = useTransform(smooth, [0.04, 0.96], [0, 1]);

  useLayoutEffect(() => {
    const measure = () => {
      const d = window.matchMedia("(min-width: 768px)").matches;
      setDesktop(d);
      if (track.current && viewport.current) setDistance(Math.max(0, track.current.scrollWidth - viewport.current.clientWidth));
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  return (
    <div ref={viewport} className="relative w-full overflow-hidden">
      <motion.div
        ref={track}
        style={desktop ? { x } : undefined}
        className="flex snap-x snap-mandatory gap-5 overflow-x-auto px-5 pb-6 md:snap-none md:overflow-visible md:px-[max(2.5rem,calc((100vw-1320px)/2+2.5rem))] md:pb-0 [scrollbar-width:none]"
      >
        {/* intro card */}
        <div className={`${glass} flex w-[82vw] shrink-0 snap-start flex-col justify-between p-8 sm:w-[24rem] md:h-[25rem]`}>
          <div>
            <Eyebrow n="02">What we trade</Eyebrow>
            <RevealText text="Six categories. One standard of care." className="display text-4xl text-forest-deep sm:text-5xl" />
            <p className="mt-5 text-[0.95rem] leading-relaxed text-ink/70">
              Graded, inspected and packed to export standard, from India&rsquo;s best growing regions and manufacturing clusters.
            </p>
          </div>
          <div className="mt-8 flex items-center gap-4">
            <ArrowLink href="/products">All products</ArrowLink>
            <span className="hidden text-[0.65rem] uppercase tracking-[0.24em] text-ink/45 md:inline">Keep scrolling</span>
          </div>
        </div>

        {products.map((p, i) => (
          <motion.div
            key={p.slug}
            className="w-[78vw] shrink-0 snap-start sm:w-[21rem]"
            initial={{ opacity: 0, y: 40, rotate: 2 }}
            whileInView={{ opacity: 1, y: 0, rotate: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 1, ease, delay: (i % 3) * 0.08 }}
          >
            <Link
              href={`/products/${p.slug}`}
              className="group relative flex h-[26rem] flex-col overflow-hidden rounded-[1.75rem] border border-forest-deep/10 bg-ivory/90 p-7 shadow-[0_30px_80px_-40px_rgba(14,59,46,0.35)] backdrop-blur-md transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] hover:-translate-y-2 md:h-[25rem]"
            >
              {/* emerald flood rises on hover */}
              <span aria-hidden className="absolute inset-0 origin-bottom scale-y-0 bg-forest-deep transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-y-100" />
              <span className="relative flex items-start justify-between">
                <span className="display text-5xl italic text-brass/70 transition-colors duration-700 group-hover:text-brass-light">{String(i + 1).padStart(2, "0")}</span>
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-forest/10 text-forest transition-all duration-700 group-hover:rotate-[20deg] group-hover:bg-ivory/10 group-hover:text-brass-light">
                  <Icon name={p.icon} className="h-7 w-7" />
                </span>
              </span>
              <span className="relative mt-auto">
                <span className="display block text-[2rem] leading-tight text-forest-deep transition-colors duration-700 group-hover:text-ivory">{p.name}</span>
                <span className="mt-4 block space-y-1.5 text-sm text-ink/65 transition-colors duration-700 group-hover:text-ivory/75">
                  {p.items.slice(0, 3).map((it) => (
                    <span key={it.name} className="flex items-center gap-2">
                      <span className="h-1 w-1 rounded-full bg-brass" />
                      {it.name}
                    </span>
                  ))}
                </span>
                <span className="mt-6 flex items-center gap-2 text-[0.72rem] uppercase tracking-[0.2em] text-forest transition-colors duration-700 group-hover:text-brass-light">
                  Explore
                  <svg width="16" height="10" viewBox="0 0 16 10" fill="none" stroke="currentColor" strokeWidth="1.4" className="transition-transform duration-500 group-hover:translate-x-1.5" aria-hidden>
                    <path d="M0 5h14M10 1l4 4-4 4" />
                  </svg>
                </span>
              </span>
            </Link>
          </motion.div>
        ))}
        <div className="w-1 shrink-0 md:w-8" aria-hidden />
      </motion.div>

      {/* progress rail for the horizontal journey */}
      <div className="container-lux mt-8 hidden md:block">
        <div className="relative h-px w-full max-w-md bg-forest-deep/15">
          <motion.span className="absolute inset-0 origin-left bg-brass" style={{ scaleX: bar }} />
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// REGIONS: a focus pull from blur, then rule lines draw across before each row arrives
export function RegionsPanel() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -20% 0px" });
  return (
    <motion.div
      ref={ref}
      className={`${glass} max-w-xl p-6 sm:p-9`}
      initial={{ opacity: 0, scale: 1.06, filter: "blur(18px)" }}
      animate={inView ? { opacity: 1, scale: 1, filter: "blur(0px)" } : {}}
      transition={{ duration: 1.4, ease }}
    >
      <Eyebrow n="03">Global reach</Eyebrow>
      <RevealText text="Routes we know by heart." className="display text-4xl text-forest-deep sm:text-5xl" delay={0.3} />
      <p className="mt-4 text-[0.95rem] leading-relaxed text-ink/70">Shipping from {originPorts.slice(0, 4).join(", ")} and more to buyers on six continents.</p>
      <ul className="mt-6">
        {regions.map((r, i) => (
          <li key={r.name} className="relative py-3">
            <motion.span
              aria-hidden
              className="absolute inset-x-0 top-0 h-px origin-left bg-forest-deep/15"
              initial={{ scaleX: 0 }}
              animate={inView ? { scaleX: 1 } : {}}
              transition={{ duration: 0.9, ease, delay: 0.5 + i * 0.09 }}
            />
            <div className="flex items-baseline justify-between gap-4 overflow-hidden">
              <motion.span initial={{ y: "110%" }} animate={inView ? { y: "0%" } : {}} transition={{ duration: 0.9, ease, delay: 0.7 + i * 0.09 }} className="block">
                <span className="display text-xl text-forest-deep">{r.name}</span>
                <span className="mt-0.5 block text-xs text-ink/55">{r.ports.join(" · ")}</span>
              </motion.span>
              <motion.span className="shrink-0 text-xs uppercase tracking-[0.16em] text-brass" initial={{ opacity: 0, x: 20 }} animate={inView ? { opacity: 1, x: 0 } : {}} transition={{ duration: 0.8, delay: 0.9 + i * 0.09 }}>
                {r.transit}
              </motion.span>
            </div>
          </li>
        ))}
      </ul>
      <div className="mt-7">
        <ArrowLink href="/global-network">See our network</ArrowLink>
      </div>
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
// WHY: the panel tilts up into place and each card swings open like a container door
export function WhyPanel() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -20% 0px" });
  return (
    <div ref={ref} style={{ perspective: 1400 }}>
      <motion.div
        className={`${glass} max-w-xl p-6 sm:p-9`}
        style={{ transformOrigin: "50% 100%" }}
        initial={{ opacity: 0, rotateX: 24, y: 80 }}
        animate={inView ? { opacity: 1, rotateX: 0, y: 0 } : {}}
        transition={{ duration: 1.3, ease }}
      >
        <p className="eyebrow mb-4">Why Everlyn</p>
        <RevealText text="Trust is built at every step." className="display text-4xl text-forest-deep sm:text-5xl" delay={0.3} />
        <ul className="mt-7 grid gap-4 sm:grid-cols-2" style={{ perspective: 900 }}>
          {whyUs.map((w, i) => (
            <motion.li
              key={w.title}
              className="rounded-2xl border border-forest-deep/10 bg-ivory/70 p-4"
              style={{ transformOrigin: i % 2 ? "100% 50%" : "0% 50%" }}
              initial={{ rotateY: i % 2 ? 95 : -95, opacity: 0 }}
              animate={inView ? { rotateY: 0, opacity: 1 } : {}}
              transition={{ duration: 1.2, ease, delay: 0.6 + i * 0.14 }}
            >
              <Icon name={w.icon} className="h-7 w-7 text-brass" />
              <p className="mt-3 font-medium text-forest-deep">{w.title}</p>
              <p className="mt-1 text-sm leading-relaxed text-ink/65">{w.body}</p>
            </motion.li>
          ))}
        </ul>
      </motion.div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// PROCESS: a scroll-driven timeline; steps light up one by one as the crane unloads
export function ProcessPanel({ sectionRef }: { sectionRef: React.RefObject<HTMLElement | null> }) {
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start start", "end end"] });
  const fill = useSpring(scrollYProgress, { stiffness: 90, damping: 26 });
  const [active, setActive] = useState(0);
  useMotionValueEvent(scrollYProgress, "change", (v) => setActive(Math.min(process.length - 1, Math.floor(v * process.length * 1.05))));
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -20% 0px" });
  return (
    <motion.div
      ref={ref}
      className={`${glass} max-w-xl p-6 sm:p-9`}
      initial={{ opacity: 0, x: -90 }}
      animate={inView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 1.2, ease }}
    >
      <Eyebrow n="04">Arrival</Eyebrow>
      <RevealText text="From enquiry to your doorstep." className="display text-4xl text-forest-deep sm:text-5xl" delay={0.2} />
      <ol className="relative mt-8 pl-8">
        <span aria-hidden className="absolute bottom-2 left-[0.7rem] top-2 w-px bg-forest-deep/12" />
        <motion.span aria-hidden className="absolute bottom-2 left-[0.7rem] top-2 w-px origin-top bg-brass" style={{ scaleY: fill }} />
        {process.map((s, i) => {
          const on = i <= active;
          return (
            <li key={s.step} className="relative pb-4 last:pb-0">
              <span
                aria-hidden
                className={`absolute -left-8 top-1 flex h-[1.45rem] w-[1.45rem] items-center justify-center rounded-full border text-[0.6rem] transition-all duration-700 ${
                  on ? "scale-100 border-brass bg-forest-deep text-brass-light" : "scale-75 border-forest-deep/20 bg-ivory text-ink/40"
                }`}
              >
                {i + 1}
              </span>
              <div className={`transition-all duration-700 ${on ? "opacity-100" : "opacity-35"}`}>
                <p className={`font-medium transition-colors duration-700 ${i === active ? "text-forest" : "text-forest-deep"}`}>{s.title}</p>
                <AnimatePresence initial={false}>
                  {i === active && (
                    <motion.p
                      className="overflow-hidden text-sm leading-relaxed text-ink/65"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.5, ease }}
                    >
                      <span className="block pt-1">{s.body}</span>
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            </li>
          );
        })}
      </ol>
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
// DELIVERED: an iris opens from the centre; quotes resolve word by word; certifications glide past
function BlurWords({ text }: { text: string }) {
  return (
    <>
      {text.split(" ").map((w, i) => (
        <motion.span
          key={i}
          className="inline-block"
          initial={{ opacity: 0, filter: "blur(8px)", y: 6 }}
          animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
          transition={{ duration: 0.6, ease, delay: i * 0.035 }}
        >
          {w}&nbsp;
        </motion.span>
      ))}
    </>
  );
}

export function DeliveredPanel() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -20% 0px" });
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % testimonials.length), 7500);
    return () => clearInterval(t);
  }, []);
  const q = testimonials[i];
  const marquee = [...certifications, ...certifications];
  return (
    <motion.div
      ref={ref}
      className={`${glass} max-w-2xl overflow-hidden p-6 sm:p-9`}
      initial={{ clipPath: "circle(0% at 50% 50%)" }}
      animate={inView ? { clipPath: "circle(150% at 50% 50%)" } : {}}
      transition={{ duration: 1.6, ease }}
    >
      <Eyebrow n="05">Delivered</Eyebrow>
      <RevealText text="Opened with confidence." className="display text-4xl text-forest-deep sm:text-5xl" delay={0.5} />
      <figure className="relative mt-7 min-h-[12rem] sm:min-h-[9.5rem]">
        <AnimatePresence mode="wait">
          <motion.div key={i} exit={{ opacity: 0, filter: "blur(6px)" }} transition={{ duration: 0.5 }}>
            <blockquote className="display text-[1.45rem] italic leading-snug text-forest-deep/90 sm:text-2xl">
              &ldquo;{inView ? <BlurWords text={q.quote} /> : q.quote}&rdquo;
            </blockquote>
            <figcaption className="mt-4 text-xs uppercase tracking-[0.18em] text-ink/55">
              {q.who} · <span className="normal-case tracking-normal">{q.org}</span>
            </figcaption>
          </motion.div>
        </AnimatePresence>
      </figure>
      <div className="mt-5 flex gap-2" role="tablist" aria-label="Testimonials">
        {testimonials.map((_, k) => (
          <button
            key={k}
            role="tab"
            aria-selected={k === i}
            aria-label={`Testimonial ${k + 1}`}
            onClick={() => setI(k)}
            className={`h-1 rounded-full transition-all duration-500 ${k === i ? "w-10 bg-forest" : "w-5 bg-forest/20 hover:bg-forest/40"}`}
          />
        ))}
      </div>

      <div className="relative mt-8 -mx-6 overflow-hidden border-y border-forest-deep/10 py-4 sm:-mx-9 [mask-image:linear-gradient(90deg,transparent,#000_12%,#000_88%,transparent)]">
        <motion.ul className="flex w-max gap-10" animate={{ x: ["0%", "-50%"] }} transition={{ duration: 26, ease: "linear", repeat: Infinity }} aria-label="Registrations and certifications">
          {marquee.map((c, k) => (
            <li key={k} className="flex items-center gap-3 whitespace-nowrap text-[0.72rem] uppercase tracking-[0.2em] text-forest-deep/75" aria-hidden={k >= certifications.length}>
              <span className="h-1.5 w-1.5 rotate-45 bg-brass" />
              {c.name}
              <span className="normal-case tracking-normal text-ink/45">{c.by}</span>
            </li>
          ))}
        </motion.ul>
      </div>

      <div className="mt-8 flex flex-wrap gap-3">
        <Button href="/quote" arrow>Start your shipment</Button>
        <Button href="/contact" variant="outline">Talk to us</Button>
      </div>
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
const CHAPTERS = [
  { at: 0, label: "Origin" },
  { at: 0.3, label: "Sunset sail" },
  { at: 0.47, label: "Worldwide" },
  { at: 0.69, label: "Night arrival" },
  { at: 0.95, label: "Delivered" },
];

/** Thin progress rail with chapter names, fixed on the right edge (desktop). */
export function StoryProgress() {
  const bar = useRef<HTMLSpanElement>(null);
  const [active, setActive] = useState(0);
  useEffect(() => {
    let raf = 0;
    let last = -1;
    const loop = () => {
      const p = story.current;
      if (bar.current) bar.current.style.transform = `scaleY(${p})`;
      let a = 0;
      CHAPTERS.forEach((c, i) => {
        if (p >= c.at - 0.001) a = i;
      });
      if (a !== last) {
        last = a;
        setActive(a);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);
  return (
    <div aria-hidden className="glass pointer-events-none fixed bottom-10 right-8 z-20 hidden items-center gap-4 rounded-2xl px-4 py-3 xl:flex">
      <ul className="space-y-3 text-right">
        {CHAPTERS.map((c, i) => (
          <li key={c.label} className={`text-[0.62rem] uppercase tracking-[0.28em] transition-all duration-700 ${i === active ? "text-forest-deep" : "text-forest-deep/30"}`}>
            {c.label}
          </li>
        ))}
      </ul>
      <span className="relative block h-40 w-px bg-forest-deep/15">
        <span ref={bar} className="absolute inset-0 origin-top bg-brass" style={{ transform: "scaleY(0)" }} />
      </span>
    </div>
  );
}
