"use client";

import { useEffect, useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AnimatePresence, motion } from "framer-motion";
import { quoteSchema, type QuoteInput } from "@/lib/enquiry";
import { products } from "@/content/site";
import { Field, SuccessMark } from "./Field";
import { Button } from "../ui/Button";

const ease = [0.22, 1, 0.36, 1] as const;

const STEPS: { title: string; fields: (keyof QuoteInput)[] }[] = [
  { title: "Product", fields: ["tradeType", "category", "product", "quantity", "unit", "packaging"] },
  { title: "Shipment", fields: ["destinationCountry", "destinationPort", "incoterm", "timeline"] },
  { title: "Your details", fields: ["name", "email", "phone", "company", "notes"] },
];

const categories = [...products.map((p) => p.name), "Import into India", "Other / not listed"];

export function QuoteForm() {
  const [step, setStep] = useState(0);
  const [dir, setDir] = useState(1);
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [ref, setRef] = useState("");
  const { register, handleSubmit, trigger, setValue, control, formState: { errors } } = useForm<QuoteInput>({
    resolver: zodResolver(quoteSchema),
    defaultValues: { kind: "quote", tradeType: "Export from India", unit: "MT", incoterm: "FOB", timeline: "Within a month", category: "" },
    mode: "onTouched",
  });

  // Pre-select a category when arriving from a product page (?product=slug)
  useEffect(() => {
    const slug = new URLSearchParams(window.location.search).get("product");
    const p = products.find((x) => x.slug === slug);
    if (p) setValue("category", p.name);
  }, [setValue]);

  const go = async (to: number) => {
    if (to > step) {
      const ok = await trigger(STEPS[step].fields);
      if (!ok) return;
    }
    setDir(to > step ? 1 : -1);
    setStep(to);
  };

  const onSubmit = async (data: QuoteInput) => {
    setState("sending");
    try {
      const res = await fetch("/api/enquiry", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      const json = await res.json();
      if (!res.ok || !json.ok) throw new Error();
      setRef(json.ref ?? "");
      setState("done");
    } catch {
      setState("error");
    }
  };

  const aria = (k: keyof QuoteInput) => ({ "aria-invalid": !!errors[k], "aria-describedby": errors[k] ? `q-${k}-error` : undefined });
  const tradeType = useWatch({ control, name: "tradeType" });

  if (state === "done") {
    return (
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="py-6" role="status">
        <SuccessMark />
        <h2 className="display mt-6 text-4xl text-forest-deep sm:text-5xl">Your quote request is in.</h2>
        <p className="mt-4 max-w-lg text-ink/70">
          Our trade desk will review the details and reply within one business day with pricing or a few clarifying questions.
          {ref && <> Your reference is <strong className="text-forest-deep">{ref}</strong>.</>}
        </p>
        <div className="mt-10">
          <Button href="/" variant="outline">Back to home</Button>
        </div>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate>
      <input type="hidden" {...register("kind")} />
      <input type="text" tabIndex={-1} autoComplete="off" aria-hidden className="hidden" {...register("website")} />

      {/* Stepper */}
      <ol className="mb-12 grid grid-cols-3 gap-3" aria-label="Form progress">
        {STEPS.map((s, i) => (
          <li key={s.title}>
            <button type="button" onClick={() => i < step && go(i)} disabled={i > step} className="w-full text-left disabled:cursor-default" aria-current={i === step ? "step" : undefined}>
              <span className="relative block h-px w-full bg-forest-deep/15">
                <motion.span className="absolute inset-0 origin-left bg-forest" initial={false} animate={{ scaleX: i <= step ? 1 : 0 }} transition={{ duration: 0.8, ease }} />
              </span>
              <span className={`mt-3 block text-[0.68rem] uppercase tracking-[0.2em] ${i === step ? "text-forest-deep" : "text-ink/45"}`}>
                <span className="display mr-2 text-base italic tracking-normal text-brass">0{i + 1}</span>
                {s.title}
              </span>
            </button>
          </li>
        ))}
      </ol>

      <div className="relative min-h-[26rem]">
        <AnimatePresence mode="wait" custom={dir}>
          <motion.div
            key={step}
            custom={dir}
            initial={{ opacity: 0, x: dir * 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: dir * -40 }}
            transition={{ duration: 0.55, ease }}
            className="grid gap-8 sm:grid-cols-2"
          >
            {step === 0 && (
              <>
                <fieldset className="sm:col-span-2">
                  <legend className="text-[0.68rem] font-medium uppercase tracking-[0.2em] text-ink/55">I want to</legend>
                  <div className="mt-3 flex flex-wrap gap-3">
                    {(["Export from India", "Import into India"] as const).map((t) => (
                      <label key={t} className={`cursor-pointer rounded-full border px-5 py-2.5 text-sm transition-all duration-500 ${tradeType === t ? "border-forest-deep bg-forest-deep text-ivory" : "border-forest-deep/20 text-forest-deep hover:border-forest-deep/50"}`}>
                        <input type="radio" value={t} className="sr-only" {...register("tradeType")} />
                        {t === "Export from India" ? "Buy from India" : "Import into India"}
                      </label>
                    ))}
                  </div>
                </fieldset>
                <Field label="Category" htmlFor="q-category" error={errors.category?.message}>
                  <select id="q-category" className="field" {...register("category")} {...aria("category")}>
                    <option value="">Select a category</option>
                    {categories.map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </Field>
                <Field label="Product & specification" htmlFor="q-product" error={errors.product?.message}>
                  <input id="q-product" className="field" placeholder="e.g. 1121 Steam Basmati, 8.3 mm" {...register("product")} {...aria("product")} />
                </Field>
                <div className="grid grid-cols-[1fr_auto] gap-4">
                  <Field label="Quantity" htmlFor="q-quantity" error={errors.quantity?.message}>
                    <input id="q-quantity" className="field" inputMode="decimal" placeholder="e.g. 50" {...register("quantity")} {...aria("quantity")} />
                  </Field>
                  <Field label="Unit" htmlFor="q-unit">
                    <select id="q-unit" className="field" {...register("unit")}>
                      {quoteSchema.shape.unit.options.map((u) => (
                        <option key={u}>{u}</option>
                      ))}
                    </select>
                  </Field>
                </div>
                <Field label="Packaging preference" htmlFor="q-packaging" optional>
                  <input id="q-packaging" className="field" placeholder="e.g. 25 kg jute bags, private label" {...register("packaging")} />
                </Field>
              </>
            )}

            {step === 1 && (
              <>
                <Field label={tradeType === "Import into India" ? "Origin country" : "Destination country"} htmlFor="q-destinationCountry" error={errors.destinationCountry?.message}>
                  <input id="q-destinationCountry" className="field" autoComplete="country-name" {...register("destinationCountry")} {...aria("destinationCountry")} />
                </Field>
                <Field label={tradeType === "Import into India" ? "Port of loading" : "Destination port"} htmlFor="q-destinationPort" optional>
                  <input id="q-destinationPort" className="field" placeholder="e.g. Rotterdam" {...register("destinationPort")} />
                </Field>
                <Field label="Incoterm" htmlFor="q-incoterm">
                  <select id="q-incoterm" className="field" {...register("incoterm")}>
                    {quoteSchema.shape.incoterm.options.map((u) => (
                      <option key={u}>{u}</option>
                    ))}
                  </select>
                </Field>
                <Field label="When do you need it?" htmlFor="q-timeline">
                  <select id="q-timeline" className="field" {...register("timeline")}>
                    {quoteSchema.shape.timeline.options.map((u) => (
                      <option key={u}>{u}</option>
                    ))}
                  </select>
                </Field>
                <p className="text-sm leading-relaxed text-ink/60 sm:col-span-2">
                  Not sure about Incoterms? Choose &ldquo;Not sure&rdquo; and we&rsquo;ll recommend the best option for your market.
                </p>
              </>
            )}

            {step === 2 && (
              <>
                <Field label="Full name" htmlFor="q-name" error={errors.name?.message}>
                  <input id="q-name" className="field" autoComplete="name" {...register("name")} {...aria("name")} />
                </Field>
                <Field label="Business email" htmlFor="q-email" error={errors.email?.message}>
                  <input id="q-email" type="email" className="field" autoComplete="email" {...register("email")} {...aria("email")} />
                </Field>
                <Field label="Company" htmlFor="q-company" optional>
                  <input id="q-company" className="field" autoComplete="organization" {...register("company")} />
                </Field>
                <Field label="Phone / WhatsApp" htmlFor="q-phone" optional>
                  <input id="q-phone" type="tel" className="field" autoComplete="tel" {...register("phone")} />
                </Field>
                <Field label="Anything else?" htmlFor="q-notes" optional className="sm:col-span-2">
                  <textarea id="q-notes" rows={4} className="field resize-none" placeholder="Certifications needed, target price, sample request…" {...register("notes")} />
                </Field>
              </>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-forest-deep/10 pt-8">
        <div>
          {step > 0 && (
            <button type="button" onClick={() => go(step - 1)} className="link-underline text-[0.78rem] uppercase tracking-[0.18em] text-forest-deep">
              ← Back
            </button>
          )}
        </div>
        <div className="flex items-center gap-4">
          {state === "error" && <p role="alert" className="text-sm text-[#9b3b2a]">Couldn&rsquo;t send. Please try again.</p>}
          {step < STEPS.length - 1 ? (
            <Button onClick={() => go(step + 1)} arrow>Continue</Button>
          ) : (
            <Button type="submit" arrow disabled={state === "sending"}>{state === "sending" ? "Sending…" : "Request quote"}</Button>
          )}
        </div>
      </div>
    </form>
  );
}
