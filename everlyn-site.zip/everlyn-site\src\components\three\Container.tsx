"use client";

import { useEffect, useMemo } from "react";
import { Decal } from "@react-three/drei";
import * as THREE from "three";
import { interiorGlowTexture, logoDecalTexture } from "./textures";
import { corrugatedPanel } from "./geometry";
import { markingsTexture, usePBR } from "./materials";
import { DECAL_H, DECAL_W } from "@/lib/story";

export type ContainerRefs = {
  group: React.RefObject<THREE.Group | null>;
  doorL: React.RefObject<THREE.Group | null>;
  doorR: React.RefObject<THREE.Group | null>;
  decalMat: React.RefObject<THREE.MeshStandardMaterial | null>;
  glowMat: React.RefObject<THREE.MeshBasicMaterial | null>;
  spillMat: React.RefObject<THREE.MeshBasicMaterial | null>;
  light: React.RefObject<THREE.PointLight | null>;
};

const L = 2.4;
const H = 1.0;
const W = 0.98;
const RIB = 0.018;

/** The hero 20 ft container: real corrugated walls, steel frame, castings, working doors, painted logo. */
export function HeroContainer({ refs, shadows }: { refs: ContainerRefs; shadows: boolean }) {
  const pbr = usePBR();
  const m = useMemo(() => {
    const sideGeo = corrugatedPanel(L - 0.12, H - 0.12, RIB, 0.11);
    const endGeo = corrugatedPanel(W - 0.12, H - 0.12, RIB, 0.1);
    const roofGeo = corrugatedPanel(L - 0.12, W - 0.12, 0.008, 0.16).rotateX(-Math.PI / 2);
    const leafGeo = corrugatedPanel(W / 2 - 0.05, H - 0.14, 0.012, 0.085);
    const decal = new THREE.MeshStandardMaterial({
      map: logoDecalTexture(),
      transparent: true,
      opacity: 1,
      roughness: 0.55,
      metalness: 0.1,
      polygonOffset: true,
      polygonOffsetFactor: -6,
      depthWrite: false,
    });
    const marks = new THREE.MeshStandardMaterial({ map: markingsTexture("EVLU 220145 2", "22G1"), transparent: true, roughness: 0.6, polygonOffset: true, polygonOffsetFactor: -6, depthWrite: false });
    const glow = new THREE.MeshBasicMaterial({ map: interiorGlowTexture(), toneMapped: false });
    const casting = new THREE.MeshStandardMaterial({ color: "#2a2c28", roughness: 0.6, metalness: 0.8 });
    const hole = new THREE.MeshStandardMaterial({ color: "#0c0d0c", roughness: 1 });
    const chrome = new THREE.MeshStandardMaterial({ color: "#c9c3b5", roughness: 0.28, metalness: 1 });
    const seal = new THREE.MeshStandardMaterial({ color: "#121312", roughness: 0.9 });
    const spillGeo = new THREE.PlaneGeometry(3.4, 1.8);
    return { sideGeo, endGeo, roofGeo, leafGeo, decal, marks, glow, casting, hole, chrome, seal, spillGeo };
  }, []);

  useEffect(() => {
    refs.decalMat.current = m.decal;
    refs.glowMat.current = m.glow;
  }, [refs, m]);

  const f = 0.065;
  const posts: [number, number][] = [];
  for (const x of [L / 2 - f / 2, -L / 2 + f / 2]) for (const z of [W / 2 - f / 2, -W / 2 + f / 2]) posts.push([x, z]);
  const castings: [number, number, number][] = [];
  for (const x of [L / 2 - 0.045, -L / 2 + 0.045]) for (const y of [H / 2 - 0.045, -H / 2 + 0.045]) for (const z of [W / 2 - 0.045, -W / 2 + 0.045]) castings.push([x, y, z]);

  const leaf = (side: 1 | -1) => (
    <group position={[0, 0, -side * (W / 4)]}>
      <mesh geometry={m.leafGeo} material={pbr.containerPaint} rotation={[0, -Math.PI / 2, 0]} castShadow={shadows} receiveShadow={shadows} />
      {/* door frame & gasket */}
      <mesh material={pbr.frameSteel} position={[0.006, H / 2 - 0.09, 0]}>
        <boxGeometry args={[0.03, 0.05, W / 2 - 0.02]} />
      </mesh>
      <mesh material={pbr.frameSteel} position={[0.006, -H / 2 + 0.09, 0]}>
        <boxGeometry args={[0.03, 0.05, W / 2 - 0.02]} />
      </mesh>
      <mesh material={m.seal} position={[0.004, 0, -side * (W / 4 - 0.012)]}>
        <boxGeometry args={[0.02, H - 0.12, 0.012]} />
      </mesh>
      {/* two locking bars per leaf with cam keepers and handles */}
      {[0.06, 0.18].map((o) => (
        <group key={o} position={[-0.03, 0, side * (o - W / 4 + 0.02)]}>
          <mesh material={m.chrome} castShadow={shadows}>
            <cylinderGeometry args={[0.011, 0.011, H - 0.08, 10]} />
          </mesh>
          {[H / 2 - 0.07, -H / 2 + 0.07].map((y) => (
            <mesh key={y} material={pbr.frameSteel} position={[0.012, y, 0]}>
              <boxGeometry args={[0.03, 0.05, 0.04]} />
            </mesh>
          ))}
          <mesh material={m.chrome} position={[-0.02, -0.06, side * 0.03]} rotation={[0.25 * side, 0, 0]}>
            <boxGeometry args={[0.014, 0.16, 0.018]} />
          </mesh>
        </group>
      ))}
      {/* hinges on the outer edge */}
      {[-0.33, -0.1, 0.13, 0.36].map((y) => (
        <mesh key={y} material={pbr.frameSteel} position={[-0.012, y, side * (W / 4 - 0.01)]}>
          <cylinderGeometry args={[0.014, 0.014, 0.07, 10]} />
        </mesh>
      ))}
    </group>
  );

  return (
    <group ref={refs.group}>
      {/* long sides with the painted logo */}
      <mesh geometry={m.sideGeo} material={pbr.containerPaint} position={[0, 0, W / 2 - RIB]} castShadow={shadows} receiveShadow={shadows}>
        <Decal position={[0, 0.02, RIB]} rotation={[0, 0, 0]} scale={[DECAL_W, DECAL_H, 0.12]} material={m.decal} />
        <Decal position={[0.88, 0.37, RIB]} rotation={[0, 0, 0]} scale={[0.36, 0.18, 0.12]} material={m.marks} />
      </mesh>
      <mesh geometry={m.sideGeo} material={pbr.containerPaint} position={[0, 0, -W / 2 + RIB]} rotation={[0, Math.PI, 0]} castShadow={shadows} receiveShadow={shadows}>
        <Decal position={[0, 0.02, RIB]} rotation={[0, 0, 0]} scale={[DECAL_W, DECAL_H, 0.12]} material={m.decal} />
      </mesh>
      {/* front end wall */}
      <mesh geometry={m.endGeo} material={pbr.containerPaint} position={[L / 2 - RIB, 0, 0]} rotation={[0, Math.PI / 2, 0]} castShadow={shadows} />
      {/* roof + floor */}
      <mesh geometry={m.roofGeo} material={pbr.containerPaint} position={[0, H / 2 - 0.03, 0]} castShadow={shadows} receiveShadow={shadows} />
      <mesh material={pbr.frameSteel} position={[0, -H / 2 + 0.03, 0]}>
        <boxGeometry args={[L - 0.04, 0.06, W - 0.04]} />
      </mesh>

      {/* frame: corner posts, top and bottom rails */}
      {posts.map(([x, z], i) => (
        <mesh key={i} material={pbr.frameSteel} position={[x, 0, z]} castShadow={shadows}>
          <boxGeometry args={[f, H, f]} />
        </mesh>
      ))}
      {[H / 2 - f / 2, -H / 2 + f / 2].map((y) =>
        [W / 2 - f / 2, -W / 2 + f / 2].map((z) => (
          <mesh key={`${y}${z}`} material={pbr.frameSteel} position={[0, y, z]} castShadow={shadows}>
            <boxGeometry args={[L, y < 0 ? f * 1.5 : f, f]} />
          </mesh>
        )),
      )}
      {[H / 2 - f / 2, -H / 2 + f / 2].map((y) =>
        [L / 2 - f / 2, -L / 2 + f / 2].map((x) => (
          <mesh key={`${y}${x}`} material={pbr.frameSteel} position={[x, y, 0]}>
            <boxGeometry args={[f, f * 1.3, W]} />
          </mesh>
        )),
      )}
      {/* door header & sill */}
      <mesh material={pbr.frameSteel} position={[-L / 2 + 0.01, H / 2 - 0.06, 0]}>
        <boxGeometry args={[0.04, 0.1, W]} />
      </mesh>
      {/* forklift pockets */}
      {[-0.55, 0.55].map((x) =>
        [W / 2, -W / 2].map((z) => (
          <mesh key={`${x}${z}`} material={m.hole} position={[x, -H / 2 + 0.05, z]}>
            <boxGeometry args={[0.18, 0.05, 0.004]} />
          </mesh>
        )),
      )}
      {/* ISO corner castings with apertures */}
      {castings.map((c, i) => (
        <group key={i} position={c}>
          <mesh material={m.casting}>
            <boxGeometry args={[0.09, 0.09, 0.09]} />
          </mesh>
          <mesh material={m.hole} position={[0, 0, Math.sign(c[2]) * 0.046]}>
            <boxGeometry args={[0.045, 0.026, 0.002]} />
          </mesh>
          <mesh material={m.hole} position={[0, Math.sign(c[1]) * 0.046, 0]}>
            <boxGeometry args={[0.05, 0.002, 0.028]} />
          </mesh>
        </group>
      ))}

      {/* warm interior revealed when the doors open */}
      <mesh position={[-L / 2 + 0.02, 0, 0]} rotation={[0, -Math.PI / 2, 0]} material={m.glow}>
        <planeGeometry args={[W - 0.1, H - 0.1]} />
      </mesh>

      {/* rear doors, hinged on the outer edges */}
      <group ref={refs.doorL} position={[-L / 2 - 0.006, 0, W / 2 - 0.02]}>
        {leaf(1)}
      </group>
      <group ref={refs.doorR} position={[-L / 2 - 0.006, 0, -W / 2 + 0.02]}>
        {leaf(-1)}
      </group>

      {/* light spilling onto the ground when the doors open */}
      <mesh position={[-L / 2 - 1.6, -1.265, 0]} rotation={[-Math.PI / 2, 0, 0]} geometry={m.spillGeo}>
        <meshBasicMaterial ref={refs.spillMat} color="#f3d28e" transparent opacity={0} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} alphaMap={radialAlpha()} />
      </mesh>
      <pointLight ref={refs.light} position={[-L / 2 - 0.3, 0.1, 0]} color="#ffcf80" intensity={0} distance={7} decay={1.5} />
    </group>
  );
}

let _radial: THREE.CanvasTexture | null = null;
function radialAlpha() {
  if (_radial) return _radial;
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(128, 64, 4, 100, 64, 110);
  grd.addColorStop(0, "#fff");
  grd.addColorStop(1, "#000");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  _radial = new THREE.CanvasTexture(c);
  return _radial;
}
