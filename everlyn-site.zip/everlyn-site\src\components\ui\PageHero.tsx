"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { RevealText } from "./Reveal";
import { Emblem } from "../Logo";

const ease = [0.22, 1, 0.36, 1] as const;

type Crumb = { label: string; href?: string };

export function PageHero({
  eyebrow,
  title,
  intro,
  crumbs = [],
  children,
}: {
  eyebrow: string;
  title: string;
  intro?: string;
  crumbs?: Crumb[];
  children?: React.ReactNode;
}) {
  return (
    <section className="relative overflow-hidden pb-20 pt-36 md:pb-28 md:pt-48">
      {/* slow-turning emblem watermark */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -right-28 top-10 text-forest/[0.07] md:-right-10"
        initial={{ opacity: 0, rotate: -20, scale: 0.9 }}
        animate={{ opacity: 1, rotate: 0, scale: 1 }}
        transition={{ duration: 2.4, ease }}
      >
        <Emblem className="h-[26rem] w-[26rem] md:h-[34rem] md:w-[34rem]" strokeWidth={0.8} />
      </motion.div>

      {/* a shipping route drawing itself across the hero */}
      <svg aria-hidden className="pointer-events-none absolute inset-x-0 bottom-6 h-40 w-full" viewBox="0 0 1440 160" preserveAspectRatio="none" fill="none">
        <motion.path
          d="M-20 130 C 260 40, 520 150, 760 80 S 1220 20, 1460 70"
          stroke="#b08d57"
          strokeWidth="1"
          strokeDasharray="2 6"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.7 }}
          transition={{ duration: 2.8, ease, delay: 0.4 }}
        />
      </svg>

      <div className="container-lux relative">
        {crumbs.length > 0 && (
          <motion.nav
            aria-label="Breadcrumb"
            className="mb-8 text-[0.7rem] uppercase tracking-[0.2em] text-ink/50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
          >
            <ol className="flex flex-wrap items-center gap-2">
              <li>
                <Link href="/" className="link-underline hover:text-forest-deep">Home</Link>
              </li>
              {crumbs.map((c) => (
                <li key={c.label} className="flex items-center gap-2">
                  <span aria-hidden>/</span>
                  {c.href ? (
                    <Link href={c.href} className="link-underline hover:text-forest-deep">{c.label}</Link>
                  ) : (
                    <span aria-current="page" className="text-forest-deep">{c.label}</span>
                  )}
                </li>
              ))}
            </ol>
          </motion.nav>
        )}
        <motion.p className="eyebrow mb-6" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, ease, delay: 0.3 }}>
          {eyebrow}
        </motion.p>
        <RevealText as="h1" immediate delay={0.35} text={title} className="display max-w-5xl text-[2.9rem] text-forest-deep sm:text-6xl lg:text-[5.5rem]" />
        {intro && (
          <motion.p
            className="mt-8 max-w-2xl text-lg leading-relaxed text-ink/70"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.1, ease, delay: 0.8 }}
          >
            {intro}
          </motion.p>
        )}
        {children && (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.1, ease, delay: 1 }} className="mt-10">
            {children}
          </motion.div>
        )}
      </div>
    </section>
  );
}

export function SectionHeading({ eyebrow, title, intro, light, className = "" }: { eyebrow: string; title: string; intro?: string; light?: boolean; className?: string }) {
  return (
    <div className={`max-w-3xl ${className}`}>
      <p className="eyebrow mb-5">{eyebrow}</p>
      <RevealText text={title} className={`display text-4xl sm:text-5xl lg:text-6xl ${light ? "text-ivory" : "text-forest-deep"}`} />
      {intro && <p className={`mt-6 text-lg leading-relaxed ${light ? "text-ivory/70" : "text-ink/70"}`}>{intro}</p>}
    </div>
  );
}
