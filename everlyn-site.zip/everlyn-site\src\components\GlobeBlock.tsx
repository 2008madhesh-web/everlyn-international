"use client";

import dynamic from "next/dynamic";

const InteractiveGlobe = dynamic(() => import("./three/InteractiveGlobe"), {
  ssr: false,
  loading: () => <div className="h-full w-full animate-pulse rounded-full bg-forest/10" />,
});

export function GlobeBlock() {
  return (
    <div className="relative aspect-square w-full max-w-[640px] cursor-grab active:cursor-grabbing" data-lenis-prevent-touch>
      <InteractiveGlobe />
      <p className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 text-[0.65rem] uppercase tracking-[0.24em] text-ink/45">Drag to explore</p>
    </div>
  );
}
