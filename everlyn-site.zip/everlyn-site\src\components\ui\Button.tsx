"use client";

import Link from "next/link";
import { useRef } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

type Variant = "primary" | "outline" | "light" | "ghost";

type Props = {
  children: React.ReactNode;
  href?: string;
  onClick?: () => void;
  type?: "button" | "submit";
  variant?: Variant;
  className?: string;
  arrow?: boolean;
  disabled?: boolean;
  external?: boolean;
};

const styles: Record<Variant, { base: string; fill: string; hoverText: string }> = {
  primary: {
    base: "bg-forest-deep text-ivory border border-forest-deep",
    fill: "bg-brass",
    hoverText: "group-hover:text-forest-ink",
  },
  outline: {
    base: "bg-transparent text-forest-deep border border-forest-deep/40",
    fill: "bg-forest-deep",
    hoverText: "group-hover:text-ivory",
  },
  light: {
    base: "bg-ivory text-forest-deep border border-ivory",
    fill: "bg-brass",
    hoverText: "group-hover:text-forest-ink",
  },
  ghost: {
    base: "bg-transparent text-ivory border border-ivory/40",
    fill: "bg-ivory",
    hoverText: "group-hover:text-forest-deep",
  },
};

/** Magnetic pill button with a fill sweep on hover. */
export function Button({ children, href, onClick, type = "button", variant = "primary", className, arrow, disabled, external }: Props) {
  const ref = useRef<HTMLSpanElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 220, damping: 18, mass: 0.4 });
  const sy = useSpring(y, { stiffness: 220, damping: 18, mass: 0.4 });

  const onMove = (e: React.PointerEvent) => {
    if (e.pointerType !== "mouse" || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    x.set((e.clientX - (r.left + r.width / 2)) * 0.25);
    y.set((e.clientY - (r.top + r.height / 2)) * 0.35);
  };
  const reset = () => {
    x.set(0);
    y.set(0);
  };

  const s = styles[variant];
  const inner = (
    <motion.span
      ref={ref}
      style={{ x: sx, y: sy }}
      onPointerMove={onMove}
      onPointerLeave={reset}
      data-cursor="hover"
      className={`group relative inline-flex items-center justify-center gap-3 overflow-hidden rounded-full px-7 py-3.5 text-[0.8rem] font-medium tracking-[0.14em] uppercase transition-colors duration-500 ${s.base} ${disabled ? "opacity-50 pointer-events-none" : ""} ${className ?? ""}`}
    >
      <span
        aria-hidden
        className={`absolute inset-0 translate-y-[101%] rounded-[inherit] transition-transform duration-[650ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-y-0 ${s.fill}`}
      />
      <span className={`relative z-10 transition-colors duration-500 ${s.hoverText}`}>{children}</span>
      {arrow && (
        <span className={`relative z-10 inline-block overflow-hidden transition-colors duration-500 ${s.hoverText}`} aria-hidden>
          <span className="flex transition-transform duration-500 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-x-1">
            <svg width="16" height="10" viewBox="0 0 16 10" fill="none" stroke="currentColor" strokeWidth="1.3">
              <path d="M0 5h14M10 1l4 4-4 4" />
            </svg>
          </span>
        </span>
      )}
    </motion.span>
  );

  if (href) {
    if (external) {
      return (
        <a href={href} target="_blank" rel="noopener noreferrer" className="inline-block">
          {inner}
        </a>
      );
    }
    return (
      <Link href={href} className="inline-block">
        {inner}
      </Link>
    );
  }
  return (
    <button type={type} onClick={onClick} disabled={disabled} className="inline-block">
      {inner}
    </button>
  );
}

/** Text link with an animated arrow. */
export function ArrowLink({ href, children, className }: { href: string; children: React.ReactNode; className?: string }) {
  return (
    <Link
      href={href}
      data-cursor="hover"
      className={`group inline-flex items-center gap-3 text-[0.78rem] font-medium uppercase tracking-[0.18em] ${className ?? "text-forest-deep"}`}
    >
      <span className="link-underline">{children}</span>
      <span className="relative flex h-8 w-8 items-center justify-center rounded-full border border-current/30 transition-all duration-500 group-hover:border-current group-hover:translate-x-1">
        <svg width="12" height="10" viewBox="0 0 16 10" fill="none" stroke="currentColor" strokeWidth="1.4">
          <path d="M0 5h14M10 1l4 4-4 4" />
        </svg>
      </span>
    </Link>
  );
}
