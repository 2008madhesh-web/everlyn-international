import { z } from "zod";

const name = z.string().trim().min(2, "Please enter your name").max(120);
const email = z.email("Please enter a valid email").max(200);
const phone = z.string().trim().max(40).optional().or(z.literal(""));
const company = z.string().trim().max(160).optional().or(z.literal(""));
const country = z.string().trim().max(80).optional().or(z.literal(""));

export const contactSchema = z.object({
  kind: z.literal("contact"),
  name,
  email,
  phone,
  company,
  country,
  subject: z.enum(["Export enquiry", "Import enquiry", "Samples", "Partnership", "Other"]),
  message: z.string().trim().min(10, "Tell us a little more (at least 10 characters)").max(4000),
  website: z.string().max(0).optional(), // honeypot
});

export const quoteSchema = z.object({
  kind: z.literal("quote"),
  tradeType: z.enum(["Export from India", "Import into India"]),
  category: z.string().min(1, "Choose a category"),
  product: z.string().trim().min(2, "Describe the product").max(400),
  quantity: z.string().trim().min(1, "Enter a quantity").max(60),
  unit: z.enum(["MT", "kg", "Pieces", "Containers (20 ft)", "Containers (40 ft)"]),
  packaging: z.string().trim().max(200).optional().or(z.literal("")),
  destinationCountry: z.string().trim().min(2, "Enter a country").max(80),
  destinationPort: z.string().trim().max(80).optional().or(z.literal("")),
  incoterm: z.enum(["EXW", "FOB", "CFR", "CIF", "DDP", "Not sure"]),
  timeline: z.enum(["Within 2 weeks", "Within a month", "1–3 months", "Just exploring"]),
  name,
  email,
  phone,
  company,
  notes: z.string().trim().max(4000).optional().or(z.literal("")),
  website: z.string().max(0).optional(),
});

export const enquirySchema = z.discriminatedUnion("kind", [contactSchema, quoteSchema]);

export type ContactInput = z.infer<typeof contactSchema>;
export type QuoteInput = z.infer<typeof quoteSchema>;
