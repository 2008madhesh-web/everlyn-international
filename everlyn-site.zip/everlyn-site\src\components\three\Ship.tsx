"use client";

import { useLayoutEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Decal } from "@react-three/drei";
import * as THREE from "three";
import { deckGeometry, deckHeight, halfBeamAt, hullGeometry, type HullSpec } from "./geometry";
import { hullLetteringTexture, usePBR, windowsGlowTexture, windowsTexture } from "./materials";
import { night } from "./night";
import { ContainerStacks, LIVERIES, rng, type Stack } from "./Port";
import { DECK_Y, WATER_Y } from "@/lib/story";

export const HULL: HullSpec = { bow: -16.5, stern: 13.6, beam: 5.4, depth: 3.1, deckY: DECK_Y };
const BAYS = [-10.2, -7.65, -5.1, -2.55, 0, 2.55, 5.1, 7.65];
const ROWS = [-2.2, -1.1, 0, 1.1, 2.2];
const HATCH_TOP = DECK_Y + 0.1;

/** A feeder container ship, bow toward -x. Group origin sits on the waterline datum. */
export function Ship({ groupRef, wakeRef, shadows, lite }: { groupRef: React.RefObject<THREE.Group | null>; wakeRef: React.RefObject<THREE.MeshBasicMaterial | null>; shadows: boolean; lite: boolean }) {
  const pbr = usePBR();
  const radar = useRef<THREE.Group>(null);

  const m = useMemo(() => {
    const { geometry } = hullGeometry(HULL, WATER_Y, { top: "#10392d", boot: "#e9e2d2", bottom: "#7a2b22" });
    const deckGeo = deckGeometry(HULL);
    const white = new THREE.MeshStandardMaterial({ color: "#efebe2", roughness: 0.55, metalness: 0.15 });
    const win = windowsTexture();
    win.wrapS = win.wrapT = THREE.RepeatWrapping;
    const glow = windowsGlowTexture();
    glow.wrapS = glow.wrapT = THREE.RepeatWrapping;
    const face = (rx: number) => {
      const map = win.clone();
      map.repeat.set(rx, 1.5);
      map.needsUpdate = true;
      const em = glow.clone();
      em.repeat.set(rx, 1.5);
      em.needsUpdate = true;
      return new THREE.MeshStandardMaterial({ map, emissiveMap: em, emissive: "#ffcf8a", emissiveIntensity: 0, roughness: 0.5, metalness: 0.1 });
    };
    const facadeEnds = face(2.4);
    const facadeSides = face(2);
    const roofMat = new THREE.MeshStandardMaterial({ color: "#efebe2", roughness: 0.6 });
    const facade = [facadeEnds, facadeEnds, roofMat, roofMat, facadeSides, facadeSides];
    const glass = new THREE.MeshPhysicalMaterial({ color: "#1c2827", roughness: 0.04, metalness: 0.3, envMapIntensity: 1.8 });
    const grey = new THREE.MeshStandardMaterial({ color: "#5e6461", roughness: 0.6, metalness: 0.5 });
    const dark = new THREE.MeshStandardMaterial({ color: "#1d201e", roughness: 0.6, metalness: 0.4 });
    const emerald = new THREE.MeshStandardMaterial({ color: "#1f5c47", roughness: 0.45, metalness: 0.3 });
    const brass = new THREE.MeshStandardMaterial({ color: "#b08d57", roughness: 0.3, metalness: 0.9 });
    const orange = new THREE.MeshStandardMaterial({ color: "#d4682a", roughness: 0.45 });
    const lettering = new THREE.MeshStandardMaterial({ map: hullLetteringTexture("EVERLYN", "#efe6d2", 90), transparent: true, roughness: 0.5, polygonOffset: true, polygonOffsetFactor: -6, depthWrite: false });
    const name = new THREE.MeshStandardMaterial({ map: hullLetteringTexture("EVERLYN GRACE", "#efe6d2", 26), transparent: true, roughness: 0.5, polygonOffset: true, polygonOffsetFactor: -6, depthWrite: false });
    return { hullGeo: geometry, deckGeo, white, facade, facadeEnds, facadeSides, glass, grey, dark, emerald, brass, orange, lettering, name, win };
  }, []);

  const cargo = useMemo(() => {
    const r = rng(42);
    const out: Stack[] = [];
    for (const x of BAYS)
      for (const z of ROWS) {
        if (Math.abs(z) > 2 && x < -7) continue; // narrow bow
        const ours = x === 0 && z === 0;
        const tiers = ours ? 1 : 1 + Math.floor(r() * (lite ? 2 : 3));
        for (let t = 0; t < tiers; t++) out.push({ p: [x, HATCH_TOP + 0.5 + t, z], c: LIVERIES[Math.floor(r() * LIVERIES.length)] });
      }
    return out;
  }, [lite]);

  // railings along both sides of the deck
  const rails = useMemo(() => {
    const posts: THREE.Matrix4[] = [];
    const pts: Record<string, THREE.Vector3[]> = { a: [], b: [] };
    for (let x = HULL.bow + 1.2; x < 13; x += 0.45) {
      const b = halfBeamAt(x, HULL) - 0.06;
      const t = (x - HULL.bow) / (HULL.stern - HULL.bow);
      const y = deckHeight(t, DECK_Y);
      for (const s of [1, -1]) {
        posts.push(new THREE.Matrix4().makeTranslation(x, y + 0.13, s * b));
        pts[s > 0 ? "a" : "b"].push(new THREE.Vector3(x, y + 0.26, s * b));
      }
    }
    const tubes = Object.values(pts).map((p) => new THREE.TubeGeometry(new THREE.CatmullRomCurve3(p), 120, 0.008, 5, false));
    return { posts, tubes };
  }, []);
  const postsRef = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    rails.posts.forEach((mx, i) => postsRef.current!.setMatrixAt(i, mx));
    postsRef.current!.instanceMatrix.needsUpdate = true;
  }, [rails]);

  // wake: a soft foam trail fading away behind the stern
  const wakeTex = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = 256;
    c.height = 64;
    const g = c.getContext("2d")!;
    const grd = g.createLinearGradient(0, 0, 256, 0);
    grd.addColorStop(0, "rgba(255,255,255,0.9)");
    grd.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = grd;
    const rand = rng(9);
    for (let i = 0; i < 900; i++) {
      const x = rand() * 256;
      const spread = 6 + x * 0.1;
      g.globalAlpha = 0.25 * (1 - x / 256);
      g.fillRect(x, 32 + (rand() - 0.5) * spread * 2, 3, 1.5);
    }
    g.globalAlpha = 1;
    const t = new THREE.CanvasTexture(c);
    return t;
  }, []);

  useFrame((_, dt) => {
    if (radar.current) radar.current.rotation.y += dt * 1.6;
    // cabin windows light up after sunset
    m.facadeEnds.emissiveIntensity = m.facadeSides.emissiveIntensity = night.value * 1.6;
  });

  const accX = 10.4;
  return (
    <group ref={groupRef}>
      {/* hull with painted lettering */}
      <mesh geometry={m.hullGeo} material={pbr.hull} castShadow={shadows} receiveShadow={shadows}>
        <Decal position={[-1.5, -0.56, HULL.beam / 2]} rotation={[0, 0, 0]} scale={[11, 1.4, 1.4]} material={m.lettering} />
        <Decal position={[-1.5, -0.56, -HULL.beam / 2]} rotation={[0, Math.PI, 0]} scale={[11, 1.4, 1.4]} material={m.lettering} />
        <Decal position={[-13.6, -0.2, 1.9]} rotation={[0, 0.35, 0]} scale={[3.4, 0.42, 1.2]} material={m.name} />
        <Decal position={[13.62, -0.6, 0]} rotation={[0, Math.PI / 2, 0]} scale={[3.2, 0.4, 0.6]} material={m.name} />
      </mesh>
      {/* bulbous bow */}
      <mesh position={[-16.3, DECK_Y - 2.55, 0]} scale={[1.5, 0.48, 0.42]}>
        <sphereGeometry args={[1, 24, 16]} />
        <meshStandardMaterial color="#7a2b22" roughness={0.85} />
      </mesh>
      <mesh geometry={m.deckGeo} material={pbr.deck} receiveShadow={shadows} />

      {/* hatch covers and lashing bridges */}
      {BAYS.map((x) => (
        <group key={x}>
          <mesh material={m.grey} position={[x, DECK_Y + 0.05, 0]} receiveShadow={shadows} castShadow={shadows}>
            <boxGeometry args={[2.46, 0.1, x < -7 ? 3.6 : 5.0]} />
          </mesh>
          {x > -9 && (
            <mesh material={m.grey} position={[x + 1.27, DECK_Y + 0.75, 0]} castShadow={shadows}>
              <boxGeometry args={[0.08, 1.3, 5.1]} />
            </mesh>
          )}
        </group>
      ))}
      <ContainerStacks items={cargo} shadows={shadows} />

      {/* forecastle: breakwater, winches, anchor */}
      <mesh material={m.white} position={[-12.3, DECK_Y + 0.75, 0]} rotation={[0, 0, -0.15]} castShadow={shadows}>
        <boxGeometry args={[0.06, 0.7, 3.8]} />
      </mesh>
      {[0.8, -0.8].map((z) => (
        <mesh key={z} material={m.dark} position={[-14.2, DECK_Y + 0.5, z]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.16, 0.16, 0.36, 16]} />
        </mesh>
      ))}
      {[1, -1].map((s) => (
        <mesh key={s} material={m.dark} position={[-14.9, DECK_Y - 0.25, s * 1.62]} rotation={[0, 0, 0.2]}>
          <boxGeometry args={[0.25, 0.45, 0.08]} />
        </mesh>
      ))}

      {/* accommodation block and bridge */}
      <group position={[accX, DECK_Y, 0]}>
        <mesh position={[0, 2.25, 0]} material={m.facade} castShadow={shadows} receiveShadow={shadows}>
          <boxGeometry args={[2.4, 4.5, 4.6]} />
        </mesh>
        {/* navigation bridge with wings */}
        <mesh material={m.white} position={[-0.1, 4.85, 0]} castShadow={shadows}>
          <boxGeometry args={[2.0, 0.7, 6.4]} />
        </mesh>
        <mesh material={m.glass} position={[-1.11, 4.9, 0]}>
          <boxGeometry args={[0.02, 0.36, 6.2]} />
        </mesh>
        <mesh material={m.white} position={[-0.1, 5.25, 0]}>
          <boxGeometry args={[2.1, 0.08, 6.5]} />
        </mesh>
        {/* mast with rotating radar */}
        <mesh material={m.white} position={[0.2, 6.05, 0]}>
          <cylinderGeometry args={[0.05, 0.07, 1.6, 10]} />
        </mesh>
        <mesh material={m.white} position={[0.2, 6.3, 0]}>
          <boxGeometry args={[0.08, 0.06, 1.4]} />
        </mesh>
        <group ref={radar} position={[0.2, 6.9, 0]}>
          <mesh material={m.dark}>
            <boxGeometry args={[0.08, 0.06, 0.9]} />
          </mesh>
        </group>
        {/* funnel in Everlyn colours */}
        <group position={[1.55, 4.0, 0]}>
          <mesh material={m.emerald} castShadow={shadows}>
            <boxGeometry args={[1.0, 2.6, 1.3]} />
          </mesh>
          <mesh material={m.brass} position={[0, 0.6, 0]}>
            <boxGeometry args={[1.02, 0.18, 1.32]} />
          </mesh>
          <mesh material={m.dark} position={[0, 1.36, 0]}>
            <boxGeometry args={[1.02, 0.14, 1.32]} />
          </mesh>
        </group>
        {/* free-fall lifeboat on its ramp at the stern */}
        <group position={[2.6, 1.6, 0]} rotation={[0, 0, -0.5]}>
          <mesh material={m.grey} position={[0, -0.25, 0]}>
            <boxGeometry args={[1.6, 0.06, 0.6]} />
          </mesh>
          <mesh material={m.orange} rotation={[0, 0, Math.PI / 2]} castShadow={shadows}>
            <capsuleGeometry args={[0.24, 1.0, 8, 16]} />
          </mesh>
        </group>
      </group>

      {/* railings */}
      <instancedMesh ref={postsRef} args={[undefined, m.white, rails.posts.length]}>
        <cylinderGeometry args={[0.008, 0.008, 0.26, 4]} />
      </instancedMesh>
      {rails.tubes.map((g, i) => (
        <mesh key={i} geometry={g} material={m.white} />
      ))}

      {/* wake trailing from the stern */}
      <mesh position={[HULL.stern + 9, WATER_Y + 0.03, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[18, 7]} />
        <meshBasicMaterial ref={wakeRef} map={wakeTex} transparent opacity={0} depthWrite={false} />
      </mesh>
    </group>
  );
}
