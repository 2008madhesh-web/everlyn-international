import Link from "next/link";
import { Emblem, LogoStacked } from "./Logo";
import { company, contact, footerNav, socials } from "@/content/site";
import { Button } from "./ui/Button";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="relative z-10 overflow-hidden bg-forest-ink text-ivory">
      <Emblem className="pointer-events-none absolute -right-40 -top-40 h-[34rem] w-[34rem] text-ivory/[0.035]" strokeWidth={1} />

      <div className="container-lux relative pt-24 pb-10">
        <div className="flex flex-col items-start justify-between gap-10 border-b border-ivory/10 pb-16 md:flex-row md:items-end">
          <div>
            <p className="eyebrow mb-5">Ready when you are</p>
            <h2 className="display max-w-2xl text-4xl sm:text-5xl md:text-6xl">
              Let&rsquo;s move your next shipment, <em className="text-brass-light">together.</em>
            </h2>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button href="/quote" variant="light" arrow>Request a Quote</Button>
            <Button href={`https://wa.me/${contact.whatsapp}`} variant="ghost" external>WhatsApp</Button>
          </div>
        </div>

        <div className="grid gap-12 py-16 md:grid-cols-12">
          <div className="md:col-span-4">
            <Link href="/" aria-label="Home" className="text-ivory">
              <LogoStacked className="scale-[0.7] origin-top-left" />
            </Link>
            <p className="-mt-6 max-w-xs text-sm leading-relaxed text-ivory/60">{company.description}</p>
          </div>

          {Object.entries(footerNav).map(([group, links]) => (
            <div key={group} className="md:col-span-2">
              <p className="eyebrow mb-5">{group}</p>
              <ul className="space-y-3 text-sm text-ivory/75">
                {links.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="link-underline hover:text-ivory">{l.label}</Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div className="md:col-span-2">
            <p className="eyebrow mb-5">Office</p>
            <address className="space-y-1 text-sm not-italic text-ivory/75">
              {contact.addressLines.slice(1).map((l) => (
                <span key={l} className="block">{l}</span>
              ))}
              <a href={`mailto:${contact.email}`} className="link-underline mt-3 block w-fit hover:text-ivory">{contact.email}</a>
              <a href={contact.phoneHref} className="link-underline block w-fit hover:text-ivory">{contact.phone}</a>
            </address>
          </div>
        </div>

        <div className="flex flex-col gap-4 border-t border-ivory/10 pt-8 text-xs text-ivory/45 md:flex-row md:items-center md:justify-between">
          <p>© {year} {company.name}. All rights reserved. · {contact.iec} · {contact.gst}</p>
          <ul className="flex gap-6">
            {socials.map((s) => (
              <li key={s.label}>
                <a href={s.href} className="link-underline uppercase tracking-[0.18em] hover:text-ivory">{s.label}</a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  );
}
