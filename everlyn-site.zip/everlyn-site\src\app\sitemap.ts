import type { MetadataRoute } from "next";
import { company, products } from "@/content/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const pages = ["", "/about", "/products", "/services", "/global-network", "/quality", "/industries", "/contact", "/quote", "/faq", "/careers", "/privacy", "/terms"];
  const now = new Date();
  return [
    ...pages.map((p) => ({ url: `${company.url}${p}`, lastModified: now, changeFrequency: "monthly" as const, priority: p === "" ? 1 : 0.7 })),
    ...products.map((p) => ({ url: `${company.url}/products/${p.slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.8 })),
  ];
}
