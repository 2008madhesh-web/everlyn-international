"use client";

import { usePathname } from "next/navigation";
import { motion } from "framer-motion";

const ease = [0.22, 1, 0.36, 1] as const;

/**
 * Runs on every navigation: an emerald curtain lifts away and the page settles in.
 * The home page is excluded: it has its own loading screen, which must be visible from the
 * very first paint so the logo bloom can be seen from its first petal.
 */
export default function Template({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  if (pathname === "/") return <>{children}</>;
  return (
    <>
      <motion.div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-[55] origin-top bg-forest-deep"
        initial={{ scaleY: 1 }}
        animate={{ scaleY: 0 }}
        transition={{ duration: 0.9, ease, delay: 0.05 }}
        style={{ transformOrigin: "top" }}
      />
      {/* opacity only: a transform here would break position:fixed/sticky children */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, ease, delay: 0.2 }}>
        {children}
      </motion.div>
    </>
  );
}
