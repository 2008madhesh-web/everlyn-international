import type { Metadata } from "next";
import { LegalPage } from "@/components/ui/LegalPage";
import { company } from "@/content/site";

export const metadata: Metadata = { title: "Terms of Trade" };

// TODO: have this template reviewed by your legal adviser before launch.
export default function TermsPage() {
  return (
    <LegalPage
      title="Terms of Trade"
      updated="November 2026"
      sections={[
        {
          h: "Scope",
          p: [`These terms apply to the use of this website and to quotations issued by ${company.name}. Each confirmed order is also governed by the sales contract or proforma invoice agreed for it, which takes precedence where the two differ.`],
        },
        {
          h: "Quotations",
          p: [
            "Quotations are valid for the period stated on them. Prices depend on market conditions, exchange rates and freight rates, and may be revised before an order is confirmed in writing.",
          ],
        },
        {
          h: "Orders & payment",
          p: [
            "An order is confirmed when both parties sign the sales contract or proforma invoice and any agreed advance payment is received.",
            "Payment terms, such as advance, documents against payment or letter of credit, are set out in the sales contract.",
          ],
        },
        {
          h: "Delivery & risk",
          p: [
            "Delivery terms follow the Incoterms® 2020 rule named in the contract. Risk passes to the buyer at the point defined by that rule.",
          ],
        },
        {
          h: "Quality & claims",
          p: [
            "Goods are supplied to the specification and approved sample agreed in the contract. Any quality claim must be raised in writing within the period stated in the contract, supported by an independent survey report.",
          ],
        },
        {
          h: "Website content",
          p: [
            "Product descriptions and specifications on this website are for general information and do not form part of any contract. Content may change without notice.",
          ],
        },
        {
          h: "Governing law",
          p: ["Unless otherwise agreed in the sales contract, these terms are governed by the laws of India."],
        },
      ]}
    />
  );
}
