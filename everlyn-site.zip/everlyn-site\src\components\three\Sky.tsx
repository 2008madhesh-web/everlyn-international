"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

/**
 * Shared sky state. The same uniform objects are used by the sky dome and the ocean,
 * so the water always reflects exactly the sky above it (afternoon, sunset or night).
 */
export const skyUniforms = {
  uEnv: { value: null as THREE.Texture | null },
  uEnvRot: { value: 0 },
  uDayIntensity: { value: 0.85 },
  uDusk: { value: 0 },
  uNight: { value: 0 },
  uSunDir: { value: new THREE.Vector3(0, 0.05, -1) },
  uMoonDir: { value: new THREE.Vector3(0, 0.4, -1).normalize() },
  uKeyDir: { value: new THREE.Vector3(0, 1, 0) },
  uKeyColor: { value: new THREE.Color(1, 0.9, 0.7) },
  uTime: { value: 0 },
};

/** GLSL: `vec3 skyColor(vec3 dir)`, plus helpers, driven by `skyUniforms`. */
export const SKY_GLSL = /* glsl */ `
  uniform sampler2D uEnv;
  uniform float uEnvRot;
  uniform float uDayIntensity;
  uniform float uDusk;
  uniform float uNight;
  uniform vec3 uSunDir;
  uniform vec3 uMoonDir;
  uniform float uTime;

  float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
  }
  float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
  }
  float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash12(i), hash12(i + vec2(1.0, 0.0)), u.x), mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0, 1.0)), u.x), u.y);
  }
  float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; i++) {
      v += a * vnoise(p);
      p = p * 2.03 + vec2(17.1, 9.2);
      a *= 0.5;
    }
    return v;
  }

  vec3 skyDay(vec3 d) {
    float c = cos(uEnvRot);
    float s = sin(uEnvRot);
    vec3 r = vec3(c * d.x + s * d.z, d.y, -s * d.x + c * d.z);
    vec2 uv = vec2(atan(r.z, r.x) * 0.15915494 + 0.5, asin(clamp(r.y, -1.0, 1.0)) * 0.31830988 + 0.5);
    return texture2D(uEnv, uv).rgb * uDayIntensity;
  }

  vec3 skyDusk(vec3 d) {
    float h = clamp(d.y, 0.0, 1.0);
    float t = pow(h, 0.45);
    vec3 hor = vec3(1.25, 0.46, 0.15);
    vec3 mid = vec3(0.34, 0.12, 0.17);
    vec3 zen = vec3(0.025, 0.035, 0.1);
    vec3 col = mix(hor, mid, smoothstep(0.0, 0.32, t));
    col = mix(col, zen, smoothstep(0.3, 1.0, t));
    vec2 az = normalize(d.xz + 1e-5);
    vec2 saz = normalize(uSunDir.xz);
    float toward = max(dot(az, saz), 0.0);
    col += vec3(0.9, 0.3, 0.09) * pow(toward, 6.0) * (1.0 - smoothstep(0.0, 0.4, h));
    float cs = dot(d, uSunDir);
    col += vec3(16.0, 7.5, 2.4) * smoothstep(0.99935, 0.9996, cs);   // sun disc
    col += vec3(1.8, 0.7, 0.22) * pow(max(cs, 0.0), 300.0);          // corona
    col += vec3(0.55, 0.2, 0.07) * pow(max(cs, 0.0), 22.0);          // glow
    col = mix(col, vec3(0.2, 0.09, 0.08), smoothstep(0.0, -0.12, d.y));
    return col;
  }

  vec3 skyNight(vec3 d) {
    float h = clamp(d.y, 0.0, 1.0);
    vec3 col = mix(vec3(0.028, 0.045, 0.07), vec3(0.004, 0.008, 0.02), pow(h, 0.5));
    col += vec3(0.11, 0.065, 0.035) * pow(1.0 - h, 10.0);           // glow of the city on the horizon
    // stars
    vec3 p = d * 220.0;
    vec3 cell = floor(p);
    float rnd = hash13(cell);
    float dist = length(fract(p) - 0.5);
    float twinkle = 0.55 + 0.45 * sin(uTime * (2.0 + rnd * 4.0) + rnd * 60.0);
    col += vec3(1.0, 0.95, 0.85) * step(0.9965, rnd) * smoothstep(0.32, 0.0, dist) * twinkle * 2.6 * smoothstep(0.03, 0.25, d.y);
    // moon with a soft halo
    float cm = dot(d, uMoonDir);
    float mare = 0.82 + 0.18 * vnoise(d.xy * 900.0);
    col += vec3(2.6, 2.5, 2.3) * mare * smoothstep(0.99955, 0.99972, cm);
    col += vec3(0.35, 0.42, 0.6) * pow(max(cm, 0.0), 500.0);
    col += vec3(0.06, 0.08, 0.13) * pow(max(cm, 0.0), 24.0);
    col = mix(col, vec3(0.005, 0.008, 0.012), smoothstep(0.0, -0.1, d.y));
    return col;
  }

  vec3 skyClouds(vec3 d, vec3 base) {
    if (d.y <= 0.0) return base;
    vec2 uv = d.xz / (d.y + 0.12) * 0.55 + vec2(uTime * 0.012, uTime * 0.004);
    float n = fbm(uv * 1.3);
    float n2 = fbm(uv * 3.1 + 4.0);
    float cover = mix(0.56, 0.5, uDusk);
    float dens = smoothstep(cover, cover + 0.28, n * 0.75 + n2 * 0.25) * smoothstep(0.0, 0.18, d.y);
    float toSun = pow(max(dot(normalize(d.xz + 1e-5), normalize(uSunDir.xz)), 0.0), 3.0);
    vec3 dayC = mix(vec3(1.05, 0.98, 0.92), vec3(0.72, 0.68, 0.66), smoothstep(0.5, 0.9, n2)) * uDayIntensity * 1.15;
    vec3 duskC = mix(vec3(0.16, 0.07, 0.1), vec3(1.3, 0.48, 0.18), toSun * (1.0 - smoothstep(0.0, 0.5, d.y)) + 0.2 * smoothstep(0.4, 0.8, n2));
    float moonLit = pow(max(dot(d, uMoonDir), 0.0), 6.0);
    vec3 nightC = vec3(0.03, 0.04, 0.06) + vec3(0.12, 0.14, 0.2) * moonLit;
    vec3 c = mix(mix(dayC, duskC, uDusk), nightC, uNight);
    return mix(base, c, dens * mix(0.85, 0.95, uNight));
  }

  vec3 skyColor(vec3 d) {
    d = normalize(d);
    vec3 c = mix(skyDay(d), skyDusk(d), uDusk);
    c = mix(c, skyNight(d), uNight);
    return skyClouds(d, c);
  }
`;

/** Huge inverted sphere that always surrounds the camera and paints the sky. */
export function SkyDome({ domeRef }: { domeRef: React.RefObject<THREE.Mesh | null> }) {
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: skyUniforms,
        vertexShader: /* glsl */ `
          varying vec3 vDir;
          void main() {
            vDir = (modelMatrix * vec4(position, 0.0)).xyz;
            vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            gl_Position = p.xyww; // pin to the far plane
          }
        `,
        fragmentShader: /* glsl */ `
          ${SKY_GLSL}
          varying vec3 vDir;
          void main() {
            gl_FragColor = vec4(skyColor(vDir), 1.0);
            #include <tonemapping_fragment>
            #include <colorspace_fragment>
          }
        `,
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
      }),
    [],
  );
  return (
    <mesh ref={domeRef} material={mat} renderOrder={-1000} frustumCulled={false}>
      <sphereGeometry args={[500, 64, 32]} />
    </mesh>
  );
}

// ---------------------------------------------------------------------------
/** A small flock of gulls wheeling over the harbour in daylight. */
export function Birds({ visibleRef }: { visibleRef: React.RefObject<number> }) {
  const group = useRef<THREE.Group>(null);
  const birds = useMemo(
    () =>
      Array.from({ length: 11 }, (_, i) => ({
        r: 9 + (i % 4) * 3.2,
        h: 7.5 + (i % 3) * 1.6,
        speed: 0.12 + (i % 5) * 0.025,
        phase: i * 0.57,
        flap: 6 + (i % 3) * 1.5,
        cx: -4 + (i % 2) * 6,
      })),
    [],
  );
  const wing = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute([0, 0, -0.04, 0, 0, 0.06, 0.34, 0.02, 0.0], 3));
    g.computeVertexNormals();
    return g;
  }, []);
  const mat = useMemo(() => new THREE.MeshStandardMaterial({ color: "#3a3936", side: THREE.DoubleSide, roughness: 0.9 }), []);

  useFrame(({ clock }) => {
    const g = group.current;
    if (!g) return;
    const v = visibleRef.current ?? 1;
    g.visible = v > 0.02;
    if (!g.visible) return;
    const t = clock.elapsedTime;
    g.children.forEach((bird, i) => {
      const b = birds[i];
      const a = t * b.speed + b.phase;
      bird.position.set(b.cx + Math.cos(a) * b.r, b.h + Math.sin(a * 1.7) * 0.6, -3 + Math.sin(a) * b.r * 0.6);
      bird.rotation.y = -a + Math.PI;
      const f = Math.sin(t * b.flap + b.phase) * 0.55;
      (bird.children[0] as THREE.Mesh).rotation.z = f;
      (bird.children[1] as THREE.Mesh).rotation.z = -f;
      bird.scale.setScalar(v);
    });
  });

  return (
    <group ref={group}>
      {birds.map((_, i) => (
        <group key={i}>
          <mesh geometry={wing} material={mat} />
          <mesh geometry={wing} material={mat} scale={[-1, 1, 1]} />
        </group>
      ))}
    </group>
  );
}
