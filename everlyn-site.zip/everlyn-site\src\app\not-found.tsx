import Link from "next/link";
import { Emblem } from "@/components/Logo";

export default function NotFound() {
  return (
    <section className="relative flex min-h-[90vh] items-center overflow-hidden">
      <Emblem className="pointer-events-none absolute -right-24 top-1/2 h-[36rem] w-[36rem] -translate-y-1/2 text-forest/[0.07]" strokeWidth={0.8} />
      <div className="container-lux relative">
        <p className="eyebrow mb-6">Error 404</p>
        <h1 className="display max-w-3xl text-5xl text-forest-deep sm:text-7xl">This shipment seems to have lost its way.</h1>
        <p className="mt-6 max-w-lg text-lg text-ink/70">The page you&rsquo;re looking for doesn&rsquo;t exist or has moved. Let&rsquo;s get you back on course.</p>
        <div className="mt-10 flex flex-wrap gap-6 text-sm uppercase tracking-[0.18em]">
          <Link href="/" className="link-underline text-forest-deep">Back to home</Link>
          <Link href="/products" className="link-underline text-forest-deep">Our products</Link>
          <Link href="/contact" className="link-underline text-forest-deep">Contact us</Link>
        </div>
      </div>
    </section>
  );
}
