import type { IconName } from "@/content/site";

const paths: Record<IconName, React.ReactNode> = {
  spice: (
    <>
      <path d="M12 3c3 2.5 4.5 5.5 4.5 9a4.5 4.5 0 0 1-9 0C7.5 8.5 9 5.5 12 3Z" />
      <path d="M12 7v12M9.5 12.5 12 15l2.5-2.5" />
    </>
  ),
  grain: (
    <>
      <path d="M12 21V8" />
      <path d="M12 8c0-2.5 1.5-4.5 3-5 .5 2-.5 4.5-3 5ZM12 8c0-2.5-1.5-4.5-3-5-.5 2 .5 4.5 3 5Z" />
      <path d="M12 13c1.5-2 3.5-2.8 5-2.5-.3 2-2.5 3.5-5 2.5ZM12 13c-1.5-2-3.5-2.8-5-2.5.3 2 2.5 3.5 5 2.5ZM12 18c1.5-2 3.5-2.8 5-2.5-.3 2-2.5 3.5-5 2.5ZM12 18c-1.5-2-3.5-2.8-5-2.5.3 2 2.5 3.5 5 2.5Z" />
    </>
  ),
  fruit: (
    <>
      <path d="M12 7c-4-2-8 .5-8 5.5S7.5 21 10 21c1 0 1.4-.5 2-.5s1 .5 2 .5c2.5 0 6-3.5 6-8.5S16 5 12 7Z" />
      <path d="M12 7c0-2 1-3.5 3-4" />
    </>
  ),
  textile: (
    <>
      <path d="M6 4h12v4H6zM6 16h12v4H6z" />
      <path d="M8 8v8M12 8v8M16 8v8" />
    </>
  ),
  craft: (
    <>
      <path d="M9 3h6M10 3v3c-3 1.5-5 4-5 7.5C5 18 8 21 12 21s7-3 7-7.5C19 10 17 7.5 14 6V3" />
      <path d="M6 12h12" />
    </>
  ),
  gear: (
    <>
      <circle cx="12" cy="12" r="3.2" />
      <path d="M12 2.5v3M12 18.5v3M21.5 12h-3M5.5 12h-3M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1M18.7 18.7l-2.1-2.1M7.4 7.4 5.3 5.3" />
      <circle cx="12" cy="12" r="6.5" />
    </>
  ),
  ship: (
    <>
      <path d="M3 15h18l-2.5 5h-13z" />
      <path d="M6 15v-4h12v4M9 11V8h6v3M12 8V4" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c2.5 2.5 3.8 5.5 3.8 9S14.5 18.5 12 21M12 3C9.5 5.5 8.2 8.5 8.2 12s1.3 6.5 3.8 9" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3 4.5 6v5.5c0 4.5 3.2 8.3 7.5 9.5 4.3-1.2 7.5-5 7.5-9.5V6z" />
      <path d="m8.8 12 2.2 2.2 4.2-4.4" />
    </>
  ),
  doc: (
    <>
      <path d="M6 3h8l4 4v14H6z" />
      <path d="M14 3v4h4M9 12h6M9 15.5h6M9 9h2.5" />
    </>
  ),
  box: (
    <>
      <path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z" />
      <path d="m4 7.5 8 4.5 8-4.5M12 12v9" />
    </>
  ),
  truck: (
    <>
      <path d="M2.5 6h11v10h-11zM13.5 9.5h4l3 3.5v3h-7" />
      <circle cx="7" cy="17.5" r="1.8" />
      <circle cx="17" cy="17.5" r="1.8" />
    </>
  ),
  search: (
    <>
      <circle cx="10.5" cy="10.5" r="6.5" />
      <path d="m15.5 15.5 5 5" />
    </>
  ),
  handshake: (
    <>
      <path d="m3 11 4-4 3 1 2-1.5 3 .5 4 4" />
      <path d="m3 11 6 6c.8.8 2 .8 2.8 0l5.7-5.7M9.5 13.5 12 16M12 11l2.5 2.5" />
    </>
  ),
  leaf: (
    <>
      <path d="M5 19c0-9 5-14 15-14 0 10-5 15-14 15" />
      <path d="M5 19 13 11" />
    </>
  ),
  chart: (
    <>
      <path d="M4 20V4M4 20h16" />
      <path d="m7 15 4-4 3 3 5-6" />
    </>
  ),
  store: (
    <>
      <path d="M4 9.5 5.5 4h13L20 9.5M4 9.5V20h16V9.5M4 9.5c0 1.5 1.3 2.5 2.7 2.5S9.3 11 9.3 9.5c0 1.5 1.2 2.5 2.7 2.5s2.7-1 2.7-2.5c0 1.5 1.2 2.5 2.6 2.5S20 11 20 9.5" />
      <path d="M10 20v-4.5h4V20" />
    </>
  ),
  factory: (
    <>
      <path d="M3 20V10l5 3V10l5 3V6h3l1 14z" />
      <path d="M3 20h18M17 20V6" />
    </>
  ),
  hotel: (
    <>
      <path d="M5 21V4h14v17M3 21h18" />
      <path d="M9 8h1.5M13.5 8H15M9 12h1.5M13.5 12H15M10.5 21v-4h3v4" />
    </>
  ),
  cart: (
    <>
      <path d="M3 4h2.5l2 11h11l2-8H6.5" />
      <circle cx="9" cy="19" r="1.4" />
      <circle cx="17" cy="19" r="1.4" />
    </>
  ),
  anchor: (
    <>
      <circle cx="12" cy="5" r="2" />
      <path d="M12 7v14M8 10h8M4.5 13.5c0 4 3.4 7.5 7.5 7.5s7.5-3.5 7.5-7.5" />
    </>
  ),
  compass: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="m15.5 8.5-2 5-5 2 2-5z" />
    </>
  ),
};

export function Icon({ name, className }: { name: IconName; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={className ?? "h-6 w-6"}
      fill="none"
      stroke="currentColor"
      strokeWidth={1.25}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  );
}
