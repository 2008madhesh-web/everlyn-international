import { PageHero } from "./PageHero";

export function LegalPage({ title, updated, sections }: { title: string; updated: string; sections: { h: string; p: string[] }[] }) {
  return (
    <>
      <PageHero eyebrow={`Last updated ${updated}`} title={title} crumbs={[{ label: title }]} />
      <article className="container-lux pb-32">
        <div className="mx-auto max-w-3xl space-y-12">
          {sections.map((s, i) => (
            <section key={s.h}>
              <h2 className="display text-3xl text-forest-deep">
                <span className="mr-3 text-brass">{String(i + 1).padStart(2, "0")}</span>
                {s.h}
              </h2>
              {s.p.map((t, j) => (
                <p key={j} className="mt-4 leading-relaxed text-ink/75">{t}</p>
              ))}
            </section>
          ))}
        </div>
      </article>
    </>
  );
}
