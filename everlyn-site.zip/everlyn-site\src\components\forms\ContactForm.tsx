"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AnimatePresence, motion } from "framer-motion";
import { contactSchema, type ContactInput } from "@/lib/enquiry";
import { Field, SuccessMark } from "./Field";
import { Button } from "../ui/Button";

const subjects = contactSchema.shape.subject.options;

export function ContactForm() {
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [ref, setRef] = useState("");
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ContactInput>({
    resolver: zodResolver(contactSchema),
    defaultValues: { kind: "contact", subject: "Export enquiry" },
  });

  const onSubmit = async (data: ContactInput) => {
    setState("sending");
    try {
      const res = await fetch("/api/enquiry", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      const json = await res.json();
      if (!res.ok || !json.ok) throw new Error();
      setRef(json.ref ?? "");
      setState("done");
      reset();
    } catch {
      setState("error");
    }
  };

  const aria = (k: keyof ContactInput) => ({ "aria-invalid": !!errors[k], "aria-describedby": errors[k] ? `c-${k}-error` : undefined });

  return (
    <AnimatePresence mode="wait">
      {state === "done" ? (
        <motion.div key="done" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="py-10" role="status">
          <SuccessMark />
          <h3 className="display mt-6 text-4xl text-forest-deep">Thank you. Your message is on its way.</h3>
          <p className="mt-3 text-ink/70">We&rsquo;ll reply within one business day.{ref && ` Your reference: ${ref}.`}</p>
          <button type="button" onClick={() => setState("idle")} className="link-underline mt-8 text-sm uppercase tracking-[0.18em] text-forest-deep">Send another message</button>
        </motion.div>
      ) : (
        <motion.form key="form" onSubmit={handleSubmit(onSubmit)} noValidate initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="grid gap-8 sm:grid-cols-2">
          <input type="hidden" {...register("kind")} />
          <input type="text" tabIndex={-1} autoComplete="off" aria-hidden className="hidden" {...register("website")} />
          <Field label="Full name" htmlFor="c-name" error={errors.name?.message}>
            <input id="c-name" className="field" autoComplete="name" {...register("name")} {...aria("name")} />
          </Field>
          <Field label="Email" htmlFor="c-email" error={errors.email?.message}>
            <input id="c-email" type="email" className="field" autoComplete="email" {...register("email")} {...aria("email")} />
          </Field>
          <Field label="Company" htmlFor="c-company" optional>
            <input id="c-company" className="field" autoComplete="organization" {...register("company")} />
          </Field>
          <Field label="Phone / WhatsApp" htmlFor="c-phone" optional>
            <input id="c-phone" type="tel" className="field" autoComplete="tel" {...register("phone")} />
          </Field>
          <Field label="Country" htmlFor="c-country" optional>
            <input id="c-country" className="field" autoComplete="country-name" {...register("country")} />
          </Field>
          <Field label="Subject" htmlFor="c-subject">
            <select id="c-subject" className="field" {...register("subject")}>
              {subjects.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </Field>
          <Field label="Message" htmlFor="c-message" error={errors.message?.message} className="sm:col-span-2">
            <textarea id="c-message" rows={5} className="field resize-none" placeholder="Products, quantities, destination or any questions…" {...register("message")} {...aria("message")} />
          </Field>
          <div className="flex flex-wrap items-center gap-6 sm:col-span-2">
            <Button type="submit" arrow disabled={state === "sending"}>{state === "sending" ? "Sending…" : "Send message"}</Button>
            {state === "error" && <p role="alert" className="text-sm text-[#9b3b2a]">Something went wrong. Please try again or email us directly.</p>}
          </div>
        </motion.form>
      )}
    </AnimatePresence>
  );
}
