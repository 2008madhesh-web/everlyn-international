"use client";

import { useMemo } from "react";
import { useTexture } from "@react-three/drei";
import * as THREE from "three";

const T = "/textures/";

function prep(tex: THREE.Texture, repeat: number, srgb = false, aniso = 8) {
  const t = tex.clone();
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.anisotropy = aniso;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.needsUpdate = true;
  return t;
}

/** Photo-scanned PBR materials (Poly Haven, CC0) shared by every model in the story. */
export function usePBR() {
  const [cDiff, cNor, cArm, mDiff, mNor, mArm, kDiff, kNor, kArm] = useTexture([
    `${T}container_side_diff_2k.jpg`,
    `${T}container_side_nor_gl_2k.jpg`,
    `${T}container_side_arm_2k.jpg`,
    `${T}metal_plate_02_diff_1k.jpg`,
    `${T}metal_plate_02_nor_gl_1k.jpg`,
    `${T}metal_plate_02_arm_1k.jpg`,
    `${T}concrete_floor_02_diff_1k.jpg`,
    `${T}concrete_floor_02_nor_gl_1k.jpg`,
    `${T}concrete_floor_02_arm_1k.jpg`,
  ]);

  return useMemo(() => {
    // Hero container: the scan is green, tinted here to the exact Everlyn emerald
    // while keeping every scratch and streak of the real surface.
    const containerPaint = new THREE.MeshStandardMaterial({
      color: "#62a2d2",
      map: prep(cDiff, 1.9, true),
      normalMap: prep(cNor, 1.9),
      normalScale: new THREE.Vector2(0.9, 0.9),
      roughnessMap: prep(cArm, 1.9),
      metalnessMap: prep(cArm, 1.9),
      aoMap: prep(cArm, 1.9),
      roughness: 1,
      metalness: 0.55,
      envMapIntensity: 1.1,
    });

    // Instanced boxes in the yard/on deck: real surface detail, colour from each instance
    const containerYard = new THREE.MeshStandardMaterial({
      color: "#ffffff",
      normalMap: prep(cNor, 1.9),
      roughnessMap: prep(cArm, 1.9),
      metalnessMap: prep(cArm, 1.9),
      roughness: 1,
      metalness: 0.45,
    });

    const frameSteel = new THREE.MeshStandardMaterial({
      color: "#163f33",
      normalMap: prep(mNor, 2),
      roughnessMap: prep(mArm, 2),
      roughness: 0.9,
      metalness: 0.5,
    });

    const rawSteel = new THREE.MeshStandardMaterial({
      map: prep(mDiff, 1.5, true),
      normalMap: prep(mNor, 1.5),
      roughnessMap: prep(mArm, 1.5),
      metalnessMap: prep(mArm, 1.5),
      metalness: 1,
      roughness: 1,
    });

    // Hull: painted plating, colour from vertex colours (topsides / boot top / antifouling)
    const hull = new THREE.MeshStandardMaterial({
      vertexColors: true,
      normalMap: prep(mNor, 1),
      normalScale: new THREE.Vector2(0.6, 0.6),
      roughnessMap: prep(mArm, 1),
      roughness: 0.85,
      metalness: 0.25,
      side: THREE.DoubleSide,
    });

    const deck = new THREE.MeshStandardMaterial({
      color: "#8a8f86",
      map: prep(mDiff, 1, true),
      normalMap: prep(mNor, 1),
      roughness: 0.85,
      metalness: 0.3,
    });

    const concrete = new THREE.MeshStandardMaterial({
      color: "#e6dccb",
      map: prep(kDiff, 0.35, true),
      normalMap: prep(kNor, 0.35),
      roughnessMap: prep(kArm, 0.35),
      aoMap: prep(kArm, 0.35),
      roughness: 1,
      metalness: 0,
    });

    return { containerPaint, containerYard, frameSteel, rawSteel, hull, deck, concrete };
  }, [cDiff, cNor, cArm, mDiff, mNor, mArm, kDiff, kNor, kArm]);
}

// ---------------------------------------------------------------------------
let _water: THREE.CanvasTexture | null = null;
/** Tileable ripple normal map for the sea, generated once. */
export function waterNormalTexture() {
  if (_water) return _water;
  const S = 256;
  const h = new Float32Array(S * S);
  const waves: [number, number, number, number][] = [];
  let seed = 11;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
  for (let k = 0; k < 22; k++) {
    const fx = Math.round((rnd() * 2 - 1) * 9);
    const fy = Math.round((rnd() * 2 - 1) * 9) || 1;
    waves.push([fx, fy, rnd() * Math.PI * 2, 1 / Math.hypot(fx, fy)]);
  }
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      let v = 0;
      for (const [fx, fy, ph, a] of waves) v += Math.sin(((fx * x + fy * y) / S) * Math.PI * 2 + ph) * a;
      h[y * S + x] = v;
    }
  const c = document.createElement("canvas");
  c.width = c.height = S;
  const g = c.getContext("2d")!;
  const img = g.createImageData(S, S);
  const k = 1.6;
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      const l = h[y * S + ((x - 1 + S) % S)];
      const r = h[y * S + ((x + 1) % S)];
      const u = h[((y - 1 + S) % S) * S + x];
      const d = h[((y + 1) % S) * S + x];
      const n = new THREE.Vector3((l - r) * k, (u - d) * k, 1).normalize();
      const i = (y * S + x) * 4;
      img.data[i] = (n.x * 0.5 + 0.5) * 255;
      img.data[i + 1] = (n.y * 0.5 + 0.5) * 255;
      img.data[i + 2] = (n.z * 0.5 + 0.5) * 255;
      img.data[i + 3] = 255;
    }
  g.putImageData(img, 0, 0);
  _water = new THREE.CanvasTexture(c);
  _water.wrapS = _water.wrapT = THREE.RepeatWrapping;
  return _water;
}

function canvasTex(w: number, h: number, draw: (g: CanvasRenderingContext2D) => void, srgb = true) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  draw(c.getContext("2d")!);
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

/** Yellow/black hazard stripes for crane legs and quay edges. */
export const hazardTexture = () =>
  canvasTex(128, 128, (g) => {
    g.fillStyle = "#d9a91a";
    g.fillRect(0, 0, 128, 128);
    g.fillStyle = "#1b1b18";
    for (let i = -128; i < 256; i += 64) {
      g.beginPath();
      g.moveTo(i, 0);
      g.lineTo(i + 32, 0);
      g.lineTo(i + 160, 128);
      g.lineTo(i + 128, 128);
      g.fill();
    }
  });

/** White accommodation-block facade with rows of tinted windows. */
export const windowsTexture = () =>
  canvasTex(512, 512, (g) => {
    g.fillStyle = "#f1ede4";
    g.fillRect(0, 0, 512, 512);
    for (let r = 0; r < 4; r++)
      for (let c = 0; c < 8; c++) {
        const x = 18 + c * 62;
        const y = 40 + r * 124;
        const grd = g.createLinearGradient(x, y, x, y + 44);
        grd.addColorStop(0, "#2c3a3a");
        grd.addColorStop(1, "#4d5f5c");
        g.fillStyle = grd;
        g.fillRect(x, y, 42, 44);
      }
    g.fillStyle = "rgba(0,0,0,0.06)";
    for (let r = 0; r < 4; r++) g.fillRect(0, 118 + r * 124, 512, 4);
  });

/** Matching glow mask: only the window panes, used as an emissive map at night. */
export const windowsGlowTexture = () =>
  canvasTex(512, 512, (g) => {
    g.fillStyle = "#000";
    g.fillRect(0, 0, 512, 512);
    let seed = 5;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
    for (let r = 0; r < 4; r++)
      for (let c = 0; c < 8; c++) {
        if (rnd() < 0.25) continue; // a few cabins dark
        g.fillStyle = rnd() > 0.5 ? "#ffd9a0" : "#ffe9c4";
        g.fillRect(18 + c * 62, 40 + r * 124, 42, 44);
      }
  });

/** Container identification markings (owner code, size/type) like a real box. */
export const markingsTexture = (code: string, type: string) =>
  canvasTex(512, 256, (g) => {
    g.fillStyle = "#f2ead8";
    g.font = "700 64px Arial, Helvetica, sans-serif";
    g.textBaseline = "top";
    g.fillText(code, 8, 8);
    g.font = "700 46px Arial, Helvetica, sans-serif";
    g.fillText(type, 8, 92);
    g.font = "500 22px Arial, Helvetica, sans-serif";
    g.fillText("MAX. GROSS  30,480 KG", 8, 160);
    g.fillText("TARE         2,200 KG", 8, 190);
  });

/** Large hull lettering, e.g. EVERLYN along the ship's side. */
export const hullLetteringTexture = (text: string, color = "#efe6d2", tracking = 40) =>
  canvasTex(2048, 256, (g) => {
    const font = getComputedStyle(document.documentElement).getPropertyValue("--font-cormorant").trim() || "Georgia";
    g.fillStyle = color;
    g.font = `500 200px ${font}, Georgia, serif`;
    g.textBaseline = "middle";
    const chars = [...text];
    const widths = chars.map((ch) => g.measureText(ch).width);
    const total = widths.reduce((a, b) => a + b, 0) + tracking * (chars.length - 1);
    let x = 1024 - total / 2;
    chars.forEach((ch, i) => {
      g.fillText(ch, x, 136);
      x += widths[i] + tracking;
    });
  });
