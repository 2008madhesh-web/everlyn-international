import type { Metadata } from "next";
import Link from "next/link";
import { PageHero, SectionHeading } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { Icon } from "@/components/ui/Icon";
import { CtaBand } from "@/components/ui/CtaBand";
import { products } from "@/content/site";

export const metadata: Metadata = {
  title: "Products",
  description: "Spices, rice and grains, fresh produce, textiles, handicrafts and engineering goods exported from India to export grade.",
};

const imports = ["Industrial machinery & spares", "Electronic components", "Raw materials & polymers", "Dry fruits & nuts", "Food ingredients", "Consumer goods for distribution"];

export default function ProductsPage() {
  return (
    <>
      <PageHero
        eyebrow="Our products"
        title="India's finest, graded and packed for the world."
        intro="Six categories, hundreds of products, one standard. Every lot is sampled, inspected and documented before it leaves India."
        crumbs={[{ label: "Products" }]}
      />

      <section className="container-lux pb-24">
        <ul className="border-t border-forest-deep/15">
          {products.map((p, i) => (
            <Reveal as="li" key={p.slug} delay={0.05} className="border-b border-forest-deep/15">
              <Link href={`/products/${p.slug}`} className="group relative grid items-center gap-6 py-10 md:grid-cols-12 md:py-14">
                <span aria-hidden className="absolute inset-0 origin-bottom scale-y-0 rounded-3xl bg-forest-deep transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-y-100" />
                <span className="display relative text-2xl italic text-brass md:col-span-1 md:pl-6">{String(i + 1).padStart(2, "0")}</span>
                <span className="relative flex items-center gap-5 md:col-span-5">
                  <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full border border-forest-deep/15 text-forest transition-colors duration-500 group-hover:border-ivory/20 group-hover:text-brass-light">
                    <Icon name={p.icon} className="h-7 w-7" />
                  </span>
                  <span className="display text-3xl text-forest-deep transition-colors duration-500 group-hover:text-ivory md:text-[2.6rem]">{p.name}</span>
                </span>
                <span className="relative text-sm leading-relaxed text-ink/65 transition-colors duration-500 group-hover:text-ivory/70 md:col-span-5">
                  {p.short}
                  <span className="mt-3 block text-xs uppercase tracking-[0.16em] text-forest/80 transition-colors duration-500 group-hover:text-brass-light">
                    {p.items.slice(0, 3).map((x) => x.name).join(" · ")}
                  </span>
                </span>
                <span className="relative hidden justify-end pr-6 md:col-span-1 md:flex">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full border border-forest-deep/20 text-forest-deep transition-all duration-500 group-hover:rotate-[-45deg] group-hover:border-ivory/30 group-hover:text-ivory">
                    <svg width="16" height="10" viewBox="0 0 16 10" fill="none" stroke="currentColor" strokeWidth="1.4"><path d="M0 5h14M10 1l4 4-4 4" /></svg>
                  </span>
                </span>
              </Link>
            </Reveal>
          ))}
        </ul>
      </section>

      <section className="bg-parchment/60 py-24 md:py-32">
        <div className="container-lux grid gap-14 md:grid-cols-2">
          <SectionHeading eyebrow="Import desk" title="Bringing the world to India, too." intro="Our import team sources goods for Indian manufacturers, distributors and retailers, and handles customs clearance and delivery to your door." />
          <ul className="grid content-start gap-3 sm:grid-cols-2">
            {imports.map((x, i) => (
              <Reveal as="li" key={x} delay={i * 0.05} className="flex items-center gap-3 rounded-2xl border border-forest-deep/10 bg-ivory px-5 py-4 text-sm text-forest-deep">
                <span className="h-1.5 w-1.5 rounded-full bg-brass" />
                {x}
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <CtaBand title="Can't see what you're looking for?" body="Our sourcing team works across hundreds of Indian product lines. Tell us the specification and we'll find a qualified supplier." />
    </>
  );
}
