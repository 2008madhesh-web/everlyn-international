"use client";

import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import * as THREE from "three";
import { Bloom, EffectComposer, N8AO, Noise, SMAA, ToneMapping, Vignette } from "@react-three/postprocessing";
import { BlendFunction, ToneMappingMode } from "postprocessing";
import { StoryScene } from "./StoryScene";

/** Renders after the sky and textures have loaded (i.e. once Suspense resolves). */
function Ready({ onReady }: { onReady?: () => void }) {
  useEffect(() => {
    const id = requestAnimationFrame(() => onReady?.());
    return () => cancelAnimationFrame(id);
  }, [onReady]);
  return null;
}

/** Fixed full-screen WebGL layer behind the home page. */
export default function StoryCanvas({ onReady }: { onReady?: () => void }) {
  // client-only component (loaded with ssr:false), so window is available here
  const [lite] = useState(
    () => window.matchMedia("(max-width: 767px)").matches || (navigator.hardwareConcurrency ?? 8) <= 4 || (process.env.NODE_ENV !== "production" && location.search.includes("lite")),
  );

  return (
    <Canvas
      className="!fixed inset-0 !h-[100lvh] !w-full"
      style={{ pointerEvents: "none" }}
      dpr={lite ? [1, 1.25] : [1, 1.5]}
      shadows={!lite ? { type: THREE.PCFShadowMap } : false}
      camera={{ fov: 35, near: 0.1, far: 700, position: [0, 1, 6] }}
      gl={{ antialias: false, powerPreference: "high-performance", alpha: false, stencil: false }}
      aria-hidden
    >
      <Suspense fallback={null}>
        <StoryScene lite={lite} />
        {lite ? (
          <EffectComposer multisampling={0} enableNormalPass={false}>
            <Bloom mipmapBlur luminanceThreshold={1} luminanceSmoothing={0.2} intensity={0.5} />
            <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
            <Vignette offset={0.28} darkness={0.4} />
            <SMAA />
          </EffectComposer>
        ) : (
          <EffectComposer multisampling={0} enableNormalPass={false}>
            <N8AO aoRadius={0.7} distanceFalloff={0.6} intensity={2.2} quality="medium" halfRes />
            <Bloom mipmapBlur luminanceThreshold={1} luminanceSmoothing={0.2} intensity={0.55} />
            <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
            <Vignette offset={0.28} darkness={0.42} />
            <Noise premultiply blendFunction={BlendFunction.SOFT_LIGHT} opacity={0.1} />
            <SMAA />
          </EffectComposer>
        )}
        <Ready onReady={onReady} />
      </Suspense>
    </Canvas>
  );
}
