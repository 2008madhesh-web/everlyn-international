/**
 * The scroll story timeline. `p` runs 0 to 1 across the home page.
 * Everything the 3D scene does is a pure function of `p`, so scrubbing
 * backwards and forwards always looks right.
 *
 *   0.00  golden-hour afternoon at the quay, the container is the hero
 *   0.12  the crane rolls in and loads the container onto the ship
 *   0.31  the ship departs into the setting sun (silhouette), day turns to night
 *   0.47  the voyage, shown on a night globe
 *   0.69  the ship arrives at a floodlit port at night
 *   0.78  the crane unloads the container onto the waiting lorry (the end)
 */
import * as THREE from "three";

/** Mutable, render-free shared state between the DOM and the WebGL scene. */
export const story = {
  target: 0, // scroll progress from ScrollTrigger
  current: 0, // smoothed progress used for rendering
  intro: 0, // 0 to 1 camera pull-back after the loader
  pointerX: 0,
  pointerY: 0,
};

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const seg = (p: number, a: number, b: number) => clamp((p - a) / (b - a));
export const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
/** Gentle start, then a steady cruising speed (no sudden lurch away from the berth). */
const easeInSlow = (t: number) => (t < 0.2 ? (t * t) / 0.4 : t - 0.1) / 0.9;

// ---- World constants -------------------------------------------------------
export const WATER_Y = -0.9;
export const DECK_Y = -0.2;
export const SHIP_DOCK = new THREE.Vector3(0, 0, -5.6);
/** Departure course: out to sea, moving left to right across the view toward the sun. */
export const DEPART_DIR = new THREE.Vector3(1, 0, -0.55).normalize();
export const DEPART_LEN = 82;
export const SHIP_FAR_OUT = SHIP_DOCK.clone().addScaledVector(DEPART_DIR, DEPART_LEN);
/** The ship returns at night from the left, bow first. */
export const SHIP_FAR_IN = new THREE.Vector3(-80, 0, -26);
// second tier above the hatch covers (hatch top = deck + 0.1)
export const SLOT_ON_SHIP = new THREE.Vector3(0, DECK_Y + 1.6, 0);
export const GROUND_C = 0.5; // container centre y when on the quay
export const TRUCK_C = 1.28; // container centre y when on the lorry
export const CARRY_C = 4.3; // container centre y while hanging from the crane
export const SPREADER_REST = 5.9;
export const GLOBE_POS = new THREE.Vector3(0, 300, 0);

/**
 * Compass direction of the sun: straight ahead of the camera in the opening shot.
 * The afternoon sun sits here from the first frame and sets here at the end of the departure.
 */
export const SUN_AZIMUTH = new THREE.Vector3(0.22, 0, -0.976).normalize();
export const SUNSET_ELEVATION = 0.012; // the disc slips halfway below the horizon
export const MOON_DIR = new THREE.Vector3(-0.45, 0.42, -0.79).normalize();

/** Ship heading as a y-rotation for a model whose bow points to -x. */
function headingOf(dir: THREE.Vector3) {
  let a = Math.atan2(dir.z, -dir.x);
  if (a < 0) a += Math.PI * 2;
  return a;
}
const HEAD_DOCK = Math.PI; // bow toward +x, alongside the quay
const HEAD_OUT = headingOf(DEPART_DIR);
const HEAD_IN = headingOf(SHIP_DOCK.clone().sub(SHIP_FAR_IN).setY(0).normalize());

/** Ship y-rotation: eases from alongside the quay onto its course, and back on arrival. */
export function shipHeading(p: number) {
  if (p < 0.56) return lerp(HEAD_DOCK, HEAD_OUT, ease(seg(p, 0.31, 0.37)));
  return lerp(HEAD_IN, HEAD_DOCK, ease(seg(p, 0.73, 0.78)));
}

// The sunset viewpoint: standing on the quay, looking along the sun's azimuth, with the
// ship crossing that line (and the sun) partway through its departure.
const CROSS = SHIP_DOCK.clone().addScaledVector(DEPART_DIR, DEPART_LEN * 0.6);
const SUNSET_CAM = CROSS.clone().addScaledVector(SUN_AZIMUTH, -45);
const SUNSET_LOOK = SUNSET_CAM.clone().addScaledVector(SUN_AZIMUTH, 60);

// ---- Day / night -----------------------------------------------------------
/** How far the sky has moved from afternoon toward sunset (0..1). */
export function duskAmount(p: number) {
  return p < 0.6 ? ease(seg(p, 0.29, 0.415)) : 0;
}
/** How dark it is (0 = day/sunset, 1 = night). Night holds through the arrival. */
export function nightAmount(p: number) {
  return p < 0.6 ? ease(seg(p, 0.43, 0.468)) : 1;
}

/** Where the ship is. It waits at the berth, sails into the sunset, and returns at night. */
export function shipPosition(p: number, out: THREE.Vector3) {
  if (p < 0.31) return out.copy(SHIP_DOCK);
  if (p < 0.56) return out.lerpVectors(SHIP_DOCK, SHIP_FAR_OUT, easeInSlow(seg(p, 0.31, 0.47)));
  return out.lerpVectors(SHIP_FAR_IN, SHIP_DOCK, easeOut(seg(p, 0.69, 0.78)));
}

/** The gantry crane travels along its rails into position before the pick-up. */
export function craneX(p: number) {
  return p < 0.5 ? lerp(-17, 0, ease(seg(p, 0.05, 0.125))) : 0;
}

/** The lorry waits under the crane; the story ends once the container is on it. */
export function truckX() {
  return 0;
}

export type RigState = {
  container: THREE.Vector3;
  spreaderY: number;
  trolleyZ: number;
  onShip: boolean;
  doors: number;
};

/** Container, crane trolley and spreader for a given progress. */
export function rig(p: number, ship: THREE.Vector3, out: RigState): RigState {
  const c = out.container;
  out.doors = 0;
  out.onShip = false;
  // Departure: quay to crane to ship
  if (p < 0.31) {
    out.trolleyZ = lerp(0, SHIP_DOCK.z, ease(seg(p, 0.2, 0.25)));
    if (p < 0.16) {
      c.set(0, GROUND_C, 0);
      out.spreaderY = lerp(SPREADER_REST, GROUND_C + 0.56, ease(seg(p, 0.12, 0.16)));
    } else if (p < 0.29) {
      const lift = ease(seg(p, 0.16, 0.2));
      const lower = ease(seg(p, 0.25, 0.29));
      const y = lower > 0 ? lerp(CARRY_C, SHIP_DOCK.y + SLOT_ON_SHIP.y, lower) : lerp(GROUND_C, CARRY_C, lift);
      c.set(0, y, out.trolleyZ);
      out.spreaderY = y + 0.56;
    } else {
      c.copy(ship).add(SLOT_ON_SHIP);
      out.spreaderY = lerp(SLOT_ON_SHIP.y + 0.56, SPREADER_REST, ease(seg(p, 0.29, 0.31)));
      out.onShip = true;
    }
    return out;
  }
  // At sea
  if (p < 0.78) {
    c.copy(ship).add(SLOT_ON_SHIP);
    out.spreaderY = SPREADER_REST;
    out.trolleyZ = SHIP_DOCK.z;
    out.onShip = true;
    return out;
  }
  // Arrival at night: ship to crane to lorry
  out.trolleyZ = lerp(SHIP_DOCK.z, 0, ease(seg(p, 0.84, 0.89)));
  if (p < 0.8) {
    c.copy(ship).add(SLOT_ON_SHIP);
    out.onShip = true;
    out.spreaderY = lerp(SPREADER_REST, c.y + 0.56, ease(seg(p, 0.78, 0.8)));
  } else if (p < 0.95) {
    const lift = ease(seg(p, 0.8, 0.84));
    const lower = ease(seg(p, 0.89, 0.95));
    const y = lower > 0 ? lerp(CARRY_C, TRUCK_C, lower) : lerp(SLOT_ON_SHIP.y, CARRY_C, lift);
    c.set(0, y, out.trolleyZ);
    out.spreaderY = y + 0.56;
  } else {
    c.set(0, TRUCK_C, 0);
    out.spreaderY = lerp(TRUCK_C + 0.56, SPREADER_REST, ease(seg(p, 0.95, 0.985)));
  }
  return out;
}

/** 0 = clear, 1 = fully veiled (used to hand over between the port and the globe). */
export function whiteout(p: number) {
  return p < 0.57 ? seg(p, 0.452, 0.47) : 1 - seg(p, 0.69, 0.715);
}

/** Globe visibility. */
export function globeAmount(p: number) {
  return p < 0.57 ? seg(p, 0.462, 0.49) : 1 - seg(p, 0.675, 0.695);
}

/** Progress of the hero route India to Europe on the globe. */
export function routeProgress(p: number) {
  return ease(seg(p, 0.5, 0.645));
}

// ---- Camera ---------------------------------------------------------------
type Follow = "none" | "ship" | "truck" | "globe";
type Key = { p: number; pos: [number, number, number]; look: [number, number, number]; f: Follow };

const v3 = (v: THREE.Vector3, y: number): [number, number, number] => [v.x, y, v.z];

const KEYS: Key[] = [
  // opening shot: the container on the quay, the ship behind it, the afternoon sun straight ahead
  // (eye level above the ship's deck cargo, so the low sun on the horizon is in view)
  { p: 0.0, pos: [-4.5, 3.2, 8.5], look: [-1.86, 1.1, -3.2], f: "none" },
  { p: 0.1, pos: [-2.2, 3.6, 11], look: [-0.8, 2.0, -1.5], f: "none" },
  { p: 0.15, pos: [6, 5.5, 15.5], look: [-1.2, 3.0, -3], f: "none" },
  { p: 0.22, pos: [6, 7.2, 13.5], look: [-1, 3.3, -3.4], f: "none" },
  { p: 0.29, pos: [9, 6.2, 11], look: [-1.5, 1, -5.6], f: "none" },
  // a slow glide along the quay to the sunset viewpoint
  { p: 0.345, pos: [21, 6, 17], look: [31, 2.4, -22], f: "none" },
  { p: 0.39, pos: v3(SUNSET_CAM, 4.4), look: v3(SUNSET_LOOK, 2.2), f: "none" },
  { p: 0.455, pos: [SUNSET_CAM.x + 1.4, 4.1, SUNSET_CAM.z - 0.6], look: [SUNSET_LOOK.x + 1.4, 2.1, SUNSET_LOOK.z - 0.6], f: "none" },
  // the voyage on the night globe
  { p: 0.47, pos: [-0.8, 0, 4.4], look: [-0.8, 0, 0], f: "globe" },
  { p: 0.53, pos: [-2.7, 0.2, 11.2], look: [-2.7, 0.2, 0], f: "globe" },
  { p: 0.655, pos: [-2.7, 0.2, 11.2], look: [-2.7, 0.2, 0], f: "globe" },
  { p: 0.69, pos: [-0.4, 0, 3.6], look: [-0.4, 0, 0], f: "globe" },
  // night arrival from the left, then the unload onto the lorry
  { p: 0.7, pos: [-26, 30, 48], look: [0, 0, 0], f: "ship" },
  { p: 0.78, pos: [11, 7, 18], look: [-1, 1, 0], f: "ship" },
  { p: 0.84, pos: [7, 6.4, 14.5], look: [-1.2, 3.4, -3], f: "none" },
  { p: 0.9, pos: [6.5, 5.2, 13], look: [-0.6, 2.6, -1.6], f: "none" },
  { p: 0.97, pos: [5.6, 2.8, 9.2], look: [-0.4, 1.3, 0], f: "none" },
  { p: 1.0, pos: [5.2, 2.5, 8.4], look: [-0.4, 1.25, 0], f: "none" },
];

const P = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];
const L = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];

function anchor(f: Follow, ship: THREE.Vector3, tx: number, out: THREE.Vector3) {
  if (f === "ship") return out.copy(ship);
  if (f === "truck") return out.set(tx, 0, 0);
  if (f === "globe") return out.copy(GLOBE_POS);
  return out.set(0, 0, 0);
}

const anc = new THREE.Vector3();
/** Keys are authored for a ~16:9 desktop. Narrower screens pull back and re-centre smoothly. */
const DESIGN_ASPECT = 1.65;

function resolve(k: Key, ship: THREE.Vector3, tx: number, aspect: number, pos: THREE.Vector3, look: THREE.Vector3) {
  anchor(k.f, ship, tx, anc);
  look.set(...k.look).add(anc);
  pos.set(...k.pos).add(anc);
  if (aspect >= DESIGN_ASPECT) return;
  const fit = clamp(DESIGN_ASPECT / aspect, 1, 2.4);
  const centre = clamp((DESIGN_ASPECT - aspect) / 0.65);
  if (k.f !== "ship") {
    const shift = k.look[0] * 0.75 * centre;
    look.x -= shift;
    pos.x -= shift;
  }
  pos.sub(look).multiplyScalar(1 + (fit - 1) * 0.85).add(look);
}

function catmull(out: THREE.Vector3, p0: THREE.Vector3, p1: THREE.Vector3, p2: THREE.Vector3, p3: THREE.Vector3, t: number) {
  const t2 = t * t;
  const t3 = t2 * t;
  for (const c of ["x", "y", "z"] as const) {
    out[c] = 0.5 * (2 * p1[c] + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3);
  }
  return out;
}

const space = (k: Key) => (k.f === "globe" ? 1 : 0);

/**
 * Camera position + look target for a given progress. Keys are joined with a Catmull-Rom
 * spline so the camera flows through them without stopping or turning sharply. (The jump to
 * and from the globe happens behind the veil, so those segments simply blend.)
 */
export function cameraAt(p: number, ship: THREE.Vector3, tx: number, aspect: number, pos: THREE.Vector3, look: THREE.Vector3) {
  let i = 0;
  while (i < KEYS.length - 2 && p > KEYS[i + 1].p) i++;
  const k1 = KEYS[i];
  const k2 = KEYS[i + 1];
  const t = seg(p, k1.p, k2.p);
  if (space(k1) !== space(k2)) {
    resolve(k1, ship, tx, aspect, P[1], L[1]);
    resolve(k2, ship, tx, aspect, P[2], L[2]);
    pos.lerpVectors(P[1], P[2], ease(t));
    look.lerpVectors(L[1], L[2], ease(t));
    return;
  }
  const k0 = i > 0 && space(KEYS[i - 1]) === space(k1) ? KEYS[i - 1] : k1;
  const k3 = i + 2 < KEYS.length && space(KEYS[i + 2]) === space(k2) ? KEYS[i + 2] : k2;
  resolve(k0, ship, tx, aspect, P[0], L[0]);
  resolve(k1, ship, tx, aspect, P[1], L[1]);
  resolve(k2, ship, tx, aspect, P[2], L[2]);
  resolve(k3, ship, tx, aspect, P[3], L[3]);
  catmull(pos, P[0], P[1], P[2], P[3], t);
  catmull(look, L[0], L[1], L[2], L[3], t);
}

// ---- Loader to container hand-off ------------------------------------------
/** The logo artwork painted on the container (canvas 2048 x 860, decal 1.84 units wide). */
export const DECAL_W = 1.84;
export const DECAL_ASPECT = 2048 / 860;
export const DECAL_H = DECAL_W / DECAL_ASPECT;
export const DECAL_Y = GROUND_C + 0.02; // world height of the decal centre when on the quay
export const CAMERA_FOV = 35;

/**
 * Size of the loading-screen logo in CSS pixels. The 3D intro camera is placed so
 * the painted logo on the container covers exactly this box, centred on screen,
 * so the loader can dissolve straight into the cargo.
 */
export function logoBox(w: number, h: number) {
  const width = Math.min(w * 0.84, h * 0.42 * DECAL_ASPECT);
  return { width, height: width / DECAL_ASPECT };
}

/** Intro close-up: the logo on the container fills the loader's logo box. */
export function introPose(w: number, h: number, pos: THREE.Vector3, look: THREE.Vector3) {
  const box = logoBox(w, h);
  const visibleH = DECAL_H / (box.height / h);
  const d = visibleH / (2 * Math.tan(THREE.MathUtils.degToRad(CAMERA_FOV / 2)));
  pos.set(0, DECAL_Y, 0.49 + d);
  look.set(0, DECAL_Y, 0);
}
