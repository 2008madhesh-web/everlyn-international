"use client";

import { motion, useScroll, useSpring } from "framer-motion";
import { useRef } from "react";
import { Reveal } from "./Reveal";

/** Vertical timeline whose spine draws as you scroll. */
export function Timeline({ items }: { items: { title: string; body: string; tag?: string }[] }) {
  const ref = useRef<HTMLOListElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 75%", "end 60%"] });
  const scaleY = useSpring(scrollYProgress, { stiffness: 80, damping: 24 });
  return (
    <ol ref={ref} className="relative ml-3 md:ml-0">
      <span aria-hidden className="absolute left-0 top-0 h-full w-px bg-forest-deep/10 md:left-1/2" />
      <motion.span aria-hidden style={{ scaleY }} className="absolute left-0 top-0 h-full w-px origin-top bg-brass md:left-1/2" />
      {items.map((m, i) => (
        <li key={m.title} className={`relative pb-16 pl-10 md:w-1/2 md:pl-0 ${i % 2 ? "md:ml-auto md:pl-16" : "md:pr-16 md:text-right"}`}>
          <span
            aria-hidden
            className={`absolute left-0 top-2 h-3 w-3 -translate-x-1/2 rounded-full border border-brass bg-ivory ${i % 2 ? "md:left-0" : "md:left-full"}`}
          />
          <Reveal y={20}>
            <p className="eyebrow mb-2">{m.tag ?? `Chapter ${String(i + 1).padStart(2, "0")}`}</p>
            <h3 className="display text-3xl text-forest-deep md:text-4xl">{m.title}</h3>
            <p className="mt-3 leading-relaxed text-ink/70">{m.body}</p>
          </Reveal>
        </li>
      ))}
    </ol>
  );
}
