import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";

/**
 * A corrugated steel panel (trapezoidal profile like a real ISO container wall).
 * Centred on the origin, spanning `len` along x and `height` along y, with the ribs
 * standing out toward +z. UVs are in world units (u = x, v = y) so textures tile at scale.
 */
export function corrugatedPanel(len: number, height: number, depth: number, pitch: number, thickness = 0.012) {
  const waves = Math.max(1, Math.round(len / pitch));
  const p = len / waves;
  const s = new THREE.Shape();
  const x0 = -len / 2;
  s.moveTo(x0, 0);
  for (let i = 0; i < waves; i++) {
    const x = x0 + i * p;
    s.lineTo(x + 0.3 * p, 0);
    s.lineTo(x + 0.5 * p, depth);
    s.lineTo(x + 0.8 * p, depth);
    s.lineTo(x + p, 0);
  }
  s.lineTo(len / 2, -thickness);
  s.lineTo(x0, -thickness);
  s.closePath();
  const g = new THREE.ExtrudeGeometry(s, { depth: height, bevelEnabled: false, steps: 1 });
  g.rotateX(Math.PI / 2); // profile depth → +z, extrusion → -y
  g.translate(0, height / 2, 0);
  return g;
}

function box(w: number, h: number, d: number, x: number, y: number, z: number) {
  const g = new THREE.BoxGeometry(w, h, d).toNonIndexed();
  // world-unit UVs so normal/roughness detail tiles consistently
  const uv = g.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * Math.max(w, d), uv.getY(i) * h);
  g.translate(x, y, z);
  return g;
}

/** Whole 20 ft container as one geometry, used for the instanced stacks in the yard and on the ship. */
export function containerGeometry(L = 2.4, H = 1.0, W = 0.98) {
  const parts: THREE.BufferGeometry[] = [];
  const d = 0.018;
  const side = corrugatedPanel(L - 0.1, H - 0.1, d, 0.11);
  const sideA = side.clone().translate(0, 0, W / 2 - d);
  const sideB = side.clone().rotateY(Math.PI).translate(0, 0, -W / 2 + d);
  const end = corrugatedPanel(W - 0.1, H - 0.1, d, 0.1);
  const endA = end.clone().rotateY(Math.PI / 2).translate(L / 2 - d, 0, 0);
  const endB = end.clone().rotateY(-Math.PI / 2).translate(-L / 2 + d, 0, 0);
  const roof = corrugatedPanel(L - 0.1, W - 0.1, 0.008, 0.16).rotateX(-Math.PI / 2).translate(0, H / 2 - 0.02, 0);
  parts.push(sideA, sideB, endA, endB, roof.toNonIndexed());
  const f = 0.06;
  for (const x of [L / 2 - f / 2, -L / 2 + f / 2]) for (const z of [W / 2 - f / 2, -W / 2 + f / 2]) parts.push(box(f, H, f, x, 0, z));
  for (const y of [H / 2 - f / 2, -H / 2 + f / 2]) {
    for (const z of [W / 2 - f / 2, -W / 2 + f / 2]) parts.push(box(L, f, f, 0, y, z));
    for (const x of [L / 2 - f / 2, -L / 2 + f / 2]) parts.push(box(f, f, W, x, y, 0));
  }
  parts.push(box(L - 0.04, 0.04, W - 0.04, 0, -H / 2 + 0.02, 0));
  const merged = mergeGeometries(parts.map((g) => (g.index ? g.toNonIndexed() : g)), false)!;
  merged.computeBoundingSphere();
  return merged;
}

// ---------------------------------------------------------------------------
export type HullSpec = { bow: number; stern: number; beam: number; depth: number; deckY: number };

/** Half-beam along the hull (t = 0 at the bow, 1 at the stern). */
function halfBeam(t: number, B: number) {
  if (t < 0.28) return B * Math.pow(Math.sin(((t / 0.28) * Math.PI) / 2), 0.62);
  if (t > 0.9) return B * (1 - ((t - 0.9) / 0.1) * 0.1);
  return B;
}
function hullDepth(t: number, D: number) {
  if (t < 0.12) return D * (0.62 + 0.38 * (t / 0.12));
  if (t > 0.82) return D * (1 - Math.pow((t - 0.82) / 0.18, 1.6) * 0.4);
  return D;
}
export function deckHeight(t: number, deckY: number) {
  return t < 0.16 ? deckY + 0.42 * Math.pow(1 - t / 0.16, 2) : deckY;
}

/**
 * Lofted container-ship hull: boxy midship sections with rounded bilges, a fine
 * entrance at the bow, sheer rising to the forecastle and a transom stern.
 * Vertex colours paint the antifouling below the waterline.
 */
export function hullGeometry(spec: HullSpec, waterY: number, colors: { top: string; boot: string; bottom: string }) {
  const N = 90;
  const M = 28;
  const n = 7; // superellipse exponent → bilge radius
  const pos: number[] = [];
  const col: number[] = [];
  const uv: number[] = [];
  const top = new THREE.Color(colors.top);
  const boot = new THREE.Color(colors.boot);
  const bottom = new THREE.Color(colors.bottom);
  const c = new THREE.Color();
  const B = spec.beam / 2;
  const sec: THREE.Vector3[][] = [];

  for (let i = 0; i <= N; i++) {
    const t = i / N;
    const x = spec.bow + (spec.stern - spec.bow) * t;
    const b = halfBeam(t, B);
    const D = hullDepth(t, spec.depth);
    const dk = deckHeight(t, spec.deckY);
    const ring: THREE.Vector3[] = [];
    for (let j = 0; j <= M; j++) {
      const phi = -Math.PI / 2 + (Math.PI * j) / M;
      const s = Math.sin(phi);
      const co = Math.cos(phi);
      const z = b * Math.sign(s) * Math.pow(Math.abs(s), 2 / n);
      // flare: topsides lean out slightly near the bow
      const flare = t < 0.3 ? 1 + 0.06 * (1 - t / 0.3) * Math.pow(Math.abs(s), 6) : 1;
      const y = spec.deckY - D * Math.pow(Math.abs(co), 2 / n) + (dk - spec.deckY) * Math.pow(Math.abs(s), 4);
      const v = new THREE.Vector3(x, y, z * flare);
      ring.push(v);
      pos.push(v.x, v.y, v.z);
      if (y < waterY - 0.06) c.copy(bottom);
      else if (y < waterY + 0.1) c.copy(boot);
      else c.copy(top);
      col.push(c.r, c.g, c.b);
      uv.push(x / 2.2, y / 2.2 + (z > 0 ? 0 : 7.3));
    }
    sec.push(ring);
  }
  const idx: number[] = [];
  const row = M + 1;
  for (let i = 0; i < N; i++)
    for (let j = 0; j < M; j++) {
      const a = i * row + j;
      const b2 = (i + 1) * row + j;
      idx.push(a, b2, a + 1, b2, b2 + 1, a + 1);
    }
  // transom cap (fan)
  const last = sec[N];
  const centreIndex = pos.length / 3;
  const cy = (last[0].y + last[Math.floor(M / 2)].y) / 2;
  pos.push(spec.stern, cy, 0);
  col.push(top.r, top.g, top.b);
  uv.push(0, 0);
  for (let j = 0; j < M; j++) idx.push(centreIndex, N * row + j, N * row + j + 1);
  idx.push(centreIndex, N * row + M, N * row);

  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return { geometry: g, sections: sec };
}

/** Deck surface following the sheer line. */
export function deckGeometry(spec: HullSpec) {
  const N = 90;
  const B = spec.beam / 2;
  const pos: number[] = [];
  const uv: number[] = [];
  const idx: number[] = [];
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    const x = spec.bow + (spec.stern - spec.bow) * t;
    const b = halfBeam(t, B) * 0.985;
    const y = deckHeight(t, spec.deckY) + 0.005;
    pos.push(x, y, -b, x, y, b);
    uv.push(x / 2, -b / 2, x / 2, b / 2);
    if (i < N) {
      const a = i * 2;
      idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

export function halfBeamAt(x: number, spec: HullSpec) {
  const t = (x - spec.bow) / (spec.stern - spec.bow);
  return halfBeam(Math.min(1, Math.max(0, t)), spec.beam / 2);
}

/** Tyre with a rounded shoulder, lathed around the x axis (wheel axle = z after rotation). */
export function tyreGeometry(r: number, width: number) {
  const pts: THREE.Vector2[] = [];
  const inner = r * 0.62;
  const sh = width * 0.22;
  pts.push(new THREE.Vector2(inner, -width / 2));
  pts.push(new THREE.Vector2(r - sh, -width / 2));
  for (let k = 0; k <= 6; k++) {
    const a = -Math.PI / 2 + (k / 6) * (Math.PI / 2);
    pts.push(new THREE.Vector2(r - sh + Math.cos(a) * sh, -width / 2 + sh + Math.sin(a) * sh));
  }
  for (let k = 0; k <= 6; k++) {
    const a = (k / 6) * (Math.PI / 2);
    pts.push(new THREE.Vector2(r - sh + Math.cos(a) * sh, width / 2 - sh + Math.sin(a) * sh));
  }
  pts.push(new THREE.Vector2(inner, width / 2));
  const g = new THREE.LatheGeometry(pts, 36);
  g.rotateX(Math.PI / 2); // axle along z
  return g;
}
