import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { Icon } from "@/components/ui/Icon";
import { CtaBand } from "@/components/ui/CtaBand";
import { industries } from "@/content/site";

export const metadata: Metadata = {
  title: "Industries We Serve",
  description: "Importers, retailers, food processors, hospitality groups, manufacturers and e-commerce brands source from India with Everlyn.",
};

export default function IndustriesPage() {
  return (
    <>
      <PageHero
        eyebrow="Industries"
        title="Built around the way you buy."
        intro="A supermarket and a machine-shop buyer need very different things. Here's how we tailor sourcing, packaging and logistics to each."
        crumbs={[{ label: "Industries" }]}
      />
      <section className="container-lux pb-16">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {industries.map((ind, i) => (
            <Reveal key={ind.title} delay={(i % 3) * 0.08}>
              <article className="group relative h-full overflow-hidden rounded-[1.75rem] border border-forest-deep/10 bg-ivory p-9 transition-all duration-700 hover:-translate-y-1 hover:shadow-[0_40px_80px_-50px_rgba(14,59,46,0.55)]">
                <span aria-hidden className="absolute inset-x-0 bottom-0 h-1 origin-left scale-x-0 bg-brass transition-transform duration-700 group-hover:scale-x-100" />
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-forest-deep text-brass-light">
                  <Icon name={ind.icon} className="h-7 w-7" />
                </span>
                <h2 className="display mt-7 text-3xl text-forest-deep">{ind.title}</h2>
                <p className="mt-3 text-sm leading-relaxed text-ink/70">{ind.body}</p>
                <ul className="mt-6 flex flex-wrap gap-2">
                  {ind.needs.map((n) => (
                    <li key={n} className="rounded-full bg-parchment px-3 py-1.5 text-xs text-forest-deep">{n}</li>
                  ))}
                </ul>
              </article>
            </Reveal>
          ))}
        </div>
      </section>
      <CtaBand />
    </>
  );
}
