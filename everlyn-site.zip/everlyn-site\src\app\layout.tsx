import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import "./globals.css";
import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { SmoothScroll } from "@/components/SmoothScroll";
import { Cursor } from "@/components/Cursor";
import { company, contact, socials } from "@/content/site";

const display = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  style: ["normal", "italic"],
});

const sans = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL(company.url),
  title: {
    default: `${company.name} — Import & Export from India`,
    template: `%s — ${company.name}`,
  },
  description: company.description,
  keywords: ["import export company India", "Indian exporter", "spices exporter", "basmati rice exporter", "textile exporter", "sourcing agent India", "Everlyn Internationals"],
  openGraph: {
    type: "website",
    siteName: company.name,
    title: `${company.name} — Import & Export from India`,
    description: company.description,
  },
  twitter: { card: "summary_large_image" },
};

export const viewport: Viewport = {
  themeColor: "#f6f1e7",
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: company.name,
  url: company.url,
  logo: `${company.url}/brand/everlyn-logo.jpg`,
  description: company.description,
  email: contact.email,
  telephone: contact.phone,
  address: { "@type": "PostalAddress", addressCountry: "IN" },
  sameAs: socials.map((s) => s.href).filter((h) => h.startsWith("http")),
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body className="min-h-screen">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:rounded-full focus:bg-forest-deep focus:px-4 focus:py-2 focus:text-ivory">
          Skip to content
        </a>
        <SmoothScroll />
        <Cursor />
        <Nav />
        <main id="main">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
