import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal, RevealText } from "@/components/ui/Reveal";
import { Icon } from "@/components/ui/Icon";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { products } from "@/content/site";

export function generateStaticParams() {
  return products.map((p) => ({ slug: p.slug }));
}

export const dynamicParams = false;

export async function generateMetadata({ params }: PageProps<"/products/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const p = products.find((x) => x.slug === slug);
  if (!p) return {};
  return { title: `${p.name} Exporter from India`, description: p.short };
}

export default async function ProductPage({ params }: PageProps<"/products/[slug]">) {
  const { slug } = await params;
  const idx = products.findIndex((x) => x.slug === slug);
  if (idx < 0) notFound();
  const p = products[idx];
  const next = products[(idx + 1) % products.length];

  return (
    <>
      <PageHero eyebrow="Product category" title={p.name} intro={p.intro} crumbs={[{ label: "Products", href: "/products" }, { label: p.name }]}>
        <div className="flex flex-wrap gap-3">
          <Button href={`/quote?product=${p.slug}`} arrow>Request a Quote</Button>
          <Button href="/contact" variant="outline">Ask for samples</Button>
        </div>
      </PageHero>

      <section className="container-lux pb-24 md:pb-32">
        <p className="eyebrow mb-8">What we supply</p>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {p.items.map((it, i) => (
            <Reveal as="li" key={it.name} delay={i * 0.06}>
              <div className="group h-full rounded-[1.5rem] border border-forest-deep/10 bg-ivory p-7 transition-all duration-700 hover:-translate-y-1 hover:border-brass/40 hover:shadow-[0_30px_60px_-40px_rgba(14,59,46,0.45)]">
                <Icon name={p.icon} className="h-7 w-7 text-brass transition-transform duration-700 group-hover:rotate-12" />
                <h3 className="display mt-5 text-2xl text-forest-deep">{it.name}</h3>
                <p className="mt-2 text-sm text-ink/65">{it.note}</p>
              </div>
            </Reveal>
          ))}
        </ul>
      </section>

      <section className="bg-forest-deep py-24 text-ivory md:py-32">
        <div className="container-lux grid gap-16 md:grid-cols-2">
          <div>
            <p className="eyebrow mb-5 !text-brass-light">Trade details</p>
            <RevealText text="Specifications at a glance." className="display text-4xl sm:text-5xl" />
            <dl className="mt-10 divide-y divide-ivory/10 border-y border-ivory/10">
              {p.specs.map((s) => (
                <Reveal key={s.label} y={10} className="grid gap-1 py-5 sm:grid-cols-3">
                  <dt className="text-xs uppercase tracking-[0.18em] text-ivory/50">{s.label}</dt>
                  <dd className="text-ivory/90 sm:col-span-2">{s.value}</dd>
                </Reveal>
              ))}
            </dl>
          </div>
          <div>
            <p className="eyebrow mb-5 !text-brass-light">Packaging options</p>
            <RevealText text="Packed for the voyage and the shelf." className="display text-4xl sm:text-5xl" />
            <ul className="mt-10 space-y-4">
              {p.packaging.map((x, i) => (
                <Reveal as="li" key={x} delay={i * 0.08} className="flex items-center gap-4 rounded-2xl border border-ivory/10 px-6 py-5">
                  <Icon name="box" className="h-6 w-6 shrink-0 text-brass-light" />
                  {x}
                </Reveal>
              ))}
            </ul>
            <p className="mt-8 text-sm text-ivory/60">
              Specifications are indicative. Final grades, packing and documents are confirmed in your proforma invoice.
            </p>
          </div>
        </div>
      </section>

      <section className="container-lux py-20">
        <Link href={`/products/${next.slug}`} className="group flex flex-col items-start justify-between gap-6 border-y border-forest-deep/15 py-12 md:flex-row md:items-center">
          <span>
            <span className="eyebrow">Next category</span>
            <span className="display mt-3 block text-4xl text-forest-deep transition-transform duration-700 group-hover:translate-x-3 md:text-6xl">{next.name}</span>
          </span>
          <span className="flex h-16 w-16 items-center justify-center rounded-full border border-forest-deep/20 text-forest-deep transition-all duration-500 group-hover:bg-forest-deep group-hover:text-ivory">
            <svg width="18" height="12" viewBox="0 0 16 10" fill="none" stroke="currentColor" strokeWidth="1.4"><path d="M0 5h14M10 1l4 4-4 4" /></svg>
          </span>
        </Link>
      </section>

      <CtaBand title={`Let's talk ${p.name.toLowerCase()}.`} />
    </>
  );
}
