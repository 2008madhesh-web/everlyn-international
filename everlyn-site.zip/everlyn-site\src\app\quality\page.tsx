import type { Metadata } from "next";
import { PageHero, SectionHeading } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { Timeline } from "@/components/ui/Timeline";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { certifications } from "@/content/site";

export const metadata: Metadata = {
  title: "Quality & Compliance",
  description: "How Everlyn Internationals inspects, tests and documents every shipment, plus our registrations and certifications.",
};

const checks = [
  { tag: "Before the order", title: "Supplier audit", body: "We visit and assess each supplier's facilities, capacity, hygiene and compliance before they join our network." },
  { tag: "Sampling", title: "Approved reference sample", body: "You approve a sample. We seal a matching counter-sample, and every later lot is measured against it." },
  { tag: "Production", title: "In-process checks", body: "Our team checks grading, cleaning, stitching or machining during production, not only at the end." },
  { tag: "Testing", title: "Laboratory analysis", body: "Moisture, purity, pesticide residues, aflatoxin, microbiology and material tests at NABL-accredited or independent labs." },
  { tag: "Pre-shipment", title: "AQL inspection", body: "Random sampling to international AQL standards, with a photo report before you release payment." },
  { tag: "Loading", title: "Container supervision", body: "Container condition, fumigation, stuffing and seal numbers are recorded and photographed at loading." },
];

const promises = [
  { icon: "shield" as const, t: "Third-party testing", d: "SGS, Intertek, Bureau Veritas or the lab of your choice, on request." },
  { icon: "doc" as const, t: "Complete documentation", d: "Certificates of analysis, origin, phytosanitary and fumigation in every shipment." },
  { icon: "search" as const, t: "Full traceability", d: "Each lot is traceable to its farm, mill or factory and its production date." },
  { icon: "leaf" as const, t: "Responsible sourcing", d: "Preference for suppliers with fair labour and sustainable practices." },
];

export default function QualityPage() {
  return (
    <>
      <PageHero
        eyebrow="Quality & compliance"
        title="Quality isn't a step. It's every step."
        intro="We check every shipment six times between the supplier and the sealed container, so what you receive matches what you approved."
        crumbs={[{ label: "Quality" }]}
      />

      <section className="container-lux pb-24 md:pb-32">
        <Timeline items={checks} />
      </section>

      <section className="bg-forest-deep py-24 text-ivory md:py-32">
        <div className="container-lux">
          <SectionHeading light eyebrow="Registrations" title="Recognised and registered." intro="Our registrations with Indian export authorities and quality bodies." />
          <ul className="mt-14 grid gap-px overflow-hidden rounded-[2rem] bg-ivory/10 sm:grid-cols-2 lg:grid-cols-3">
            {certifications.map((c, i) => (
              <Reveal as="li" key={c.name} delay={(i % 3) * 0.07} className="flex items-center gap-6 bg-forest-deep p-8">
                <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full border border-brass-light/40 text-brass-light">
                  <Icon name="shield" className="h-7 w-7" />
                </span>
                <span>
                  <span className="display block text-3xl">{c.name}</span>
                  <span className="text-sm text-ivory/60">{c.by}</span>
                </span>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <section className="container-lux py-24 md:py-32">
        <SectionHeading eyebrow="Our assurance" title="What you can count on." />
        <div className="mt-14 grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          {promises.map((p, i) => (
            <Reveal key={p.t} delay={i * 0.07}>
              <Icon name={p.icon} className="h-8 w-8 text-brass" />
              <h3 className="display mt-4 text-2xl text-forest-deep">{p.t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/65">{p.d}</p>
            </Reveal>
          ))}
        </div>
      </section>

      <CtaBand title="Need a specific test or certificate?" body="Tell us your market's requirements and we'll build them into the inspection plan before production starts." />
    </>
  );
}
