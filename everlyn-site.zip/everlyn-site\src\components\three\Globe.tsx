﻿"use client";

import { useMemo } from "react";
import * as THREE from "three";
import { geoEquirectangular, geoPath } from "d3-geo";
import { feature } from "topojson-client";
import type { Topology, GeometryCollection } from "topojson-specification";
import landTopo from "world-atlas/land-110m.json";
import { globeRoutes } from "@/content/site";

export const R = 2;

export function latLon(lat: number, lon: number, r = R, out = new THREE.Vector3()) {
  const phi = ((90 - lat) * Math.PI) / 180;
  const theta = ((lon + 180) * Math.PI) / 180;
  return out.set(-r * Math.sin(phi) * Math.cos(theta), r * Math.cos(phi), r * Math.sin(phi) * Math.sin(theta));
}

/** Fibonacci-sphere points that fall on land, found by rasterising the land polygons once. */
function landPoints(count: number) {
  const W = 1024;
  const H = 512;
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const g = c.getContext("2d", { willReadFrequently: true })!;
  const topo = landTopo as unknown as Topology<{ land: GeometryCollection }>;
  const land = feature(topo, topo.objects.land);
  const proj = geoEquirectangular().scale(W / (2 * Math.PI)).translate([W / 2, H / 2]);
  g.fillStyle = "#000";
  g.beginPath();
  geoPath(proj, g)(land);
  g.fill();
  const data = g.getImageData(0, 0, W, H).data;

  const pts: number[] = [];
  const golden = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < count; i++) {
    const y = 1 - (i / (count - 1)) * 2;
    const lat = (Math.asin(y) * 180) / Math.PI;
    const lon = ((((i * golden) % (2 * Math.PI)) * 180) / Math.PI) - 180;
    const px = Math.floor(((lon + 180) / 360) * W);
    const py = Math.floor(((90 - lat) / 180) * H);
    if (data[(py * W + px) * 4 + 3] > 128) {
      const v = latLon(lat, lon, R * 1.003);
      pts.push(v.x, v.y, v.z);
    }
  }
  return new Float32Array(pts);
}

const dotVert = /* glsl */ `
  uniform float uSize;
  uniform float uOpacity;
  varying float vFace;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vec3 n = normalize(normalMatrix * normalize(position));
    vFace = dot(n, normalize(-mv.xyz));
    gl_PointSize = uSize * (20.0 / -mv.z);
    gl_Position = projectionMatrix * mv;
  }
`;
const dotFrag = /* glsl */ `
  uniform vec3 uColor;
  uniform float uOpacity;
  varying float vFace;
  void main() {
    vec2 c = gl_PointCoord - 0.5;
    if (dot(c, c) > 0.25) discard;
    float a = smoothstep(-0.05, 0.35, vFace) * uOpacity;
    gl_FragColor = vec4(uColor, a);
  }
`;
const atmoVert = /* glsl */ `
  varying vec3 vN;
  varying vec3 vV;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vN = normalize(normalMatrix * normal);
    vV = normalize(-mv.xyz);
    gl_Position = projectionMatrix * mv;
  }
`;
const atmoFrag = /* glsl */ `
  uniform vec3 uColor;
  uniform float uOpacity;
  varying vec3 vN;
  varying vec3 vV;
  void main() {
    // brightest at the planet's limb, fading outward
    float f = pow(abs(dot(vN, vV)), 3.5);
    gl_FragColor = vec4(uColor, f * uOpacity);
  }
`;

export type RouteDef = { from: THREE.Vector3; to: THREE.Vector3; curve: THREE.CatmullRomCurve3; geo: THREE.TubeGeometry; total: number };

function makeRoute(a: { lat: number; lon: number }, b: { lat: number; lon: number }, radius: number): RouteDef {
  const from = latLon(a.lat, a.lon, 1);
  const to = latLon(b.lat, b.lon, 1);
  const angle = from.angleTo(to);
  const lift = 0.08 + angle * 0.22;
  const pts: THREE.Vector3[] = [];
  const q = new THREE.Quaternion();
  const axis = new THREE.Vector3().crossVectors(from, to).normalize();
  for (let i = 0; i <= 64; i++) {
    const t = i / 64;
    q.setFromAxisAngle(axis, angle * t);
    const v = from.clone().applyQuaternion(q).multiplyScalar(R * (1.01 + Math.sin(Math.PI * t) * lift));
    pts.push(v);
  }
  const curve = new THREE.CatmullRomCurve3(pts);
  const geo = new THREE.TubeGeometry(curve, 160, radius, 6, false);
  return { from: from.multiplyScalar(R), to: to.multiplyScalar(R), curve, geo, total: geo.index!.count };
}

/** Sets how much of a route tube is drawn (0 to 1). */
export function setRouteDraw(r: RouteDef, t: number) {
  const per = 6 * 6; // radialSegments * 6 indices per tubular segment
  r.geo.setDrawRange(0, Math.floor((r.total / per) * Math.min(1, Math.max(0, t))) * per);
}

export function useGlobeData(dotCount: number) {
  return useMemo(() => {
    const positions = landPoints(dotCount);
    const hero = makeRoute(globeRoutes.origin, globeRoutes.hero, 0.022);
    const others = globeRoutes.others.map((d) => makeRoute(globeRoutes.origin, d, 0.01));
    const pins = [globeRoutes.hero, ...globeRoutes.others].map((d) => latLon(d.lat, d.lon, R * 1.004));
    const origin = latLon(globeRoutes.origin.lat, globeRoutes.origin.lon, R * 1.004);
    return { positions, hero, others, pins, origin };
  }, [dotCount]);
}

export function useGlobeMaterials() {
  return useMemo(
    () => ({
      ocean: new THREE.MeshStandardMaterial({ color: "#1f5c47", emissive: "#0e3b2e", emissiveIntensity: 0.7, roughness: 0.65, metalness: 0.1, transparent: true, fog: false }),
      dots: new THREE.ShaderMaterial({
        vertexShader: dotVert,
        fragmentShader: dotFrag,
        transparent: true,
        depthWrite: false,
        uniforms: { uSize: { value: Math.min(window.devicePixelRatio, 2) * 0.9 }, uOpacity: { value: 1 }, uColor: { value: new THREE.Color("#ecd7a6") } },
      }),
      atmo: new THREE.ShaderMaterial({
        vertexShader: atmoVert,
        fragmentShader: atmoFrag,
        transparent: true,
        depthWrite: false,
        side: THREE.BackSide,
        uniforms: { uColor: { value: new THREE.Color("#7fb29a") }, uOpacity: { value: 0.75 } },
      }),
      heroRoute: new THREE.MeshBasicMaterial({ color: "#d9b878", transparent: true, toneMapped: false, fog: false }),
      route: new THREE.MeshBasicMaterial({ color: "#c7ab77", transparent: true, opacity: 0.55, toneMapped: false, fog: false }),
      pin: new THREE.MeshBasicMaterial({ color: "#f2e3c2", transparent: true, toneMapped: false, fog: false }),
      ring: new THREE.MeshBasicMaterial({ color: "#e3cc9c", transparent: true, side: THREE.DoubleSide, depthWrite: false, toneMapped: false, fog: false }),
    }),
    [],
  );
}

/** A pin that sits on the surface, with a pulsing ring facing outward. */
export function Pin({ at, mat, ringMat, size = 1, ringRef }: { at: THREE.Vector3; mat: THREE.Material; ringMat: THREE.Material; size?: number; ringRef?: (m: THREE.Mesh | null) => void }) {
  const quat = useMemo(() => new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), at.clone().normalize()), [at]);
  return (
    <group position={at} quaternion={quat}>
      <mesh material={mat}>
        <sphereGeometry args={[0.022 * size, 12, 12]} />
      </mesh>
      <mesh ref={ringRef} material={ringMat}>
        <ringGeometry args={[0.04 * size, 0.052 * size, 32]} />
      </mesh>
    </group>
  );
}
