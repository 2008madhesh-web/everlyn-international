"use client";

import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { Pin, R, setRouteDraw, useGlobeData, useGlobeMaterials } from "./Globe";
import { globeRoutes } from "@/content/site";

function GlobeModel() {
  const data = useGlobeData(24000);
  const gm = useGlobeMaterials();
  const rings = useRef<(THREE.Mesh | null)[]>([]);
  const t = useRef(0);
  const ringMats = useMemo(() => Array.from({ length: data.pins.length + 1 }, () => gm.ring.clone()), [data.pins.length, gm.ring]);
  const startY = useMemo(() => {
    const v = data.origin.clone().normalize();
    return -Math.atan2(v.x, v.z) + 0.5;
  }, [data.origin]);

  useFrame((_, dt) => {
    t.current += dt;
    const grow = Math.min(1, t.current / 2.5);
    setRouteDraw(data.hero, grow);
    data.others.forEach((r, i) => setRouteDraw(r, Math.min(1, Math.max(0, (t.current - 0.4 - i * 0.18) / 1.8))));
    rings.current.forEach((m, i) => {
      if (!m) return;
      const ph = (t.current * 0.6 + i * 0.27) % 1;
      m.scale.setScalar(0.6 + ph * 1.6);
      (m.material as THREE.MeshBasicMaterial).opacity = (1 - ph) * 0.9;
    });
  });

  return (
    <group rotation={[0.3, startY, 0]}>
      <mesh material={gm.ocean}>
        <sphereGeometry args={[R, 64, 64]} />
      </mesh>
      <points material={gm.dots}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[data.positions, 3]} />
        </bufferGeometry>
      </points>
      <mesh geometry={data.hero.geo} material={gm.heroRoute} />
      {data.others.map((r, i) => (
        <mesh key={i} geometry={r.geo} material={gm.heroRoute} />
      ))}
      <Pin at={data.origin} mat={gm.pin} ringMat={ringMats[0]} size={1.6} ringRef={(m) => (rings.current[0] = m)} />
      {data.pins.map((v, i) => (
        <Pin key={i} at={v} mat={gm.pin} ringMat={ringMats[i + 1]} ringRef={(m) => (rings.current[i + 1] = m)} />
      ))}
      <mesh material={gm.atmo}>
        <sphereGeometry args={[R * 1.1, 48, 48]} />
      </mesh>
    </group>
  );
}

/** Drag-to-rotate globe showing every Everlyn route. */
export default function InteractiveGlobe() {
  return (
    <Canvas camera={{ fov: 32, position: [0, 0, 8.4] }} dpr={[1, 1.75]} gl={{ antialias: true, alpha: true }} aria-label={`Globe showing routes from ${globeRoutes.origin.name} to ${[globeRoutes.hero, ...globeRoutes.others].map((d) => d.name).join(", ")}`}>
      <hemisphereLight args={["#fbf6ea", "#b9ab8c", 1.3]} />
      <directionalLight position={[4, 3, 5]} intensity={1.4} />
      <GlobeModel />
      <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} rotateSpeed={0.5} minPolarAngle={0.6} maxPolarAngle={2.5} />
    </Canvas>
  );
}
